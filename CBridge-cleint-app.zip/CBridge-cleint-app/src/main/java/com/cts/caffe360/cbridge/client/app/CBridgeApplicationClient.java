package com.cts.caffe360.cbridge.client.app;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cts.caffe360.cbridge.client.connect.impl.CBeridgeConnectImpl;
import com.cts.caffe360.cbridge.client.vo.CBridgeTestDataVO;

public class CBridgeApplicationClient{
	private static final Logger LOG = LoggerFactory.getLogger(CBridgeApplicationClient.class);

    
    public static void main( String[] args ) {
    	LOG.info("Test Case: 1");
//		testCBeridgeTestingWithStringJson();
		
		LOG.info("Test Case: 2");
		testCBeridgeConnectImpl();
		
		LOG.info("Test Case Execution completed");
	}

    private static void testCBeridgeConnectImpl() {
    	CBeridgeConnectImpl app = new CBeridgeConnectImpl();
		try {
			LOG.info("CBridge Health Check: " + app.cbridgeHealthCheck());
			CBridgeTestDataVO vo = app.cbridgeUpdateMethod(getCBridgeTestDataVO());
			LOG.info("CBridge - Data created and Values is: " + vo.toString());
			LOG.info("CBridge - Fetch Created Object from DB: " + app.cbridgeGetMethod(vo.getId().toString(), null));
			Map <String, String> keyVal = vo.getKeyValues();
	    	keyVal.put("Key_1", "value_111");
	    	LOG.info("CBridge - updated VO and updated into DB: " + app.cbridgeUpdateMethod(vo).toString());
	    	keyVal.put("Key_4", "value_4");
	    	LOG.info("CBridge - updated VO and updated into DB: " + app.cbridgeUpdateMethod(vo).toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    private static CBridgeTestDataVO getCBridgeTestDataVO() {
    	CBridgeTestDataVO vo = new CBridgeTestDataVO();
    	vo.setCreatedUser("CBridge_User");
    	vo.setKey("CBridge_Test_Key");
    	vo.setModuleName("CBridge");
    	vo.setId(0l);
    	Map <String, String> keyVal = new HashMap<>();
    	keyVal.put("Key_1", "value_1");
    	keyVal.put("Key_2", "value_2");
    	keyVal.put("Key_3", "value_3");
    	vo.setKeyValues(keyVal);
    	
    	return vo;
    }

    private static void testCBeridgeTestingWithStringJson() {
    	CBeridgeConnectImpl app = new CBeridgeConnectImpl();
		String jsonReqStr = "{\n" +
						"  \"created_user\": \"test_user\",\n" +
						"  \"id\": 0,\n" +
						"  \"key\": \"key_test\",\n" +
						"  \"module_name\": \"Test_Module_Name\",\n" +
						"  \"key_value\": {\n" +
						"    \"Name_1\": \"First Name\",\n" +
						"    \"Name_2\": \"Last_Name\",\n" +
						"    \"Salary\": \"111\"\n" +
						"  }\n" +
						"}";
		try {
			LOG.info("CBeridge Testing With String Json - Health Check: " + app.cbridgeHealthCheck());
			String jsonResStr = app.cbridgeUpdateMethod(jsonReqStr);
			CBridgeTestDataVO vo = app.getCBridgeTestDataVOFromJsonString(jsonResStr);
			LOG.info("CBeridge Testing With String Json - Fetch Created Object from DB: " + app.cbridgeGetMethod(vo.getId().toString(), null));
			Map <String, String> keyVal = vo.getKeyValues();
	    	keyVal.put("Name_1", "First Name Updated");
	    	keyVal.put("Name", "First Name Updated Last_Name");
	    	LOG.info("CBridge - updated VO and updated into DB: " + app.cbridgeUpdateMethod(jsonResStr).toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
