package com.cts.caffe360.cbridge.client.exception;

public class CBridgeURLConnectionExcetion extends Exception {
	private static final long serialVersionUID = 1L;

	public CBridgeURLConnectionExcetion() {
        super();
    }

    public CBridgeURLConnectionExcetion(String s) {
        super(s);
    }

    public CBridgeURLConnectionExcetion(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CBridgeURLConnectionExcetion(Throwable throwable) {
        super(throwable);
    }

    protected CBridgeURLConnectionExcetion(String s, Throwable throwable, boolean b, boolean b1) {
        super(s, throwable, b, b1);
    }
}
