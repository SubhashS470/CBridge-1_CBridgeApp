package com.cts.caffe360.cbridge.client.connect;

import java.util.Map;

import com.cts.caffe360.cbridge.client.vo.CBridgeTestDataVO;

public interface CBeridgeConnect {

	/**
	 * This method is used to get server status.
	 * @return
	 * @throws Exception
	 */
    String cbridgeHealthCheck() throws Exception;
    
    /**
     * This used get values with ID/Key or the combination of id and key
     * Solution for Following URL patterns,
     *  1. For Id -> http://localhost:7777/cbridge/api/testdata/id/{id}
     *  2. For Key -> http://localhost:7777/cbridge/api/testdata/id/{key}
     *  3. id and key -> http://localhost:7777/cbridge/api/testdata/id/{id}/key/{key}
     * @param id
     * @param key
     * @return
     * @throws Exception
     */
    String cbridgeGetMethod(String id, String key) throws Exception;
    
    /**
     * This method is used to save data into CBridge application
     * @param arg
     * @return
     * @throws Exception
     */
    String cbridgeUpdateMethod(Map<String, String> arg) throws Exception;

    /**
     * This method is used to update json object into DB
     * @param json
     * @return
     * @throws Exception
     */
    String cbridgeUpdateMethod(String json) throws Exception;
    
    /**
     * This method used to update user data in the format of CBridgeTestDataVO
     * @param jsonValue
     * @return CBridgeTestDataVO
     * @throws Exception
     */
    CBridgeTestDataVO cbridgeUpdateMethod(CBridgeTestDataVO jsonValue) throws Exception;

	String cbridgeGetMethod(String module, String key, String user) throws Exception;

}
