package com.cts.caffe360.cbridge.client.constant;

public interface CBeridgeConnectConstant {
    String CBRIDGE_HEALTH_CHECK = "http://localhost:7777/cbridge/api/testdata/healthCheck";
    String CBRIDGE_TEST_DATA_GET_BY_ID = "http://localhost:7777/cbridge/api/testdata/id/";
    String CBRIDGE_TEST_DATA_GET_URL = "http://localhost:7777/cbridge/api/testdata/";
    String CBRIDGE_TEST_DATA_UPDATE = "http://localhost:7777/cbridge/api/testdata/updateTestData";
    String CBRIDGE_TEST_DATA_GET_BY_KEY = "http://localhost:7777/cbridge/api/testdata/key/";

    String ARG_STR_ID = "id";
    String ARG_STR_KEY = "key";
    String ARG_STR_VALUE = "value";
    String ARG_STR_PARAM = "param";
    String ARG_ID = "{id}";
    String ARG_KEY = "{key}";
    String ARG_VALUE = "{value}";
}
