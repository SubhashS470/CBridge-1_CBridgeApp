package com.cts.caffe360.cbridge.client.connect.impl;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cts.caffe360.cbridge.client.connect.CBeridgeConnect;
import com.cts.caffe360.cbridge.client.constant.CBeridgeConnectConstant;
import com.cts.caffe360.cbridge.client.exception.CBridgeResponseException;
import com.cts.caffe360.cbridge.client.exception.CBridgeURLConnectionExcetion;
import com.cts.caffe360.cbridge.client.vo.CBridgeTestDataVO;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CBeridgeConnectImpl implements CBeridgeConnect {
    private static final Logger LOG = LoggerFactory.getLogger(CBeridgeConnectImpl.class);

    private HttpURLConnection con;
    private ObjectMapper om = new ObjectMapper();

    public CBeridgeConnectImpl() {
		super();
	}

	@Override
    public String cbridgeHealthCheck() throws Exception {
        return getGetBridgeApi(CBeridgeConnectConstant.CBRIDGE_HEALTH_CHECK, null).toString();
    }

//    @Override
//    public String cbridgeGetMethod(String url, Map<String, Object> arg) throws Exception {
//        return getGetBridgeApi(url, arg).toString();
//    }

    private StringBuffer getGetBridgeApi(String url, Map<String, Object> arg) throws CBridgeURLConnectionExcetion {
    	/*if (arg == null && !url.contains("/healthCheck")) {
    		LOG.info("\nArgument is null for the URL: "+ url);
    		throw new CBridgeURLConnectionExcetion("Argument is null for the URL: " + url);
    	}*/
        StringBuffer sb = new StringBuffer(16);
        try {
            LOG.info("\nURL: " + url);
            url = updateURLValue(url, arg);
            LOG.info("Updated URL: " + url);
            urlConnect(url);
            con.setRequestMethod("GET");

            if (con.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new CBridgeURLConnectionExcetion("Failed : HTTP error code : " + con.getResponseCode());
            }

            String str;
            BufferedReader br = getBufferedReader();
            LOG.info("Output from Server .... ");
            while ((str = br.readLine()) != null) {
                sb.append(str);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            disconnect();
        }
        LOG.info( "Response: " + sb.toString());
        return sb;
    }

    @SuppressWarnings("unchecked")
	private String updateURLValue(String url, Map<String, Object> arg) throws IOException {
        String id = null;
        String key = null;
        String value = null;
        boolean paramFlag = false;
        Map<String, String> params = null;
        String url1 = "";
        if (arg == null){
            return url;
        }
        for(String s : arg.keySet()){
            switch(s) {
                case CBeridgeConnectConstant.ARG_STR_ID:
                    id = (String) arg.get(s);
                    break;
                case CBeridgeConnectConstant.ARG_STR_KEY:
                    key = (String) arg.get(s);
                    break;
                case CBeridgeConnectConstant.ARG_STR_VALUE:
                    value = (String) arg.get(s);
                    break;
                case CBeridgeConnectConstant.ARG_STR_PARAM:
                    paramFlag = true;
                    params = (Map<String, String>) arg.get(CBeridgeConnectConstant.ARG_STR_PARAM);
                    break;
            }
        }
        if (StringUtils.isNotBlank(id) && StringUtils.isNotBlank(key)) {
            url1 = StringUtils.replace(url, CBeridgeConnectConstant.ARG_ID, id);
            url1 = StringUtils.replace(url1, CBeridgeConnectConstant.ARG_KEY, key);
        } else if (StringUtils.isNotBlank(id) && StringUtils.isNotBlank(value)) {
            url1 = StringUtils.replace(url, CBeridgeConnectConstant.ARG_ID, id);
            url1 = StringUtils.replace(url1, CBeridgeConnectConstant.ARG_VALUE, value);
        } else if (StringUtils.isNotBlank(value)) {
            url1 = StringUtils.replace(url, CBeridgeConnectConstant.ARG_VALUE, value);
        } else {
            url1 = StringUtils.replace(url, CBeridgeConnectConstant.ARG_ID, id);
        }
        if (paramFlag && params != null) {
            DataOutputStream out = new DataOutputStream(con.getOutputStream());
            out.writeBytes(getParamsString(params));
            out.flush();
            out.close();
        }
        return url1;
    }

    private void urlConnect(String url) throws IOException {
        con = getConnection(url);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type", "application/json");
        con.setDoInput(true);
        con.setDoOutput(true);
    }

    @Override
    public String cbridgeUpdateMethod(Map<String, String> arg) throws Exception {
        StringBuffer sb = null;
        try {
            postURLConnect(CBeridgeConnectConstant.CBRIDGE_TEST_DATA_UPDATE, om.writeValueAsString(arg));
            sb = getPostMethodResponse();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            disconnect();
        }
        return sb.toString();
    }

    @Override
    public String cbridgeUpdateMethod(String json) throws Exception {
        StringBuffer sb = null;
        try {
            postURLConnect(CBeridgeConnectConstant.CBRIDGE_TEST_DATA_GET_BY_KEY, json);
            sb = getPostMethodResponse();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            disconnect();
        }
        return sb.toString();
    }

    public CBridgeTestDataVO getCBridgeTestDataVOFromJsonString(String jsonVO) throws Exception {
		return (jsonVO != null ? om.readValue(jsonVO, CBridgeTestDataVO.class) : null);
	}
    
	private void postURLConnect(String url, String json) throws IOException, ProtocolException, CBridgeResponseException {
		LOG.info("The JSON value for Test Data POJO: " + json.toString());
		LOG.info("The URL: " + url);
		urlConnect(url);
		con.setRequestMethod("POST");
		OutputStream os = con.getOutputStream();
		os.write(json.getBytes());
		os.flush();
		if (con.getResponseCode() != HttpURLConnection.HTTP_OK) {
			throw new CBridgeResponseException("Failed Response: HTTP error code : " + con.getResponseCode());
		}
	}

    private BufferedReader getBufferedReader() throws IOException {
        return new BufferedReader(new InputStreamReader((con.getInputStream())));
    }

    private static HttpURLConnection getConnection(String url) throws MalformedURLException, IOException {
        return (HttpURLConnection) new URL(url).openConnection();
    }

    private void disconnect() {
        if (con != null) {
            con.disconnect();
        }
    }

    public static String getParamsString(Map<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, String> en : params.entrySet()) {
            result.append(URLEncoder.encode(en.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(en.getValue(), "UTF-8"));
            result.append("&");
        }
        String resultString = result.toString();
        return resultString.length() > 0 ? resultString.substring(0, resultString.length() - 1) : resultString;
    }

    public static void main(String ar[]){
        System.out.println(StringUtils.replace("http://localhost:7777/cbridge/api/testdata/id/{id}", CBeridgeConnectConstant.ARG_ID, "1"));
    }

	@Override
	public CBridgeTestDataVO cbridgeUpdateMethod(CBridgeTestDataVO jsonValue) throws Exception {
		StringBuffer sb = null;
		try {
			postURLConnect(CBeridgeConnectConstant.CBRIDGE_TEST_DATA_UPDATE, om.writeValueAsString(jsonValue));
			sb = getPostMethodResponse();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return (sb != null ? om.readValue(sb.toString(), CBridgeTestDataVO.class) : null);
	}

	private StringBuffer getPostMethodResponse() throws IOException {
		StringBuffer sb = new StringBuffer(16);
		BufferedReader br = getBufferedReader();
		String str;
		LOG.info("Output from Server .... \n");
		while ((str = br.readLine()) != null) {
			sb.append(str);
		}
		return sb;
	}

	@Override
	public String cbridgeGetMethod(String id, String key) throws Exception {
		String url = getURLStringForGetRequest(id, key);
		StringBuffer sb = new StringBuffer(16);
		try {
			LOG.info("Updated URL: " + url);
			urlConnect(url);
			con.setRequestMethod("GET");
			if (con.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new CBridgeURLConnectionExcetion("Failed : HTTP error code : " + con.getResponseCode());
			}
			String str;
			BufferedReader br = getBufferedReader();
			LOG.info("Output from Server .... ");
			while ((str = br.readLine()) != null) {
				sb.append(str);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		LOG.info( "Response: " + sb.toString());
		return sb.toString();
	}
	@Override
	public String cbridgeGetMethod(String key, String module,String user ) throws Exception {
		String url = getURLStringForGetRequest(key, module,user);
		StringBuffer sb = new StringBuffer(16);
		try {
			LOG.info("Updated URL: " + url);
			urlConnect(url);
			con.setRequestMethod("GET");
			if (con.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new CBridgeURLConnectionExcetion("Failed : HTTP error code : " + con.getResponseCode());
			}
			String str;
			BufferedReader br = getBufferedReader();
			LOG.info("Output from Server .... ");
			while ((str = br.readLine()) != null) {
				sb.append(str);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		LOG.info( "Response: " + sb.toString());
		return sb.toString();
	}

	private String getURLStringForGetRequest( String key,String module, String userName) {
		StringBuffer url = new StringBuffer(CBeridgeConnectConstant.CBRIDGE_TEST_DATA_GET_URL);
		
		if (StringUtils.isNotBlank(module) && StringUtils.isNotBlank(key)&&StringUtils.isNotBlank(userName)) {
			url.append("key/").append(key).append("/module/").append(module).append("/userName/").append(userName);
		} else if (StringUtils.isBlank(module) && StringUtils.isNotBlank(key)&& StringUtils.isNotBlank(userName)) {
			url.append("key/").append(key).append(key).append("/userName/").append(userName);
		} else if (StringUtils.isNotBlank(module) && StringUtils.isBlank(key)&&StringUtils.isNotBlank(userName)) {
			url.append("module/").append(module).append("/userName/").append(userName);
		}else if (StringUtils.isNotBlank(module) && StringUtils.isNotBlank(key)&&StringUtils.isBlank(userName)) {
			url.append("key/").append(key).append("/module/").append(module);
		}else if (StringUtils.isBlank(module) && StringUtils.isBlank(key)&&StringUtils.isNotBlank(userName)) {
			url.append("userName/").append(userName);
		}else if (StringUtils.isNotBlank(module) && StringUtils.isBlank(key)&&StringUtils.isBlank(userName)) {
			url.append("module/").append(module);
		}else if (StringUtils.isBlank(module) && StringUtils.isNotBlank(key)&&StringUtils.isBlank(userName)) {
			url.append("key/").append(key);
		}
		
		return url.toString();
	}

	private String getURLStringForGetRequest(String id, String key) {
		StringBuffer url = new StringBuffer(CBeridgeConnectConstant.CBRIDGE_TEST_DATA_GET_URL);
		if (StringUtils.isNotBlank(id) && StringUtils.isNotBlank(key)) {
			url.append("id/").append(id).append("/key/").append(key);
		} else if (StringUtils.isNotBlank(id) && StringUtils.isBlank(key)) {
			url.append("id/").append(id);
		} if (StringUtils.isBlank(id) && StringUtils.isNotBlank(key)) {
			url.append("key/").append(key);
		}
		return url.toString();
	}
	
}
