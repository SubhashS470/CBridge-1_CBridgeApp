package com.cts.caffe360.cbridge.client.exception;

public class CBridgeResponseException extends Exception {
	private static final long serialVersionUID = 1L;

	public CBridgeResponseException() {
        super();
    }

    public CBridgeResponseException(String s) {
        super(s);
    }

    public CBridgeResponseException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CBridgeResponseException(Throwable throwable) {
        super(throwable);
    }

    protected CBridgeResponseException(String s, Throwable throwable, boolean b, boolean b1) {
        super(s, throwable, b, b1);
    }
}
