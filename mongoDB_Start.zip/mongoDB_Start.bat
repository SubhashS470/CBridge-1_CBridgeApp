echo "Mongo DB starting"
::cd D:\Pandiyan\Software\mongodb-win32-x86_64-enterprise-windows-64-4.2.2\bin

::mongod --config mongod.cfg

::D:\Pandiyan\Software\mongodb-compass-1.20.4-win32-x64\MongoDBCompass.exe 

.\mongodb-4.2.3\bin\mongod.exe --port 27777 --dbpath .\MongoDB_Data\DB 

