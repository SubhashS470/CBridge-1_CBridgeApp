echo "Mongo DB Stop

taskkill /F /IM mongod.exe

