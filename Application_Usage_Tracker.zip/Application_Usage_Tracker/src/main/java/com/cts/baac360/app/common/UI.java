package com.cts.baac360.app.common;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class UI {
	private UI() {

	}

	public static void setMainWindowposition(JFrame frme) {
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension screenSize = toolkit.getScreenSize();
		frme.setBounds(100, 100, (int) screenSize.getWidth(), (int) screenSize.getHeight());
		frme.setLocationRelativeTo(frme.getGraphicsConfiguration().getDevice().getFullScreenWindow());
		frme.setVisible(true);
	}

	public static void setposition(JFrame frme) {
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension screenSize = toolkit.getScreenSize();
		int x = (screenSize.width - frme.getWidth()) / 2;
		int y = (screenSize.height - frme.getHeight()) / 2;
		frme.setLocation(x, y);
		frme.setLocationRelativeTo(null);
	}

	public static void setLookandFeel(String theme) {
		try {
			UIManager.setLookAndFeel(theme);
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
	}

	public static ImageIcon loadCaffelogo() {
		try {
			BufferedImage caffe360ImgFile = ImageIO.read(new File("Input/CAFFe360Logo.png"));
			return new ImageIcon(caffe360ImgFile.getScaledInstance(152, 35, Image.SCALE_SMOOTH));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
