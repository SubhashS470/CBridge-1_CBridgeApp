package com.cts.baac360.app.ui;

import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

@SuppressWarnings({ "serial", "rawtypes" })
public class CheckboxListCellRenderer extends JCheckBox implements ListCellRenderer {
	protected static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

//	private static int cound = 1;

	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
		setComponentOrientation(list.getComponentOrientation());
		setFont(list.getFont());
		setBackground(list.getBackground());
		setForeground(list.getForeground());
		setSelected(isSelected);
		setEnabled(list.isEnabled());
		list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		setText(value == null ? "" : value.toString());
		return this;
	}

	protected class CellRenderer implements ListCellRenderer {
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus){
			JCheckBox checkbox = (JCheckBox) value;
			checkbox.setBackground(isSelected ? list.getSelectionBackground() : list.getBackground());
			checkbox.setForeground(isSelected ? list.getSelectionForeground() : list.getForeground());
			checkbox.setEnabled(isEnabled());
			checkbox.setFont(getFont());
			checkbox.setFocusPainted(false);
			checkbox.setBorderPainted(true);
			checkbox.setBorder(isSelected ? UIManager.getBorder("List.focusCellHighlightBorder") : noFocusBorder);
			return checkbox;
		}
	}
}
