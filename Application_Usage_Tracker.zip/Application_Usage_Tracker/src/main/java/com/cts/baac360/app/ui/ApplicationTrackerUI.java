/**
 * 
 */
package com.cts.baac360.app.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cts.baac360.app.common.AppProperties;
import com.cts.baac360.app.common.UiUtility;
import com.cts.baac360.app.model.AppUsageTrackerVO;
import com.cts.baac360.app.model.LoginLogoffTrakerVO;
import com.cts.baac360.app.model.LoginRows;
import com.cts.baac360.app.model.TransactionRows;
import com.cts.baac360.app.thread.AppUsageTrackerBulkUpdateWorker;
import com.cts.baac360.app.util.AppUsageTrackerFetch;
import com.cts.baac360.app.util.AppUsageTrackerUtil;
import com.cts.baac360.app.util.StringTypeIdentifier;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.toedter.calendar.JDateChooser;

public class ApplicationTrackerUI extends JFrame {
	private static final Logger LOG = LoggerFactory.getLogger(ApplicationTrackerUI.class);
	private static final long serialVersionUID = -8182553549417799373L;
	public static JPanel pnlTransactionTableVal;
	public static DefaultTableModel modelTransaction;
	public static DefaultTableModel modelLogin;
	public static ApplicationTrackerUI fsApp = null;
	public JFrame frmValidatorFor;
	public JProgressBar progressBar = null;
	public JTable tblLogin, tbleTransaction;
	public static JPanel pnlLoginTableVal;
	public List<TransactionRows> tranlist;
	public List<LoginRows> loginlist;
	private static List<AppUsageTrackerVO> resLst;
	public static String appname = "";
	public static String path = System.getProperty("user.dir") + "\\Output\\" + "SavingsPivot" + "_"
			+ LocalDateTime.now().toString().replace(":", "").replace(".", "") + ".xlsx";
	public static List<String> lstPvot = Arrays.asList("Tower", "Date", "Associate Name", "Work Type",
			"Application Name", "Category", "Module Name");
	private JTextField txtCFG;
	private JDateChooser txtFromDateROI;
	private JDateChooser txtToDateROI;
	private TableRowSorter<DefaultTableModel> sorter;

	public ApplicationTrackerUI() throws IOException {
		init();
	}

	void init() {
		try {
			AppProperties.loadResources("Apiurl");
			framSetting();
			setApplicationTitleLable();
			setTransactionTablePanel();
			setLoginTablePanel();
			tbleTransaction.setModel(modelTransaction);
			populateTransactionDetails(tbleTransaction, tblLogin);
			tblLogin.setModel(modelLogin);
			JButton btnGenerateTranReport = new JButton();
			btnGenerateTranReport.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						File file = new File("Output");
						if (file.mkdir()) {
							LOG.info("Directory Created");
						} else {
							LOG.info("Directory is not created");
						}
						exportToExcel(tbleTransaction,
								System.getProperty("user.dir") + "\\Output\\TransactionDetailReport.xlsx");
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					LOG.info("Completed");
				}
			});
			btnGenerateTranReport.setText("Generate Report");
			btnGenerateTranReport.setFont(new Font("Tahoma", Font.PLAIN, 11));
			btnGenerateTranReport.setBounds(427, 239, 158, 23);
			pnlTransactionTableVal.add(btnGenerateTranReport);

			JButton btnUpdate = new JButton();
			btnUpdate.setText("Update");
			btnUpdate.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (tbleTransaction.isEditing()) {
						tbleTransaction.getCellEditor().stopCellEditing();
					}
					List<AppUsageTrackerVO> voListset = updateAcceptedRecordcount(tbleTransaction);
					if (voListset != null) {
						try {
							AppUsageTrackerBulkUpdateWorker
									.updateApplicationUsage(AppProperties.getString("api.url.update"), voListset);
							populateTransactionDetails(tbleTransaction, tblLogin);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}
			});
			btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 11));
			btnUpdate.setBounds(246, 239, 158, 23);
			pnlTransactionTableVal.add(btnUpdate);

			JLabel lblCfgNo = new JLabel("CFG No");
			lblCfgNo.setBounds(10, 18, 83, 14);
			pnlTransactionTableVal.add(lblCfgNo);

			tblLogin.setModel(modelLogin);

			JButton btnGenerateLoginReport = new JButton("Generate Report");
			btnGenerateLoginReport.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						File file = new File("Output");
						if (file.mkdir()) {
							LOG.info("Directory Created");
						} else {
							LOG.info("Directory is not created");
						}
						exportToExcel(tblLogin, System.getProperty("user.dir") + "\\Output\\LoginDetailReport.xlsx");
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					LOG.info("Completed");
				}
			});
			btnGenerateLoginReport.setFont(new Font("Tahoma", Font.PLAIN, 11));
			btnGenerateLoginReport.setBounds(438, 257, 158, 23);
			pnlLoginTableVal.add(btnGenerateLoginReport);

			JLabel lblWelcome = new JLabel("Welcome: ");
			lblWelcome.setBounds(20, 42, 75, 14);
			frmValidatorFor.getContentPane().add(lblWelcome);

			JLabel lblWelcome_1 = new JLabel(System.getProperty("user.name"));
			lblWelcome_1.setFont(new Font("MS Reference Sans Serif", Font.BOLD, 11));
			lblWelcome_1.setBounds(90, 41, 91, 14);
			frmValidatorFor.getContentPane().add(lblWelcome_1);

			JLabel lblDate = new JLabel("Date: ");
			lblDate.setBounds(500, 42, 75, 14);
			frmValidatorFor.getContentPane().add(lblDate);

			SimpleDateFormat sdfDestination = new SimpleDateFormat("dd/MM/yyyy");
			Date dt = new Date();
			JLabel lbltoDate = new JLabel(sdfDestination.format(dt));
			lbltoDate.setFont(new Font("MS Reference Sans Serif", Font.BOLD, 11));
			lbltoDate.setBounds(550, 41, 156, 14);
			frmValidatorFor.getContentPane().add(lbltoDate);

			frmValidatorFor.setVisible(true);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * @param args
	 */
	public JFrame getFrame() {
		return frmValidatorFor;
	}

	private void framSetting() throws IOException {
		frmValidatorFor = new JFrame();
		frmValidatorFor.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmValidatorFor.setBounds(50, 20, 766, 721);
		frmValidatorFor.setTitle("Baac360 Application Usage Tracker");
		frmValidatorFor.setBackground(new Color(153, 153, 102));
		frmValidatorFor.getContentPane().setLayout(null);
		UiUtility.setposition(frmValidatorFor);
	}

	public void setApplicationTitleLable() {
		JLabel lblFeeScheduleTesting = new JLabel("Baac360 Application Usage Tracker");
		lblFeeScheduleTesting.setHorizontalAlignment(SwingConstants.CENTER);
		lblFeeScheduleTesting.setForeground(new Color(47, 79, 79));
		lblFeeScheduleTesting.setFont(new Font("Arial", Font.BOLD, 18));
		lblFeeScheduleTesting.setBounds(10, 11, 696, 19);
		frmValidatorFor.getContentPane().add(lblFeeScheduleTesting);
	}

	@SuppressWarnings("serial")
	public void setTransactionTablePanel() {
		pnlTransactionTableVal = new JPanel();
		pnlTransactionTableVal.setForeground(Color.BLACK);
		pnlTransactionTableVal.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null),
				"Transaction Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnlTransactionTableVal.setBackground(Color.WHITE);
		pnlTransactionTableVal.setBounds(10, 100, 715, 271);
		frmValidatorFor.getContentPane().add(pnlTransactionTableVal);
		pnlTransactionTableVal.setLayout(null);
		txtCFG = new JTextField();
		txtCFG.setColumns(10);
		txtCFG.setBounds(105, 17, 158, 20);
		pnlTransactionTableVal.add(txtCFG);

		JLabel lblFromDate_1 = new JLabel("From Date");
		lblFromDate_1.setBounds(281, 18, 78, 14);
		pnlTransactionTableVal.add(lblFromDate_1);

		txtFromDateROI = new JDateChooser();
		txtFromDateROI.setDateFormatString("yyyy-MM-dd");
		txtFromDateROI.setBounds(340, 17, 135, 20);
		pnlTransactionTableVal.add(txtFromDateROI);

		JLabel lblToDate_1 = new JLabel("To Date");
		lblToDate_1.setBounds(490, 18, 57, 14);
		pnlTransactionTableVal.add(lblToDate_1);

		txtToDateROI = new JDateChooser();
		txtToDateROI.setDateFormatString("yyyy-MM-dd");
		txtToDateROI.setBounds(554, 17, 135, 20);
		pnlTransactionTableVal.add(txtToDateROI);

		modelTransaction = new DefaultTableModel(null, new String[] { "SeqNo", "User", "Tower", "Application Name",
				"CFG No", "Transaction Type", "Transaction Date", "Record Processed Count", "Accepted Record Count" }) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return column == 8; // ✅ ONLY column 8 editable
			}

		};
		tbleTransaction = new JTable(modelTransaction);
		sorter = new TableRowSorter<>(modelTransaction);
		tbleTransaction.setRowSorter(sorter);
		TableColumn column = tbleTransaction.getColumnModel().getColumn(0); // SeqNo
		column.setMinWidth(0);
		column.setMaxWidth(0);
		column.setPreferredWidth(0);
		column.setResizable(false);
		tbleTransaction.getColumnModel().getColumn(8).setCellRenderer(new DefaultTableCellRenderer() {

			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				if (!isSelected && value != null) {
					int count = Integer.parseInt(value.toString());

					if (count == 0) {
						c.setBackground(new Color(255, 204, 204)); // light red
					} else {
						c.setBackground(new Color(204, 255, 204)); // light green
					}
				}

				return c;
			}
		});
		DocumentListener listener = new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				applyTransactionFilters();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				applyTransactionFilters();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				applyTransactionFilters();
			}
		};

		txtCFG.getDocument().addDocumentListener(listener);
		((JTextField) txtFromDateROI.getDateEditor().getUiComponent()).getDocument().addDocumentListener(listener);
		((JTextField) txtToDateROI.getDateEditor().getUiComponent()).getDocument().addDocumentListener(listener);
		/*
		 * Date Application Name Category Module Name Transaction Name Work Type LOB
		 * Location Associate Name # of Transactions Automated Run in Seconds Manual Run
		 * in Seconds Manual Run Efforts Post Automation Automation Run Time Efforts
		 * Saved post Automation Automation Saving $
		 */

		tbleTransaction.setBounds(0, 21, 962, 229);
		JScrollPane scroTransactionPane = new JScrollPane(tbleTransaction,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroTransactionPane.setBounds(10, 52, 695, 176);

		JTextField numberField = new JTextField();
		numberField.setDocument(new javax.swing.text.PlainDocument() {
			@Override
			public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
				if (str.matches("\\d+")) {
					super.insertString(offset, str, attr);
				}
			}
		});
		tbleTransaction.getColumnModel().getColumn(8).setCellEditor(new DefaultCellEditor(numberField));
		pnlTransactionTableVal.add(scroTransactionPane);

	}

	public void setLoginTablePanel() {
		pnlLoginTableVal = new JPanel();
		pnlLoginTableVal.setForeground(Color.BLACK);
		pnlLoginTableVal.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null),

				"Login Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnlLoginTableVal.setBackground(Color.WHITE);
		pnlLoginTableVal.setBounds(10, 390, 715, 291);
		frmValidatorFor.getContentPane().add(pnlLoginTableVal);
		pnlLoginTableVal.setLayout(null);
		modelLogin = new DefaultTableModel(null,
				new String[] { "Date", "Application Name", "In Time", "Out Time", "Remarks" });
		tblLogin = new JTable(modelLogin);
		tblLogin.setBounds(0, 3, 962, 229);
		JScrollPane scroTableLoginPane = new JScrollPane(tblLogin, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroTableLoginPane.setBounds(10, 21, 695, 224);
		pnlLoginTableVal.add(scroTableLoginPane);
	}

	private void populateTransactionDetails(JTable table, JTable ltable) {
		SimpleDateFormat sdfSource = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
		SimpleDateFormat sdfDestination = new SimpleDateFormat("dd/MM/yyyy");
		modelTransaction = (DefaultTableModel) table.getModel();
		modelTransaction.setRowCount(0);
		tranlist = new ArrayList<>();
		loginlist = new ArrayList<>();
		modelLogin = (DefaultTableModel) ltable.getModel();
		modelLogin.setRowCount(0);
		AppUsageTrackerFetch af = new AppUsageTrackerFetch();
		String js = null;
		String jsl = null;
		try {

			/*
			 * js = af.findByUserandAppname(AppProperties.getString("api.url.all"), "rajk",
			 * "Benefit Studio"); jsl =
			 * af.findByUserandAppname(AppProperties.getString("api.url.logs"), "rajk",
			 * "Benefit Studio");
			 */

			js = af.findByUserandAppname(AppProperties.getString("api.url.all"), System.getProperty("user.name"),
					appname);
			jsl = af.findByUserandAppname(AppProperties.getString("api.url.logs"), System.getProperty("user.name"),
					appname);

			System.out.println(js);
			System.out.println(jsl);
			ObjectMapper om = new ObjectMapper();
			resLst = om.readValue(js, new TypeReference<List<AppUsageTrackerVO>>() {
			});
			List<LoginLogoffTrakerVO> resLoginLst = om.readValue(jsl, new TypeReference<List<LoginLogoffTrakerVO>>() {
			});
			for (int i = 0; i < resLst.size(); i++) {
				AppUsageTrackerVO vo = resLst.get(i);
				modelTransaction.addRow(new Object[] { vo.getId(), vo.getCreatedBy(), vo.getTowerName(),
						vo.getAppName(), vo.getCfgName(), vo.getTransactionType(),
						vo.getCreatedDate() != null ? sdfDestination.format(vo.getCreatedDate()) : "",
						vo.getTranTotalCount(),
						(vo.getAcceptFlag() != null && vo.getAcceptFlag().equals("Y")) ? vo.getAcceptedRecCount()
								: vo.getTranTotalCount(), });

			}
			for (int i = 0; i < resLoginLst.size(); i++) {
				LoginLogoffTrakerVO vo = resLoginLst.get(i);
				modelLogin.addRow(
						new Object[] { vo.getLoginDate() != null ? sdfDestination.format(vo.getLoginDate()) : "",
								vo.getAppName(), vo.getLoginTime() != null ? sdfSource.format(vo.getLoginTime()) : "",
								vo.getLogoffTime() != null ? sdfSource.format(vo.getLogoffTime()) : "",
								vo.getLogoffRemarks() });

			}
			table.setModel(modelTransaction);
			ltable.setModel(modelLogin);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
		ApplicationTrackerUI app = new ApplicationTrackerUI();
		fsApp = app;
		app.frmValidatorFor.setVisible(true);
	}

	public static String exportToExcel(JTable table, String filePath) throws IOException {
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Application Usage Export Data");
			updateColumnHeader(table, sheet);
			for (int rowNum = 0; rowNum < table.getRowCount(); rowNum++) {
				Row row = sheet.createRow(rowNum + 1);
				for (int colInd = 0; colInd < table.getColumnCount(); colInd++) {
					Cell cell = row.createCell(colInd);
					Object value = table.getValueAt(rowNum, colInd);
					if (value != null) {
						if (StringTypeIdentifier.isCurrency(value)) {
//							cell.setCellValue(AppUsageTrackerUtil.convertStringToCurrency(value.toString())); 
//							cell.setCellValue(value.toString()); 
							cell.setCellValue(
									new BigDecimal(AppUsageTrackerUtil.convertStringToCurrency(value.toString()))
											.doubleValue());
//							cell.setCellStyle(getCurrencyCellType(workbook));// Create a CellStyle for currency format
							cell.setCellStyle(getNumberCellType(workbook));
						} else if (StringTypeIdentifier.isNumber(value)) {
							String str = value.toString();
							if (str.indexOf(".") == -1) {
								try {
									cell.setCellValue(Long.valueOf(str));
								} catch (Exception e) {
									cell.setCellValue(value.toString());
								}
							} else {
								cell.setCellValue(new BigDecimal(str).doubleValue());
							}
							cell.setCellStyle(getNumberCellType(workbook));
						} else if (StringTypeIdentifier.isBoolean(value)) {
							cell.setCellValue((Boolean) value);
							cell.setCellStyle(getBooleanCellType(workbook));
						} else if (StringTypeIdentifier.isDate(value)) {
							cell.setCellValue(AppUsageTrackerUtil.convertStringToDate(value));
							cell.setCellStyle(getDateCellStyle(workbook));
						} else { // For other types, convert to string as a fallback
							cell.setCellValue(value.toString());
						}
					} else {
						cell.setCellValue(""); // Handle null values
					}
//					cell.setCellValue(table.getValueAt(i, j) != null ? table.getValueAt(i, j).toString() : "");
				}
			}
			File opFile = new File(filePath);
			if (opFile.createNewFile()) {
				LOG.info("New Report File Created: {}", opFile.getAbsoluteFile());
			}
			try (FileOutputStream outputStream = new FileOutputStream(opFile)) {
				workbook.write(outputStream);
				outputStream.flush();
				// DynamicExcelPivot.generatePivot(opFile.getAbsolutePath(), path,lstPvot, "# of
				// Transactions", "Sum");
				LOG.info("New Report written.....");
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return filePath;
	}

	private static void updateColumnHeader(JTable table, Sheet sheet) {
		Row headerRow = sheet.createRow(0);
		for (int i = 0; i < table.getColumnCount(); i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(table.getColumnName(i));
		}
	}

	private static CellStyle getDateCellStyle(Workbook workbook) {
		CellStyle cellStyle = workbook.createCellStyle();
		CreationHelper createHelper = workbook.getCreationHelper();
		cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
		return cellStyle;
	}

	private static CellStyle getBooleanCellType(Workbook workbook) {
		CellStyle cellStyle = workbook.createCellStyle();
		org.apache.poi.ss.usermodel.Font boolFont = workbook.createFont();
		cellStyle.setFont(boolFont);
		return cellStyle;
	}

	private static List<AppUsageTrackerVO> updateAcceptedRecordcount(JTable table) {
		List<AppUsageTrackerVO> voList = new ArrayList<>();
		TableModel model = table.getModel();
		int rowCount = model.getRowCount();
		for (int row = 0; row < rowCount; row++) {
			int processedCount = Integer.parseInt(model.getValueAt(row, 7).toString());
			int acceptedCount = Integer.parseInt(model.getValueAt(row, 8).toString());
			if (acceptedCount > processedCount) {
				JOptionPane
						.showMessageDialog(
								null, "Accepted Record Count cannot be greater than "
										+ "Record Processed Count.\n\nRow: " + (row + 1),
								"Validation Error", JOptionPane.ERROR_MESSAGE);
				return null;
			}
			AppUsageTrackerVO vo = resLst.get(row);
			if (vo.getId().equals(model.getValueAt(row, 0).toString())) {
				vo.setAcceptedRecCount(Integer.parseInt(model.getValueAt(row, 8).toString()));
				vo.setAcceptFlag("Y");
				voList.add(vo);
			}
		}
		return voList;

	}

	private static CellStyle getNumberCellType(Workbook workbook) {
		CellStyle cellStyle = workbook.createCellStyle();
		org.apache.poi.ss.usermodel.Font numberFont = workbook.createFont();
		cellStyle.setFont(numberFont);
		return cellStyle;
	}

	private void applyTransactionFilters() {

		List<RowFilter<TableModel, Object>> filters = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		/* CFG */
		if (!txtCFG.getText().trim().isEmpty()) {
			filters.add(RowFilter.regexFilter("(?i)" + txtCFG.getText(), 4)); // CFG column
		}
		/* Date Range */
		if (!((JTextField) txtFromDateROI.getDateEditor().getUiComponent()).getText().isEmpty()
				|| !((JTextField) txtToDateROI.getDateEditor().getUiComponent()).getText().isEmpty()) {
			filters.add(new RowFilter<>() {
				@Override
				public boolean include(Entry<? extends TableModel, ?> entry) {
					try {
						Date txnDate = sdf.parse(entry.getStringValue(6));

						if (!((JTextField) txtFromDateROI.getDateEditor().getUiComponent()).getText().isEmpty()) {
							Date from = formatter
									.parse(((JTextField) txtFromDateROI.getDateEditor().getUiComponent()).getText());
							if (txnDate.before(from))
								return false;
						}

						if (!((JTextField) txtToDateROI.getDateEditor().getUiComponent()).getText().isEmpty()) {
							Date to = formatter
									.parse(((JTextField) txtToDateROI.getDateEditor().getUiComponent()).getText());
							if (txnDate.after(to))
								return false;
						}
						return true;
					} catch (Exception e) {
						return false;
					}
				}
			});
		}

		sorter.setRowFilter(filters.isEmpty() ? null : RowFilter.andFilter(filters));
	}

}
