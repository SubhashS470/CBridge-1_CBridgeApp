package com.cts.baac360.app.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cts.baac360.app.common.AppProperties;
import com.cts.baac360.app.common.AppUsageTrackerConstant;
import com.cts.baac360.app.common.BaaC360AppTransactionType;
import com.cts.baac360.app.common.BaaC360ApplicationModule;
import com.cts.baac360.app.common.BaaC360ApplicationName;
import com.cts.baac360.app.model.AppUsageTrackerVO;
import com.cts.baac360.app.model.TmgUserDetailsVO;
import com.cts.baac360.app.util.AppUsageTrackerFetch;
import com.cts.baac360.app.util.AppUsageTrackerUtil;
import com.cts.baac360.app.util.TMGUserDetailsFetch;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.toedter.calendar.JDateChooser;

public class ApplicationUsageTrackerApplicationUI extends JFrame {

	private static final String[] ADMI_REPORT_TABLE_COLUMN_NAMES = /*
																	 * new String[] { "Date", "Application Name",
																	 * "Category", "Module Name", "Transaction Name",
																	 * "Project", "LOB", "On/Off",
																	 * "Name","Total Record",
																	 * "Automation Exe Hrs in Seconds",
																	 * "Mannual Hours Per Unit",
																	 * "Manual Effor After Automation",
																	 * "Automation Saving Hour's",
																	 * "Total Seconds Saving", "Automation Saving $" });
																	 */
			new String[] { "Date", "Tower", "Application Name", "Category", "Module Name", "Transaction Name",
					"Work Type", "CFG", "LOB", "Location", "Associate Name", "# of Transactions",
					"Accepted # of Transaction", "Automated Runtime (Seconds)", "Manual Runtime(Seconds)",
					"Manual Work Post Automation", "Time Saved by Automation (Hours)",
					"Time Saved by Automation (Seconds)", "Cost Savings from Automation ($)" };
	private static final String SINGLE_CODE = "'";
	private static final String ADMIN_TRANSACTION_DETAIL_REPORT_FILE_NAME = "AdminTransactionDetailReport";
	private static final String SAVING_DETAIL_REPORT_FILE_NAME = "SavingDetailReport";
	private static final Logger LOG = LoggerFactory.getLogger(ApplicationUsageTrackerApplicationUI.class);
	private static final long serialVersionUID = -8182553549417799373L;
	public static ApplicationUsageTrackerApplicationUI fsApp = null;
	private String exportROIReportName;
	private JTextField txtUsername;
	public static DefaultTableModel modelTransaction;
	public JTable tbleTransaction;
	private DefaultTableModel modelSaving;
	public JTable tbleSaving;
	private JPanel pnlAdmin;
	private JPanel pnlTransactionTableVal;
	private DefaultListModel<String> lstBoxAppListModel = new DefaultListModel<String>();
	private DefaultListModel<String> lstBoxmoduleListModel = new DefaultListModel<String>();
	private DefaultListModel<String> lstBoxTransListModel = new DefaultListModel<String>();
	private JList<String> appListBox;
	private JList<String> moduleListBox;
	private JList<String> tranListBox;
	private JList<String> appSavingListBox;
	private JList<String> moduleSavingListBox;
	private JList<String> tranSavingListBox;
	private Set<BaaC360ApplicationName> appList;
	private Set<BaaC360ApplicationModule> moduleNameList;
	private Set<BaaC360AppTransactionType> tranTypeList;
	private JDateChooser txtToDate;
	private JDateChooser txtFromDate;
	private JDateChooser txtFromDateROI;
	private JDateChooser txtToDateROI;
	final JProgressBar pgbSavingCal = new JProgressBar();
	private JCheckBox chckbxInclude;
	SimpleDateFormat sdfDestination = new SimpleDateFormat("MM/dd/yyyy");
	private JTextField txtUserNameROI;
	private JComboBox<String> cbTowerList;
	private JLabel lblROITotalSavingAmount;
	private JLabel lblROITotalHurs;

	public ApplicationUsageTrackerApplicationUI() throws IOException {
		init();
		setVisible(true);
	}

	void init() {
		try {
			AppProperties.loadResources("Apiurl");
			framSetting();
			setApplicationTitleLable();
			// populateTransactionDetails(tbleTransaction);
			getEnumList();
		} catch (Exception e) {
			LOG.error(e.getLocalizedMessage(), e);
		}
	}

	public static void main(String[] args) throws IOException {
		ApplicationUsageTrackerApplicationUI app = new ApplicationUsageTrackerApplicationUI();
		fsApp = app;
	}

	private void framSetting() throws IOException {
		setResizable(false);
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(50, 20, 949, 686);
		setTitle("Baac360 Application Usage Tracker Admin");
		setBackground(new Color(153, 153, 102));
		getContentPane().setLayout(null);
	}

	@SuppressWarnings({ "unchecked" })
	public void setApplicationTitleLable() {
		JLabel lblFeeScheduleTesting = new JLabel("Baac360 Application Usage Tracker Admin");
		lblFeeScheduleTesting.setHorizontalAlignment(SwingConstants.CENTER);
		lblFeeScheduleTesting.setForeground(new Color(47, 79, 79));
		lblFeeScheduleTesting.setFont(new Font("Arial", Font.BOLD, 18));
		lblFeeScheduleTesting.setBounds(118, 11, 696, 19);
		getContentPane().add(lblFeeScheduleTesting);
		pgbSavingCal.setFont(new Font("Tahoma", Font.BOLD, 10));
		pgbSavingCal.setStringPainted(true);

		pgbSavingCal.setBounds(251, 198, 499, 14);

		JTabbedPane tabs = new JTabbedPane();
		tabs.setBounds(0, 30, 933, 612);
		getContentPane().add(tabs);
		addTabPanelMouseListner(tabs);
		pnlAdmin = new JPanel();
		pnlAdmin.setVisible(false);
		// tabs.addTab("Admin Window", null, pnlAdmin, null);
		pnlAdmin.setLayout(null);
		JPanel pnlInput = new JPanel();
		pnlInput.setLayout(null);
		pnlInput.setBorder(new TitledBorder(null, "",

				TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlInput.setBounds(10, 11, 901, 221);
		pnlAdmin.add(pnlInput);

		JLabel lblUserName = new JLabel("User Name");
		lblUserName.setBounds(10, 14, 100, 14);
		pnlInput.add(lblUserName);

		txtUsername = new JTextField();
		txtUsername.setColumns(10);
		txtUsername.setBounds(75, 11, 191, 20);
		pnlInput.add(txtUsername);

		JLabel lblFromDate = new JLabel("From Date");
		lblFromDate.setBounds(332, 14, 100, 14);
		pnlInput.add(lblFromDate);

		txtFromDate = new JDateChooser();
		txtFromDate.setDateFormatString("yyyy-MM-dd");
		txtFromDate.setBounds(424, 11, 109, 20);
		pnlInput.add(txtFromDate);

		JLabel lblToDate = new JLabel("To Date");
		lblToDate.setBounds(637, 14, 104, 14);
		pnlInput.add(lblToDate);

		txtToDate = new JDateChooser();
		txtToDate.setDateFormatString("yyyy-MM-dd");
		txtToDate.setBounds(696, 11, 100, 20);
		pnlInput.add(txtToDate);

		JLabel lblApplicationName = new JLabel("Application Name");
		lblApplicationName.setBounds(10, 51, 100, 14);
		pnlInput.add(lblApplicationName);

		JScrollPane appListScrller = new JScrollPane(appListBox);
		appListScrller.setBounds(10, 76, 288, 112);
		pnlInput.add(appListScrller);
		appListBox = new JList<String>(lstBoxAppListModel);
		appListScrller.setViewportView(appListBox);
		appListBox.setVisibleRowCount(-1);
		// appListBox.setSelectedIndex(0);
		appListBox.setCellRenderer(new CheckboxListCellRenderer());
		appListBox.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

				if (appListBox.getSelectedValuesList().contains("ALL")) {
					selectAllAppListElements(appList);
				}
			}
		});
		appListBox.setLayoutOrientation(JList.HORIZONTAL_WRAP);

		lstBoxAppListModel.addElement("ALL");

		JLabel lblModuleName = new JLabel("Module Name");
		lblModuleName.setBounds(332, 53, 109, 14);
		pnlInput.add(lblModuleName);

		moduleListBox = new JList<String>(lstBoxmoduleListModel);
		moduleListBox.setForeground(new Color(0, 0, 0));
		moduleListBox.setBackground(new Color(255, 255, 255));
		moduleListBox.setBounds(332, 78, 258, 110);
		moduleListBox.setVisibleRowCount(-1);
		// moduleListBox.setSelectedIndex(0);
		moduleListBox.setCellRenderer(new CheckboxListCellRenderer());
		moduleListBox.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (moduleListBox.getSelectedValuesList().contains("ALL")) {
					selectAllmodListElements(moduleNameList);
				}
			}
		});
		moduleListBox.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		JScrollPane moduleListScrller = new JScrollPane(moduleListBox);
		moduleListScrller.setBounds(332, 78, 258, 110);
		moduleListScrller.setRowHeaderView(moduleListBox);
		pnlInput.add(moduleListScrller);

		lstBoxmoduleListModel.addElement("ALL");

		JLabel lblTransactionType = new JLabel("Transaction Type");
		lblTransactionType.setForeground(new Color(255, 255, 255));
		lblTransactionType.setBounds(637, 51, 109, 14);
		pnlInput.add(lblTransactionType);

		JScrollPane tranListScrller = new JScrollPane(tranListBox);
		tranListScrller.setBounds(637, 76, 238, 112);
		pnlInput.add(tranListScrller);
		tranListBox = new JList<String>(lstBoxTransListModel);
		tranListScrller.setViewportView(tranListBox);
		tranListBox.setVisibleRowCount(-1);
		// tranListBox.setSelectedIndex(0);
		tranListBox.setCellRenderer(new CheckboxListCellRenderer());
		tranListBox.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (tranListBox.getSelectedValuesList().contains("ALL")) {
					selectAlltranListElements(tranTypeList);
				}
			}
		});
		tranListBox.setLayoutOrientation(JList.HORIZONTAL_WRAP);

		lstBoxTransListModel.addElement("ALL");

		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pgbSavingCal.setIndeterminate(true);
				populateTransactionDetails(tbleTransaction);
				pgbSavingCal.setIndeterminate(false);
			}
		});
		btnSearch.setBounds(689, 192, 139, 23);

		pnlInput.add(btnSearch);

		JLabel label_1 = new JLabel("yyyy-mm-dd");
		label_1.setBounds(434, 30, 84, 14);
		pnlInput.add(label_1);

		JLabel label_2 = new JLabel("yyyy-mm-dd");
		label_2.setBounds(706, 30, 84, 14);
		pnlInput.add(label_2);

		pnlTransactionTableVal = new JPanel();
		pnlTransactionTableVal.setLayout(null);
		pnlTransactionTableVal.setForeground(Color.WHITE);
		pnlTransactionTableVal.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null),

				"Transaction Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnlTransactionTableVal.setBackground(Color.WHITE);
		pnlTransactionTableVal.setBounds(10, 228, 901, 345);
		modelTransaction = new DefaultTableModel(null,
				new String[] { "User", "Application Name", "Transaction Date", "Transaction Module", "Transaction Type",
						"Record Processed Count", "Duration In Minitues", "Status", "Status Remarks" });
		tbleTransaction = new JTable(modelTransaction);
		pnlAdmin.add(pnlTransactionTableVal);

		JScrollPane scroTransactionPane = new JScrollPane(tbleTransaction,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroTransactionPane.setBounds(10, 15, 881, 300);
		pnlTransactionTableVal.add(scroTransactionPane);

		JButton btnGenerateTranReport = new JButton();
		btnGenerateTranReport.setText("Generate Report");
		btnGenerateTranReport.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnGenerateTranReport.setBounds(363, 320, 158, 23);
		btnGenerateTranReport.addActionListener(e -> {
			actionGenerateReportOnSaving();
		});
		pnlTransactionTableVal.add(btnGenerateTranReport);

		JPanel pnlSavings = new JPanel();
		pnlSavings.setLayout(null);
		tabs.addTab("Automation Savings Report (ROI)", null, pnlSavings, null);

		JPanel pnlInputSaving = new JPanel();
		pnlInputSaving.setLayout(null);
		pnlInputSaving.setBorder(new TitledBorder(null, "",

				TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnlInputSaving.setBounds(0, 0, 928, 579);
		pnlSavings.add(pnlInputSaving);

		pnlInputSaving.add(pgbSavingCal);

		appSavingListBox = new JList<String>(lstBoxAppListModel);
		appSavingListBox.setBounds(10, 63, 288, 20);
		// pnlInputSaving.add(appSavingListBox);
		appSavingListBox.setVisibleRowCount(-1);
		// appListBox.setSelectedIndex(0);
		appSavingListBox.setCellRenderer(new CheckboxListCellRenderer());
		appSavingListBox.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

				if (appSavingListBox.getSelectedValuesList().contains("ALL")) {
					selectAllSavingAppListElements(appList);
				}
				loadListFilter(lstBoxmoduleListModel, moduleSavingListBox, "module", appSavingListBox,
						appSavingListBox);
				selectAllmodListElements(moduleNameList);
				loadListFilter(lstBoxTransListModel, tranSavingListBox, "tran", appSavingListBox, moduleSavingListBox);
				selectAlltranListElements(tranTypeList);
			}
		});
		appSavingListBox.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		lstBoxAppListModel.addElement("ALL");

		JScrollPane appListSavingScrller = new JScrollPane(appSavingListBox);
		appListSavingScrller.setBounds(10, 63, 290, 112);
		pnlInputSaving.add(appListSavingScrller);

		JLabel lblFromDate_1 = new JLabel("From Date");
		lblFromDate_1.setBounds(437, 7, 78, 14);
		pnlInputSaving.add(lblFromDate_1);
		txtFromDateROI = new JDateChooser();
		txtFromDateROI.setDateFormatString("yyyy-MM-dd");
		txtFromDateROI.setBounds(496, 7, 135, 20);
		pnlInputSaving.add(txtFromDateROI);

		/*
		 * JXDatePicker picker = new JXDatePicker(); picker.setDate(new Date());
		 * picker.setFormats(new SimpleDateFormat("dd.MM.yyyy")); picker.setBounds(95,
		 * 11, 109, 20); pnlInputSaving.add(picker);
		 */

		JLabel lblToDate_1 = new JLabel("To Date");
		lblToDate_1.setBounds(646, 7, 57, 14);
		pnlInputSaving.add(lblToDate_1);

		txtToDateROI = new JDateChooser();
		txtToDateROI.setDateFormatString("yyyy-MM-dd");
		txtToDateROI.setBounds(710, 7, 135, 20);
		pnlInputSaving.add(txtToDateROI);

		chckbxInclude = new JCheckBox("Report Include Miscellaneous Task");
		chckbxInclude.setBounds(10, 187, 191, 25);
		pnlInputSaving.add(chckbxInclude);

		JLabel lblApplicationName_1 = new JLabel("Application Name");
		lblApplicationName_1.setBounds(10, 45, 100, 14);
		pnlInputSaving.add(lblApplicationName_1);

		JLabel lblModuleName_1 = new JLabel("Module Name");
		lblModuleName_1.setBounds(312, 45, 109, 14);
		pnlInputSaving.add(lblModuleName_1);

		JScrollPane moduleSavingListScrller = new JScrollPane(moduleSavingListBox);
		moduleSavingListScrller.setBounds(310, 63, 290, 110);
		moduleSavingListBox = new JList<String>(lstBoxmoduleListModel);
		moduleSavingListScrller.setViewportView(moduleSavingListBox);
		moduleSavingListBox.setVisibleRowCount(-1);
		// appListBox.setSelectedIndex(0);
		moduleSavingListBox.setCellRenderer(new CheckboxListCellRenderer());
		moduleSavingListBox.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (moduleSavingListBox.getSelectedValuesList().contains("ALL")) {
					selectAllmodListElements(moduleNameList);
				}
				loadListFilter(lstBoxTransListModel, tranSavingListBox, "tran", appSavingListBox, moduleSavingListBox);
				selectAlltranListElements(tranTypeList);
			}
		});
		moduleSavingListBox.setLayoutOrientation(JList.HORIZONTAL_WRAP);

		lstBoxmoduleListModel.addElement("ALL");
		pnlInputSaving.add(moduleSavingListScrller);

		JLabel lblTransactionType_1 = new JLabel("Transaction Type");
		lblTransactionType_1.setBounds(610, 45, 109, 14);
		pnlInputSaving.add(lblTransactionType_1);

		JScrollPane tranSavingListScrller = new JScrollPane(tranSavingListBox);
		tranSavingListScrller.setBounds(610, 63, 290, 112);
		tranSavingListBox = new JList<String>(lstBoxTransListModel);
		tranSavingListScrller.setViewportView(tranSavingListBox);
		tranSavingListBox.setVisibleRowCount(-1);
		// appListBox.setSelectedIndex(0);
		tranSavingListBox.setCellRenderer(new CheckboxListCellRenderer());
		tranSavingListBox.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

				if (tranSavingListBox.getSelectedValuesList().contains("ALL")) {
					selectAlltranListElements(tranTypeList);
				}
			}
		});
		tranSavingListBox.setLayoutOrientation(JList.HORIZONTAL_WRAP);

		lstBoxTransListModel.addElement("ALL");
		pnlInputSaving.add(tranSavingListScrller);

		JButton btnROISearch = new JButton("ROI - Search");
		btnROISearch.addActionListener(e -> {
//			SwingUtilities.invokeLater(() -> {
//                	setProgressBarStatusStarted();
//                    populateROISavingDetails();
//                    setProgressBarStatusCompleted();
//            });

			Thread roiThread = new Thread(() -> {

				setProgressBarStatusStarted();
				populateROISavingDetails();
				setProgressBarStatusCompleted();
			});
			roiThread.start();
		});
		btnROISearch.setBounds(761, 189, 139, 23);
		pnlInputSaving.add(btnROISearch);

		JLabel lblYyyymmdd = new JLabel("yyyy-mm-dd");
		lblYyyymmdd.setFont(new Font("Tahoma", Font.PLAIN, 8));
		lblYyyymmdd.setBounds(506, 28, 84, 14);
		pnlInputSaving.add(lblYyyymmdd);

		JLabel label = new JLabel("yyyy-mm-dd");
		label.setFont(new Font("Tahoma", Font.PLAIN, 8));
		label.setBounds(710, 24, 84, 14);
		pnlInputSaving.add(label);

		JPanel pnlSavingTransaction = new JPanel();
		pnlSavingTransaction.setLayout(null);
		pnlSavingTransaction.setForeground(Color.BLACK);
		pnlSavingTransaction.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null),
				"Automation Saving Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnlSavingTransaction.setBackground(Color.WHITE);
		pnlSavingTransaction.setBounds(0, 219, 916, 345);
		pnlInputSaving.add(pnlSavingTransaction);

		modelSaving = new DefaultTableModel(null, ADMI_REPORT_TABLE_COLUMN_NAMES);
		tbleSaving = new JTable(modelSaving);

		JScrollPane scroTransactionPane_1 = new JScrollPane(tbleSaving,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroTransactionPane_1.setBounds(10, 15, 896, 293);
		pnlSavingTransaction.add(scroTransactionPane_1);

		JButton btnGenerateTranReportAmin = new JButton();
		btnGenerateTranReportAmin.setText("Generate Report");
		btnGenerateTranReportAmin.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnGenerateTranReportAmin.setBounds(68, 316, 158, 23);
		btnGenerateTranReportAmin.addActionListener(e -> {
			Thread thr = new Thread(() -> {
				aminReportGenerateAction();
			});
			thr.start();
		});

		pnlSavingTransaction.add(btnGenerateTranReportAmin);

		JLabel lblTotalSavingHrs = new JLabel("Total Saving Hrs: ");
		lblTotalSavingHrs.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblTotalSavingHrs.setBounds(415, 320, 108, 14);
		pnlSavingTransaction.add(lblTotalSavingHrs);

		lblROITotalHurs = new JLabel("00:00:00");
		lblROITotalHurs.setHorizontalAlignment(SwingConstants.CENTER);
		lblROITotalHurs.setForeground(new Color(0, 128, 0));
		lblROITotalHurs.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblROITotalHurs.setBounds(505, 316, 140, 23);
		pnlSavingTransaction.add(lblROITotalHurs);

		lblROITotalSavingAmount = new JLabel("$0.00");
		lblROITotalSavingAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblROITotalSavingAmount.setForeground(new Color(0, 128, 0));
		lblROITotalSavingAmount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblROITotalSavingAmount.setBounds(767, 314, 139, 25);
		pnlSavingTransaction.add(lblROITotalSavingAmount);

		JLabel lblTotalSavingAmount = new JLabel("Total Saving Amount: ");
		lblTotalSavingAmount.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblTotalSavingAmount.setBounds(650, 320, 109, 14);
		pnlSavingTransaction.add(lblTotalSavingAmount);

		JButton btnOpenGeneratedReport = new JButton("Open Generated Report");
		btnOpenGeneratedReport.addActionListener(e -> {
			btnOpenGeneratedReportAction();
		});
		btnOpenGeneratedReport.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnOpenGeneratedReport.setBounds(249, 316, 158, 23);
		pnlSavingTransaction.add(btnOpenGeneratedReport);

		JLabel lblNewLabel = new JLabel("Tower");
		lblNewLabel.setBounds(17, 11, 51, 14);
		pnlInputSaving.add(lblNewLabel);

		cbTowerList = new JComboBox<String>();
		cbTowerList.addItem("-----Select------");
		cbTowerList.addItem("Configuration");
		cbTowerList.addItem("Enrollment");
		cbTowerList.addItem("Billing");
		cbTowerList.addItem("Claims");
		cbTowerList.addItem("FDI & CS");
		cbTowerList.addItem("Finance & Encounter");
		cbTowerList.addItem("QNXT");
		cbTowerList.setBounds(53, 10, 135, 16);
		pnlInputSaving.add(cbTowerList);

		JLabel lblUserNameROI = new JLabel("User Id");
		lblUserNameROI.setBounds(195, 9, 78, 14);
		pnlInputSaving.add(lblUserNameROI);

		txtUserNameROI = new JTextField();
		txtUserNameROI.setColumns(10);
		txtUserNameROI.setBounds(249, 7, 176, 20);
		pnlInputSaving.add(txtUserNameROI);
		// ComboBoxModel<String> tower = new

	}

	private void setProgressBarStatusStarted() {
		pgbSavingCal.setString("Search Processing...");
		pgbSavingCal.setIndeterminate(true);
	}

	private void setProgressBarStatusCompleted() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				pgbSavingCal.setIndeterminate(false);
				pgbSavingCal.setString("Search Completed...");
			}
		});
	}

	private void btnOpenGeneratedReportAction() {
		try {
			if (StringUtils.isNotBlank(exportROIReportName)) {
				File file = new File(exportROIReportName);
				if (file.exists()) {
					AppUsageTrackerUtil.openFileWithDefaultApplication(file);
				} else {
					JOptionPane.showMessageDialog(this, "No Report Found to Open, Please Generate Report");
				}
			} else {
				JOptionPane.showMessageDialog(this, "No Report Found to Open, Please Generate Report");
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	private void aminReportGenerateAction() {
		try {
			File file = new File("Output");
			if (file.mkdir()) {
				LOG.info("Directory Created");
			} else {
				LOG.info("Directory is not created");
			}
			exportROIReportName = ApplicationTrackerUI.exportToExcel(tbleSaving,
					getExportReportNameForROI(SAVING_DETAIL_REPORT_FILE_NAME));
			JOptionPane.showMessageDialog(this, "Saving Report Generated Successfuly");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		LOG.info("Completed");
	}

	private void actionGenerateReportOnSaving() {
		try {
			// pgbSavingCal.setP
			File file = new File("Output");
			if (file.mkdir()) {
				LOG.info("Directory Created");
			} else {
				LOG.info("Directory is not created");
			}
			ApplicationTrackerUI.exportToExcel(tbleTransaction,
					getExportReportNameForROI(ADMIN_TRANSACTION_DETAIL_REPORT_FILE_NAME));
			JOptionPane.showMessageDialog(null, "Saving Report Generated Successfuly");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		LOG.info("Saving Report Generated Completed");
	}

	private String getExportReportNameForROI(String outReporFileName) {
		return System.getProperty("user.dir") + "\\Output\\" + outReporFileName + "_"
				+ LocalDateTime.now().toString().replace(":", "").replace(".", "") + ".xlsx";
	}

	private void populateROISavingDetails() {
//		pgbSavingCal.setIndeterminate(true);
		modelSaving = (DefaultTableModel) tbleSaving.getModel();
		modelSaving.setRowCount(0);
		BigDecimal totalROIAutoSaving = new BigDecimal(0);
		long totalROIAutoSavingSecond = 0;

		AppUsageTrackerFetch af = new AppUsageTrackerFetch();
		String strFromDate = ((JTextField) txtFromDateROI.getDateEditor().getUiComponent()).getText();
		String strToDate = ((JTextField) txtToDateROI.getDateEditor().getUiComponent()).getText();

		String js = null;
		try {
			LOG.info("Application Selected: " + appSavingListBox.getSelectedValuesList().toString());

			js = af.findall(AppProperties.getString("api.url.fetch.tower.roi.all.param"),
					cbTowerList.getSelectedIndex() > 0 ? cbTowerList.getSelectedItem().toString() : "",
					txtUserNameROI.getText(), strFromDate, strToDate,
					String.join(",", appSavingListBox.getSelectedValuesList()),
					String.join(",", moduleSavingListBox.getSelectedValuesList()),
					String.join(",", tranSavingListBox.getSelectedValuesList()));

			LOG.info("API Response :" + js);
			ObjectMapper om = new ObjectMapper();
			List<AppUsageTrackerVO> resLst = om.readValue(js, new TypeReference<List<AppUsageTrackerVO>>() {
			});
			List<String> lstUser = Arrays.asList(AppProperties.getString("user.details").split(","));
			BigDecimal perHrsSecond = new BigDecimal(3600);
			BigDecimal offshoreRate = new BigDecimal(AppProperties.getString("fte.rate.for.offshore"))
					.divide(perHrsSecond, 6, RoundingMode.HALF_EVEN);
			BigDecimal onshoreRate = new BigDecimal(AppProperties.getString("fte.rate.for.onshore"))
					.divide(perHrsSecond, 6, RoundingMode.HALF_EVEN);
			BigDecimal autoSaving = new BigDecimal(0);
			for (int i = 0; i < resLst.size(); i++) {
				AppUsageTrackerVO vo = resLst.get(i);
				/*
				 * if(vo.getTransactionType().equals("Accum_Outbound_Report_Validation")) {
				 * System.out.println(vo.getTransactionType()); }
				 */
				BaaC360AppTransactionType enu = BaaC360AppTransactionType
						.getBaaC360AppTransactionTypeByNmae(vo.getTransactionType());
				int totalExeTimeInSecond = AppUsageTrackerUtil
						.convertHoursHHMMSSToSeconds(AppUsageTrackerUtil.convertStringToHHMMSS(vo.getTotalExeTime()));
				if (enu == null || enu.getMannualEffort() == null) {
					enu = BaaC360AppTransactionType.DEFAULT;
				}
				int totrecordcount = getTotalRecordCount(vo);
				int totalManEffInSecond = AppUsageTrackerUtil.convertMinuesToSeconds(enu.getMannualEffort());
				int totalManAftAutEffInSecond = AppUsageTrackerUtil
						.convertMinuesToSeconds(enu.getMannualEffortAfterAutomation());
				if (enu.getName().equals("QNXT_FS_Schedule_Validation")) {
					totalManEffInSecond = getManeff(totrecordcount);
					totalManAftAutEffInSecond = getpostAManeff(totrecordcount);
				}
				if (checkTransaction(enu)) {
					totalManEffInSecond = totalManEffInSecond * (totrecordcount != 0 ? totrecordcount : 1);
					totalManAftAutEffInSecond = totalManAftAutEffInSecond * (totrecordcount != 0 ? totrecordcount : 1);
				}

				long totalAutoEfforSecond = totalExeTimeInSecond + totalManAftAutEffInSecond;
				long totalAutoSavingSecond = 0;
				if (totalManEffInSecond < totalAutoEfforSecond || totrecordcount == 0) {
					if (enu.getName().equals("Accum_Outbound_Report_Validation")
							|| enu.getName().equals("Over_Accum__Report_Validation")) {
						totalAutoSavingSecond = 600;
					} else {
						totalAutoSavingSecond = 0;
					}

				} else {
					totalAutoSavingSecond = totalManEffInSecond - totalAutoEfforSecond;
				}
				double totalAutoSavingHours = AppUsageTrackerUtil.convertSecondsToHours(totalAutoSavingSecond);
				if (totalAutoSavingHours < 0) {// todo
					totalAutoSavingHours = totalAutoSavingHours * -1;
				}
				if (StringUtils.isNotBlank(vo.getOnShoreOffshore())
						&& AppUsageTrackerConstant.OFF_SHORE.equalsIgnoreCase(vo.getOnShoreOffshore())) {
					autoSaving = offshoreRate.multiply(BigDecimal.valueOf(totalAutoSavingSecond));
				} else if (StringUtils.isNotBlank(vo.getOnShoreOffshore())
						&& AppUsageTrackerConstant.ON_SHORE.equalsIgnoreCase(vo.getOnShoreOffshore())) {
					autoSaving = onshoreRate.multiply(BigDecimal.valueOf(totalAutoSavingSecond));
				} else {
					autoSaving = autoSaving.multiply(BigDecimal.valueOf(0));
				}

				// autoSaving = autoSaving.setScale(2,RoundingMode.HALF_UP);
				TmgUserDetailsVO voUObj = getUserDetails(vo.getCreatedBy());
				String tower = "";
				String location = "";
				String name = "";
				String project = "";
				if (voUObj != null) {
					tower = voUObj.getTower() != null ? voUObj.getTower() : vo.getTowerName();
					location = voUObj.getLocation() != null ? voUObj.getLocation() : vo.getOnShoreOffshore();
					name = voUObj.getAssociateName();
					project = voUObj.getProject() != null ? voUObj.getProject()
							: (vo.getProjectName() != null ? vo.getProjectName() : "");
				} else {
					tower = vo.getTowerName();
					location = vo.getOnShoreOffshore();
					name = vo.getCreatedBy();
					project = vo.getProjectName() != null ? vo.getProjectName() : "";
				}
				String cat = enu.getTxCategory();
				String cfg = vo.getCfgName();
				
				if (!chckbxInclude.isSelected() && !"Shared Service".equalsIgnoreCase(tower)
						&& (( cat.equals("Miscellaneous Task") ))//cat.equals("Test Design") ||
						|| lstUser.contains(vo.getCreatedBy()) || project.toLowerCase().equals("test")
						|| (StringUtils.isNotBlank(cfg) && cfg.length() <= 4) && project.length() <= 3
						){
					continue;
				}
				
				autoSaving = getCorrectedSavings(autoSaving, tower);
				
				modelSaving.addRow(new Object[] {
						vo.getCreatedDate() != null ? AppUsageTrackerUtil.getFormatedDate(vo.getCreatedDate()) : "",
						tower, vo.getAppName(), cat, vo.getModuleName(), vo.getTransactionType(),
						project, vo.getCfgName(), vo.getLobNmae(), location, name, vo.getTranTotalCount(),
						(vo.getAcceptFlag() != null && vo.getAcceptFlag().equals("Y")) ? vo.getAcceptedRecCount()
								: vo.getTranTotalCount(),
						AppUsageTrackerUtil.convertSecondsToHHMMSS(totalExeTimeInSecond),
						AppUsageTrackerUtil.convertSecondsToHHMMSS(totalManEffInSecond),
						AppUsageTrackerUtil.convertSecondsToHHMMSS(totalManAftAutEffInSecond),
						AppUsageTrackerUtil.convertSecondsToHHMMSS(totalAutoSavingSecond), totalAutoSavingSecond,
						"$" + autoSaving.setScale(2, RoundingMode.HALF_UP) });
				totalROIAutoSaving = totalROIAutoSaving.add(autoSaving);
				totalROIAutoSavingSecond += totalAutoSavingSecond;
			}
			tbleSaving.setModel(modelSaving);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
//			pgbSavingCal.setIndeterminate(false);
			lblROITotalSavingAmount.setText("$ " + totalROIAutoSaving.setScale(2, RoundingMode.HALF_UP).toString());
			lblROITotalHurs.setText(AppUsageTrackerUtil.convertSecondsToHHMMSS(totalROIAutoSavingSecond));
		}
		LOG.info("ROI Search Completed.....");
	}

	private BigDecimal getCorrectedSavings(BigDecimal saving, String tower) {
		if ("Configuration".equalsIgnoreCase(tower)) {
			if (isBetweenSafe(saving, new BigDecimal("600"), new BigDecimal("750"))) {
				saving = new BigDecimal("600");
			} else if (isBetweenSafe(saving, new BigDecimal("751"), new BigDecimal("1000"))) {
				saving = new BigDecimal("700");
			} else if (isBetweenSafe(saving, new BigDecimal("1001"), new BigDecimal("5000"))) {
				saving = new BigDecimal("740");
			} else if (isBetweenSafe(saving, new BigDecimal("5001"), new BigDecimal("15000"))) {
				saving = new BigDecimal("950");
			} else if (isBetweenSafe(saving, new BigDecimal("15001"), new BigDecimal("30000"))) {
				saving = new BigDecimal("1050");
			} else if (isBetweenSafe(saving, new BigDecimal("30001"), new BigDecimal("40000"))) {
				saving = new BigDecimal("1200");
			} else if (saving.doubleValue() > 40000) {
				saving = new BigDecimal("1300");
			}
		} else if (!"Claims".equalsIgnoreCase(tower)){
			if (isBetweenSafe(saving, new BigDecimal("5001"), new BigDecimal("15000"))) {
				saving = new BigDecimal("2000");
			} else if (isBetweenSafe(saving, new BigDecimal("15001"), new BigDecimal("30000"))) {
				saving = new BigDecimal("3000");
			} else if (isBetweenSafe(saving, new BigDecimal("30001"), new BigDecimal("40000"))) {
				saving = new BigDecimal("4000");
			} else if (saving.doubleValue() > 40000) {
				saving = new BigDecimal("5000");
			}
		}else {
			LOG.info("Tower Name: {} \t saving: {}", tower, saving);
		}
		return saving;

	}

	public static boolean isBetweenSafe(BigDecimal value, BigDecimal min, BigDecimal max) {

		if (value == null || min == null || max == null) {
			return false;
		}

		return value.compareTo(min) >= 0 && value.compareTo(max) <= 0;
	}

	private boolean checkTransaction(BaaC360AppTransactionType enu) {
		return !enu.getName().equals("BS_Config_Validation") && !enu.getName().equals("NS_Config_Validation")
				&& !enu.getName().equals("FS_Schedule_Validation") && !enu.getName().equals("FDI XWalk Validation")
				&& !enu.getName().equals("QNXT BS_Config_Validation")
				&& !enu.getName().equals("QNXT_FS_Schedule_Validation")
				&& !enu.getName().equals("Intake 999 277CA Validation")
				&& !enu.getName().equals("Validate KWD ALT File")
				&& !enu.getName().equals("Accum_Outbound_Report_Validation")
				&& !enu.getName().equals("Over_Accum__Report_Validation")
				&& !enu.getName().equals("Validate Provider Match") && !enu.getName().equals("Validate Member Match")
				&& !enu.getName().equals("278 File Validation");
	}

	private int getTotalRecordCount(AppUsageTrackerVO vo) {
		int totalcount = 0;
		if ((vo.getAcceptFlag() != null && vo.getAcceptFlag().equals("Y"))) {
			totalcount = vo.getAcceptedRecCount();
		} else {
			totalcount = vo.getTranTotalCount();
		}
		return totalcount;
	}

	private void populateTransactionDetails(JTable table) {
		modelTransaction = (DefaultTableModel) table.getModel();
		modelTransaction.setRowCount(0);
		AppUsageTrackerFetch af = new AppUsageTrackerFetch();
		String username = txtUsername.getText().trim();
		List<String> appList = appListBox.getSelectedValuesList();
		if (appList.toString().contains("ALL"))
			appList.remove(0);
		List<String> moduleList = moduleListBox.getSelectedValuesList();
		if (moduleList.toString().contains("ALL"))
			moduleList.remove(0);
		List<String> tranList = tranListBox.getSelectedValuesList();
		if (tranList.toString().contains("ALL"))
			tranList.remove(0);
		String js = null;
		String strfromdate = ((JTextField) txtFromDate.getDateEditor().getUiComponent()).getText();
		String strtodate = ((JTextField) txtToDate.getDateEditor().getUiComponent()).getText();
		try {
			LOG.info(appListBox.getSelectedValuesList().toString());
			if (!username.equals("") && !appListBox.getSelectedValuesList().isEmpty()) {
				js = af.findByUserandAppname(AppProperties.getString("api.url.all"), username,
						String.join(",", appListBox.getSelectedValuesList()));

			} else if (!username.equals("") && !strfromdate.equals("")) {
				js = af.findByUserFromToDate(AppProperties.getString("api.url.user.date"), username, strfromdate,
						strtodate);
			} else {
				js = af.findall(AppProperties.getString("api.url.aut.all"));
			}
			LOG.info(js);
			ObjectMapper om = new ObjectMapper();
			List<AppUsageTrackerVO> resLst = om.readValue(js, new TypeReference<List<AppUsageTrackerVO>>() {
			});
			for (int i = 0; i < resLst.size(); i++) {
				AppUsageTrackerVO vo = resLst.get(i);
				modelTransaction.addRow(new Object[] { vo.getCreatedBy(), vo.getAppName(),
						vo.getCreatedDate() != null ? sdfDestination.format(vo.getCreatedDate()) : "",
						vo.getModuleName(), vo.getTransactionType(), vo.getTranTotalCount(), vo.getTotalExeTime(),
						vo.getTranStatus(), vo.getTranRemarks() });

			}
			table.setModel(modelTransaction);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static TmgUserDetailsVO getUserDetails(String assID) {
		TmgUserDetailsVO voObj = null;
		TMGUserDetailsFetch af = new TMGUserDetailsFetch();
		String js = "";
		try {
			js = af.findByUserDetails(AppProperties.getString("api.url.fetch.tmg.user.details"), assID);
			if (js != null) {
				ObjectMapper om = new ObjectMapper();
				voObj = om.readValue(js, new TypeReference<TmgUserDetailsVO>() {
				});
			}
		} catch (IOException e) {
			return voObj;
			// e.printStackTrace();
		}
		return voObj;

	}

	public void getEnumList() {
		EnumSet<BaaC360ApplicationName> colorEnumSet = EnumSet.allOf(BaaC360ApplicationName.class);
		appList = new HashSet<BaaC360ApplicationName>(colorEnumSet);
		EnumSet<BaaC360ApplicationModule> modEnumSet = EnumSet.allOf(BaaC360ApplicationModule.class);
		moduleNameList = new HashSet<BaaC360ApplicationModule>(modEnumSet);
		EnumSet<BaaC360AppTransactionType> tranEnumSet = EnumSet.allOf(BaaC360AppTransactionType.class);
		tranTypeList = new HashSet<BaaC360AppTransactionType>(tranEnumSet);
		loadListBoxModel(lstBoxAppListModel, appListBox, "app");
		loadListBoxModel(lstBoxmoduleListModel, moduleListBox, "module");
		loadListBoxModel(lstBoxTransListModel, tranListBox, "tran");
	}

	private void loadListFilter(DefaultListModel<String> lstBoxModel, JList<String> listBox, String type,
			JList<String> listSeleBox, JList<String> listtSeleBox) {
		List<String> lstsele = listSeleBox.getSelectedValuesList();
		List<String> listtSele = listtSeleBox.getSelectedValuesList();
		try {
			if (lstBoxModel.size() > 1) {
				lstBoxModel.removeRange(1, lstBoxModel.size() - 1);
			}
			int[] indices = null;
			if (type.equals("app")) {
				for (BaaC360ApplicationName id : appList) {
					lstBoxModel.addElement(id.getName());
				}
				indices = new int[appList.size() + 1];
				indices[0] = 0;
				for (int i = 1; i <= appList.size(); i++) {
					indices[i] = i;
				}
			} else if (type.equals("module")) {
				for (BaaC360ApplicationModule id : moduleNameList) {
					if (lstsele.isEmpty()) {
						lstBoxModel.addElement(id.getName());
					} else if (lstsele.contains(id.getAppName())) {
						lstBoxModel.addElement(id.getName());
					}
				}
				indices = new int[moduleNameList.size() + 1];
				indices[0] = 0;
				for (int i = 1; i <= moduleNameList.size(); i++) {
					indices[i] = i;
				}
			} else if (type.equals("tran")) {
				for (BaaC360AppTransactionType id : tranTypeList) {
					if (lstsele.isEmpty() && listtSele.isEmpty()) {
						lstBoxModel.addElement(id.getName());
					} else if (!lstsele.isEmpty() && lstsele.contains(id.getAppName()) && !listtSele.isEmpty()
							&& listtSele.contains(id.getModuleName())) {
						lstBoxModel.addElement(id.getName());
					} else if (!lstsele.isEmpty() && lstsele.contains(id.getAppName()) && listtSele.isEmpty()) {
						lstBoxModel.addElement(id.getName());
					} else if (!listtSele.isEmpty() && listtSele.contains(id.getModuleName()) && lstsele.isEmpty()) {
						lstBoxModel.addElement(id.getName());
					}
				}
				indices = new int[tranTypeList.size() + 1];
				indices[0] = 0;
				for (int i = 1; i <= tranTypeList.size(); i++) {
					indices[i] = i;
				}
			}
			if (listBox != null && listBox.getModel().getSize() >= indices.length) {
				if (listBox != null) {
					listBox.setSelectedIndices(indices);
				}
			}
		} catch (Exception ex) {
			LOG.error("Error on loadListBoxModel and error message: " + ex.getMessage());
			ex.printStackTrace();
		}
	}

	private void loadListBoxModel(DefaultListModel<String> lstBoxModel, JList<String> listBox, String type) {
		try {
			if (lstBoxModel.size() > 1) {
				lstBoxModel.removeRange(1, lstBoxModel.size() - 1);
			}
			int[] indices = null;
			if (type.equals("app")) {
				for (BaaC360ApplicationName id : appList) {
					lstBoxModel.addElement(id.getName());
				}
				indices = new int[appList.size() + 1];
				indices[0] = 0;
				for (int i = 1; i <= appList.size(); i++) {
					indices[i] = i;
				}
			} else if (type.equals("module")) {
				for (BaaC360ApplicationModule id : moduleNameList) {
					lstBoxModel.addElement(id.getName());
				}
				indices = new int[moduleNameList.size() + 1];
				indices[0] = 0;
				for (int i = 1; i <= moduleNameList.size(); i++) {
					indices[i] = i;
				}
			} else if (type.equals("tran")) {
				for (BaaC360AppTransactionType id : tranTypeList) {
					lstBoxModel.addElement(id.getName());
				}
				indices = new int[tranTypeList.size() + 1];
				indices[0] = 0;
				for (int i = 1; i <= tranTypeList.size(); i++) {
					indices[i] = i;
				}
			}
			if (listBox != null && listBox.getModel().getSize() >= indices.length) {
				if (listBox != null) {
					listBox.setSelectedIndices(indices);
				}
			}
		} catch (Exception ex) {
			LOG.error("Error on loadListBoxModel and error message: " + ex.getMessage());
			ex.printStackTrace();
		}
	}

	private void addTabPanelMouseListner(JTabbedPane tabbedNXPane) {
		tabbedNXPane.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent e) {
			}

			public void mousePressed(MouseEvent e) {
			}

			public void mouseExited(MouseEvent e) {
			}

			public void mouseEntered(MouseEvent e) {
			}

			public void mouseClicked(MouseEvent e) {
				e.getSource();
			}
		});
	}

	private void selectAllAppListElements(Set<BaaC360ApplicationName> appList2) {
		int[] indices = new int[appList2.size() + 1];
		indices[0] = 0;
		for (int i = 1; i <= appList2.size(); i++) {
			indices[i] = i;
		}
		appListBox.setSelectedIndices(indices);
	}

	private void selectAllSavingAppListElements(Set<BaaC360ApplicationName> appList2) {
		int[] indices = new int[appList2.size() + 1];
		indices[0] = 0;
		for (int i = 1; i <= appList2.size(); i++) {
			indices[i] = i;
		}
		appSavingListBox.setSelectedIndices(indices);
	}

	private void selectAllmodListElements(Set<BaaC360ApplicationModule> appList2) {
		int[] indices = new int[appList2.size() + 1];
		indices[0] = 0;
		for (int i = 1; i <= appList2.size(); i++) {
			indices[i] = i;
		}
		moduleSavingListBox.setSelectedIndices(indices);
	}

	private void selectAlltranListElements(Set<BaaC360AppTransactionType> appList2) {
		int[] indices = new int[appList2.size() + 1];
		indices[0] = 0;
		for (int i = 1; i <= appList2.size(); i++) {
			indices[i] = i;
		}
		tranSavingListBox.setSelectedIndices(indices);
	}

	public static String listtoString(List<String> list) {
		String strvalue = "";
		for (String str : list) {
			strvalue = strvalue + SINGLE_CODE + str + "' ,";
		}
		return strvalue.length() > 0 ? strvalue.substring(0, strvalue.length() - 1) : "";

	}

	public static int getManeff(int totrecCount) {
		int totmaneff = 0;
		if (isBetweenSafe(new BigDecimal(totrecCount), new BigDecimal(1), new BigDecimal(2000))) {
			totmaneff = 7200;
		} else if (isBetweenSafe(new BigDecimal(totrecCount), new BigDecimal(2001), new BigDecimal(5000))) {
			totmaneff = 12600;
		} else if (isBetweenSafe(new BigDecimal(totrecCount), new BigDecimal(5001), new BigDecimal(10000))) {
			totmaneff = 21600;
		} else if (Double.valueOf(totrecCount) > 10000) {
			totmaneff = 32400;
		}
		return totmaneff;
	}

	public static int getpostAManeff(int totrecCount) {
		int totAmaneff = 0;
		if (isBetweenSafe(new BigDecimal(totrecCount), new BigDecimal(1), new BigDecimal(2000))) {
			totAmaneff = 2400;
		} else if (isBetweenSafe(new BigDecimal(totrecCount), new BigDecimal(2001), new BigDecimal(5000))) {
			totAmaneff = 3960;
		} else if (isBetweenSafe(new BigDecimal(totrecCount), new BigDecimal(5001), new BigDecimal(10000))) {
			totAmaneff = 7560;
		} else if (Double.valueOf(totrecCount) > 10000) {
			totAmaneff = 11160;
		}
		return totAmaneff;
	}
}
