package com.cts.baac360.app.thread;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cts.baac360.app.model.AppUsageTrackerVO;
import com.cts.baac360.app.model.InputData;

public class AppUsageTrackerUpdateWorker implements Runnable {
	private static final Logger LOG = LoggerFactory.getLogger(AppUsageTrackerUpdateWorker.class);

	private final String apiURL;
	private final AppUsageTrackerVO appUsageTrackerVO;
	private ResponseEntity<AppUsageTrackerVO> response = null;

	private AppUsageTrackerUpdateWorker(String userId, String userName, String appName, String moduleName,
			String transactionType, int tranTotalCount, String tranStatus, String tranRemarks, String apiURL,
			Date createdDate, Date updatedDate, String createdBy, String totalExeTime) {
		this.apiURL = apiURL;
		this.appUsageTrackerVO = new AppUsageTrackerVO(userId, userName, appName, moduleName, transactionType,
				tranTotalCount, tranStatus, tranRemarks, createdDate, updatedDate, createdBy, totalExeTime,
				InputData.getproject(), InputData.getlob(), InputData.getcfg(), InputData.gettower(),
				InputData.getType(), 0,"N");
	}

	@Override
	public void run() {
		try {
			LOG.info("Worker thread started for updating AppUsageTracker via web service");

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.set("Content-Type", "application/json");
			HttpEntity<AppUsageTrackerVO> requestEntity = new HttpEntity<>(appUsageTrackerVO, headers);

			response = restTemplate.exchange(apiURL, HttpMethod.POST, requestEntity, AppUsageTrackerVO.class);

			if (response.getStatusCode().is2xxSuccessful()) {
				LOG.info("Worker thread completed for updating AppUsageTracker via web service");
			} else {
				LOG.error("Failed to update AppUsageTracker via web service: " + response.getStatusCode());
			}
		} catch (Exception e) {
			LOG.error("Error occurred while updating AppUsageTracker via web service: " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public static ResponseEntity<AppUsageTrackerVO> updateApplicationUsage(String userId, String userName,
			String appName, String moduleName, String transactionType, int tranTotalCount, String tranStatus,
			String tranRemarks, String apiURL, Date createdDate, Date updatedDate, String createdBy,
			String totalExeTime) throws Exception {
		AppUsageTrackerUpdateWorker worker = new AppUsageTrackerUpdateWorker(userId, userName, appName, moduleName,
				transactionType, tranTotalCount, tranStatus, tranRemarks, apiURL, createdDate, updatedDate, createdBy,
				totalExeTime);
		try {
			worker.run();
			LOG.info("Response Payload: " + worker.getResponse().getBody().toString());
		} catch (Exception e) {
			throw new Exception(e);
		}
		return worker.getResponse();
	}

	@SuppressWarnings("null")
	public static void main(String[] args) {
		// Sample usage
		ResponseEntity<AppUsageTrackerVO> response = null;
		try {
			LOG.info("Response Payload: " + response.getBody().toString());
			LOG.info("Response Status: " + response.getStatusCode());
			LOG.info("Response Headers: " + response.getHeaders());
			LOG.info("Response Status Code Value: " + response.getStatusCodeValue());
			LOG.info("Reason Phrase:" +((HttpStatus) response.getStatusCode()).getReasonPhrase());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ResponseEntity<AppUsageTrackerVO> getResponse() {
		return response;
	}

	public void setResponse(ResponseEntity<AppUsageTrackerVO> response) {
		this.response = response;
	}
}
