package com.cts.baac360.app.common;

public enum BaaC360AppTransactionType {
	DEFAULT("DEFAULT", "DEFAULT", "DEFAULT", "DEFAULT", "Test Design", "0", "0"),
	INTERMEDIATORY_SHEET_CREATE("Benefit Studio", "Benefit Configuration Testing", "Intermediatory Sheet Create",
			"Intermediatory Sheet Create", "Miscellaneous Task", "0", "0"),
	BS_CONFIG_VALIDATION("Benefit Studio", "Benefit Configuration Testing", "BS_Config_Validation",
			"Benefit Studio Configuration Validation", "Test Execution", "240", "120"),
	BS_CLAIMS_GENERATION("Benefit Studio", "Benefit Claims Testing", "BS_Claims_Generation",
			"Benefit Studio Claims Generation", "Test Data", "0", "0"),
	BS_EDI_GENERATION("Benefit Studio", "Benefit Claims Testing", "Benefit_EDI_Creation",
			"Benefit Claims EDI File Generation", "Test Data", "0", "0"),
	BS_CLAIMS_lOAD("Benefit Studio", "Benefit Claims Testing", "BS_Claims_Loading", "Benefit Studio Claims Loading",
			"Test Data", "15", "5"),
	BS_CLAIMS_COSTSAHRE_VALIDATION("Benefit Studio", "Benefit Claims Testing", "BS_Claims_CostSahre_Validation",
			"Benefit Studio Claims Cost Share Validation", "Test Execution", "20", "7"),
	BS_TPI_REPORT("Benefit Studio", "Benefit Claims Testing", "BS_TPI_Report_GeneSration",
			"Benefit Studio TPI Report Generation", "Test Data", "0", "0"),
	NS_CONFIG_VALIDATION("NetworX Studio", "Networx Configuration Testing", "NS_Config_Validation",
			"NetworX Configuration Validation", "Test Execution", "240", "120"),
	NS_DESIGN_DOC_LOADING("NetworX Studio", "Networx Configuration Testing", "NS_Design_Doc_Loading",
			"NetworX Design Document Loading", "Miscellaneous Task", "0", "0"),
	NS_IMPORT_AGREEMENTS("NetworX Studio", "Networx Configuration Testing", "NS_Import_Agreement",
			"NetworX Import Agreement From DB", "Miscellaneous Task", "0", "0"),
	NS_CLAIMS_GENERATION("NetworX Studio", "Networx Claims Testing", "NS_Claims_Generation",
			"NetworX Claims Generation Based on the Scenarios", "Test Data", "0", "0"),
	NS_PROD_CLAIMS_GENERATION("NetworX Studio", "Networx Claims Testing", "NS_Prod_Claims_Generation",
			"NetworX Prod Claims Generation", "Test Data", "0", "0"),
	NS_TEST_CASE_GENERATION("NetworX Studio", "Networx Claims TestCase", "NS_TestCase_Generation",
			"NetworX Test Case Generation", "Test Design", "60", "10"),
	NS_CLAIMS_LOADING("NetworX Studio", "Networx Claims Testing", "NS_Claims_Loading", "NetworX Studio Claims Loading",
			"Test Data", "15", "5"),
	NS_TPI_REPORT("NetworX Studio", "Networx Claims Testing", "NS_TPI_Report_GeneSration",
			"NetworX Studio TPI Report Generation", "Miscellaneous Task", "0", "0"),
	NS_CLAIMS_PRICING_VALIDATION("NetworX Studio", "Networx Claims Testing", "NS_Claims_Pricing_Validation",
			"NetworX Studio Claims Pricing Validation", "Test Execution", "20", "7"),
	NS_COM_GRID_VALIDATION("NetworX Studio", "Networx Configuration Testing", "NS_Com_Grid_Validation",
			"NetworX Studio ComGrid Validation", "Test Execution", "30", "5"),
	FS_VALIDATION("Fees Schedule Studio", "Fee Schedule Configuration Testing", "FS_Schedule_Validation",
			"FeeSchdule  Validation", "Test Execution", "240", "20"),
	FS_LOADING("Fees Schedule Studio", "Fee Schedule Configuration Testing", "FS_Schedule_LOADING",
			"FeeSchdule  Loading", "Miscellaneous Task", "0", "0"),
	FS_CLAIMS_GENERATION("Fees Schedule Studio", "Fee Schedule Claims Testing", "FS_Schedule_Claims_Generation",
			"FeeSchdule  Claims Generation", "Test Data", "0", "0"),
	FS_CLAIMS_LOADING("Fees Schedule Studio", "Fee Schedule Claims Testing", "FS_Schedule_Claims_Loading",
			"FeeSchdule  Claims Loading", "Test Data", "15", "5"),
	FS_CLAIMS_PRICING_VALIDATION("Fees Schedule Studio", "Fee Schedule Claims Testing",
			"FS_Schedule_Claims_Pricing_Validation", "FeeSchdule  Pricing Validation", "Test Execution", "20", "7"),
	EDI_834_ADD_MEM("TMG Enroll Legacy", "Enrollment", "Add Member Transaction", "Enroll new member", "Test Execution",
			"0", "0"),
	EDI_834_CHG_MEM("TMG Enroll Legacy", "Enrollment", "Change Member Details Transaction",
			"Change details of given member", "Test Execution", "0", "0"),
	EDI_834_TERMORCANCEL_MEM("TMG Enroll Legacy", "Enrollment", "Term Member Transaction", "Term an active member",
			"Test Execution", "0", "0"),
	EDI_834_REINSTATE_MEM("TMG Enroll Legacy", "Enrollment", "Reinstate Member Transaction",
			"Reinstate the termed member", "Test Execution", "0", "0"),
	CS_CLAIMS_GENERATION("Claims Studio", "Claims Testing", "CS_Claims_Generation", "Scenario Based Claims Generation",
			"Test Data", "0", "0"),
	CS_PROD_CLAIMS_GENERATION("Claims Studio", "Claims Testing", "CS_Prod_Claims_Generation", "Prod Claims Generation",
			"Test Data", "0", "0"),
	CS_CLAIMS_LOAD("Claims Studio", "Claims Testing", "CS_Claims_Loading", "Claims Studio Claims Loading",
			"Test Data", "20", "5"),
	CS_EDI_GENERATION("Claims Studio", "Claims Testing", "ClaimsStudio_EDI_Generation", "EDI File Generation",
			"Test Data", "0", "0"),
	CS_PROVIDER_COPY_CREATION("Claims Studio", "Provider_Creation", "Copy_Provider", "Copy Provider Creation",
			"Test Execution", "20", "5"),
	CS_PROVIDER_NEW_CREATION("Claims Studio", "Provider_Creation", "New_Provider_Creation", "New Provider Creation",
			"Test Execution", "20", "5"),
	CS_IMPORT_AGREEMENT("Claims Studio", "Claims Testing", "Import_Agreement_Data", "Import Agreement Data",
			"Test Design", "0", "0"),
	CS_IMPORT_FEESCHEDULE("Claims Studio", "Claims Testing", "Import_FeeSchedule_Data", "Import FeeSchedule Data",
			"Test Design", "0", "0"),
	CS_IMPORT_CLAIMS_SCENARIOS("Claims Studio", "Claims Testing", "Importing_Claims_Scenarios",
			"Import Claims Scenario", "Test Design", "0", "0"),
	CS_BENCHMARK_CLAIMS_GENERATION("Claims Studio", "Claims Testing", "Benchmark_claims_Generation",
			"Benchmark Claims Generation", "Test Execution", "20", "5"),
	CS_ADDING_CLAIMS_SCENARIOS("Claims Studio", "Claims Testing", "Adding_Scenarios", "Adding Claims Scenarios",
			"Miscellaneous Task", "0", "0"),
	QN_FS_VALIDATION("QNXT Fees Schedule Studio", "QNXT Fee Schedule Configuration Testing",
			"QNXT_FS_Schedule_Validation", "QNXT FeeSchdule  Validation", "Test Execution", "240", "20"),
	QN_FS_LOADING("QNXT Fees Schedule Studio", "QNXT Fee Schedule Configuration Testing", "QNXT_FS_Schedule_LOADING",
			"QNXT FeeSchdule  Loading", "Miscellaneous Task", "0", "0"),
	QN_FS_CLAIMS_GENERATION("QNXT Fees Schedule Studio", "QNXT Fee Schedule Claims Testing",
			"QNXT_FS_Schedule_Claims_Generation", "QNXT FeeSchdule  Claims Generation", "Test Data", "0", "0"),
	QN_FS_CLAIMS_LOADING("QNXT Fees Schedule Studio", "QNXT Fee Schedule Claims Testing",
			"QNXT_FS_Schedule_Claims_Loading", "QNXT FeeSchdule  Claims Loading", "Test Data", "20", "7"),
	QN_FS_CLAIMS_PRICING_VALIDATION("QNXT Fees Schedule Studio", "QNXT Fee Schedule Claims Testing",
			"QNXT_FS_Schedule_Claims_Pricing_Validation", "QNXT FeeSchdule  Pricing Validation", "Test Execution", "20",
			"7"),
	QNXT_BS_CONFIG_VALIDATION("QNXT Benefit Studio", "QNXT Benefit Configuration Testing", "QNXT BS_Config_Validation",
			"QNXT Benefit Studio Configuration Validation", "Test Execution", "240", "120"),
	QNXT_BS_CLAIMS_GENERATION("QNXT Benefit Studio", "QNXT Benefit Claims Testing", "QNXT BS_Claims_Generation",
			"QNXT Benefit Studio Claims Generation", "Test Data", "0", "0"),
	QNXT_BS_EDI_GENERATION("QNXT Benefit Studio", "QNXT Benefit Claims Testing", "QNXT Benefit_EDI_Creation",
			" QNXTBenefit Claims EDI File Generation", "Test Data", "0", "0"),
	QNXT_BS_CLAIMS_lOAD("QNXT Benefit Studio", "QNXT Benefit Claims Testing", "QNXT BS_Claims_Loading",
			"QNXT Benefit Studio Claims Loading", "Test Data", "15", "5"),
	QNXT_BS_CLAIMS_COSTSAHRE_VALIDATION("QNXT Benefit Studio", "QNXT Benefit Claims Testing",
			"QNXT BS_Claims_CostShare_Validation", "QNXT Benefit Studio Claims Cost Share Validation", "Test Execution",
			"20", "7"),
	QN_NS_CONFIG_VALIDATION("QNXT NetworX Studio", "QNXT Networx Configuration Testing", "QNXT_NS_Config_Validation",
			"QNXT NetworX Configuration Validation", "Test Execution", "240", "120"),
	QN_NS_DESIGN_DOC_LOADING("QNXT NetworX Studio", "QNXT Networx Configuration Testing", "QNXT_NS_Design_Doc_Loading",
			"QNXT NetworX Design Document Loading", "Test Design", "60", "20"),
	QN_NS_IMPORT_AGREEMENTS("QNXT NetworX Studio", "QNXT Networx Configuration Testing", "QNXT_NS_Import_Agreement",
			"QNXT NetworX Import Agreement From DB", "Test Data", "10", "10"),
	QN_NS_TEST_CASE_GENERATION("QNXT NetworX Studio", "QNXT Networx Claims Testing", "QNXT_NS_TestCase_Generation",
			"QNXT NetworX Test Case Generation", "Test Design", "20", "05"),
	QN_NS_CLAIMS_GENERATION("QNXT NetworX Studio", "QNXT Networx Claims Testing", "QNXT_NS_Claims_Generation",
			"QNXT NetworX Claims Generation Based on the Scenarios", "Test Data", "0", "0"),
	QN_NS_CLAIMS_LOADING("QNXT NetworX Studio", "QNXT Networx Claims Testing", "QNXT_NS_Claims_Loading",
			"QNXT NetworX Studio Claims Loading", "Test Data", "15", "5"),
	QN_NS_CLAIMS_PRICING_VALIDATION("QNXT NetworX Studio", "QNXT Networx Claims Testing",
			"QNXT_NS_Claims_Pricing_Validation", "QNXT NetworX Studio Claims Pricing Validation", "Test Execution",
			"20", "7"),
	QN_NS_CLAIMS_CALCULATE_PRICING("QNXT NetworX Studio", "QNXT Networx Claims Testing",
			"QNXT_NS_Claims_Calculate_Pricing", "QNXT NetworX Studio Claims Calculate Pricing", "Test Data", "0", "0"),
	QN_NS_MASS_ADJUDICATE_VALIDATION("QNXT NetworX Studio", "QNXT Networx Claims Testing",
			"QNXT_NS_Mass_Adjudicate_Validation", "QNXT NetworX Studio Claims Mass Adjudication", "Test Data", "0",
			"0"),
	AB_PARALLEL_VALIDATE_CONFIGURATION("Active Batch", "Active Batch Parallel Job Process", "AB_VALIDATE_CONFIGURATION",
			"Validate Configuration", "Test Execution", "0", "0"),
	AB_PARALLEL_VALIDATE_DIRECTORY("Active Batch", "Active Batch Parallel Job Process", "AB_VALIDATE_DIRECTORY",
			"Validate Directory", "Test Execution", "0", "0"),
	AB_PARALLEL_PREPROCESS_VALIDATE("Active Batch", "Active Batch Parallel Job Process", "AB_PREPROCESS_VALIDATE",
			"Pre-Process and Validate", "Test Data", "0", "0"),
	AB_PARALLEL_TRIGGERJOB_VALIDATE("Active Batch", "Active Batch Parallel Job Process", "AB_TRIGGERJOB_VALIDATE",
			"Trigger Job and Validate", "Test Execution", "0", "0"),
	AB_PARALLEL_SSISPACKAGE_TRIGGER_VALIDATE("Active Batch", "Active Batch Parallel Job Process",
			"AB_SSISPACKAGE_TRIGGER_VALIDATE", "SSIS Package Trigger and Validate", "Test Execution", "0", "0"),
	AB_PARALLEL_VIEWREPORT("Active Batch", "Active Batch Parallel Job Process", "AB_VIEWREPORT", "View Report",
			"Test Data", "0", "0"),
	AB_FUNCTIONAL_PREPROCESS("Active Batch", "Active Batch Functional Specific Job Process", "AB_PREPROCESS",
			"Pre-Process", "Test Data", "0", "0"),
	AB_FUNCTIONAL_VIEW_PREPROCESS_REPORT("Active Batch", "Active Batch Functional Specific Job Process",
			"AB_VIEW_PREPROCESS_REPORT", "View PreProcess Report", "Test Data", "0", "0"),
	AB_FUNCTIONAL_TRIGGERJOB_VALIDATE("Active Batch", "Active Batch Functional Specific Job Process",
			"AB_TRIGGERJOB_VALIDATE", "Trigger Job and Validate", "Test Execution", "0", "0"),
	AB_FUNCTIONAL_VIEWREPORTS("Active Batch", "Active Batch Functional Specific Job Process", "AB_FUNC_VIEWREPORTS",
			"View Report", "Test Data", "0", "0"),
	CLAIMSCREENSHOT("QNXT Claim UI Screenshot", "QNXT Claim UI Screenshot", "QNXT Claim UI Screenshot", "QNXT Claim UI Screenshot",
			"Test Data", "6", "3"),
	FINANCE_EXTRACT_UPDATE_NEXT_RUN_DATE("Finace Extract Validation","Finance Extract automation Testing","FINANCE_PAID_DATE_FROMDT_TODT_UPDATION_IN_RUNBOOK",
			"Processing the next run date and updation in xml", "Test Data", "0", "0"),
	FINANCE_VALIDATE_EXTRACT_DETAILS("Finace Extract Validation","Finance Extract automation Testing","FINACE_EXTRACT_JOB_VALIDATE",
			"Process the generated output and Validate the Extract", "Test Execution", "0", "0"),
	FINANCE_VIEW_REPORTS("Finace Extract Validation","Finance Extract automation Testing","FINANCE_VIEW_EXTRACT_REPORTS", "View Report", "Miscellaneous Task", "0", "0"),
	GENERATE_ENROLL_MEMBER_FILE("TMG Enroll Legacy", "Enrollment","Enrollment_File_Generation", "Generatin Enrollment file", "Test Execution", "15", "2"),
	VIEW_ENROLL_MEMBER_FILE("TMG Enroll Legacy", "Enrollment","View_Enrolled_File_Report", "View Report", "Miscellaneous Task", "0", "0"),
	ELIGIBILITY_JOB_TRIGGER("TMG Enroll Legacy", "Enrollment","TRIGGER_ELIGIBILITY_JOB_PROCESS", "Trigger Job and Validate", "Miscellaneous Task", "0", "0"),
	CMS_SUBMISSION_JOBS("TMG Enroll Legacy", "Enrollment","TRIGGER_CMS_SUBMISSION_JOB_PROCESS", "Trigger Job and Validate", "Miscellaneous Task", "0", "0"),
	GENERATE_BEQ_FILE("TMG Enroll Legacy", "Enrollment","BEQ_File_Generation", "Generating BEQ file", "Test Execution", "15", "2"),
	VIEW_BEQ_FILE("TMG Enroll Legacy", "Enrollment","View_BEQ_File_Report", "View Report", "Miscellaneous Task", "0", "0"),
	GENERATE_TRR_FILE("TMG Enroll Legacy", "Enrollment","TRR_File_Generation", "Generating TRR file", "Test Execution", "20", "2"),
	VIEW_TRR_FILE("TMG Enroll Legacy", "Enrollment","View_TRR_File_Report", "View Report", "Miscellaneous Task", "0", "0"),
	TRR_SUBMISSION_JOBS("TMG Enroll Legacy", "Enrollment","TRIGGER_TRR_SUBMISSION_JOB_PROCESS", "Trigger Job and Validate", "Miscellaneous Task", "0", "0"),
	VALIDATE_DB_TABLE("TMG Enroll Legacy", "Enrollment","XWALK_DB_Table_Validation", "Validation report is genrated for DB table(XWALK)",
			"Test Execution", "8", "1"),
	VIEW_DB_TABLE_REPORT("TMG Enroll Legacy", "Enrollment","View_DB_Valdated_File_Report", "View Report", "Miscellaneous Task", "0", "0"),
	VALIDATE_DAF_FILE("TMG Enroll Legacy", "Enrollment","DAF_File_Validation", "Validation report is genrated for DAF file", "Test Execution", "2", "1"),
	VIEW_DAF_FILE_REPORT("TMG Enroll Legacy", "Enrollment","View_DAF_File_Report", "View Report", "Miscellaneous Task", "0", "0"),
	VALIDATE_FULL_FILE("TMG Enroll Legacy", "Enrollment","Full_File_Validation", "Validation report is genrated for Full file", "Test Execution", "3", "1"),
	AEMEMB_Delimiter_Conversion("TMG Enroll Legacy", "Enrollment","Humana AEMEMB Delimiter Conversion", "Validation report is generated for Delimiter Conversion Client file", "Test Execution", "7", "1"),
	AEMEMB_SME_Validation("TMG Enroll Legacy", "Enrollment","AEMEMB_SME_Validation", "Validation report is generated for AEMEMB_SME_Validation file", "Test Execution", "6", "1"),
	SME_KeywordFile_Validation("TMG Enroll Legacy", "Enrollment","SME_KeywordFile_Validation", "Validation report is generated for SME_KeywordFile_Validation file", "Test Execution", "15", "1"),
	KeywordFile_FACETS_Validation("TMG Enroll Legacy", "Enrollment","KeywordFile_FACETS_Validation", "Validation report is generated for KeywordFile_FACETS_Validation file", "Test Execution", "5", "1"),
	FACETS_DAF_Validation("TMG Enroll Legacy", "Enrollment","FACETS_DAF_Validation", "Validation report is generated for FACETS_DAF_Validation file", "Test Execution", "5", "1"),

	QNXT_EAM_EAF_CREATION("QNXT EAM Application", "QNXT EAM Application", "QNXT EAM_File_Creation",
			"QNXT EAF File Creation", "Test Data", "15", "1"),
	QNXT_EAM_EAF_UPLOAD("QNXT EAM Application", "QNXT EAM Application", "QNXT EAM_File_Upload",
			"QNXT EAF File Upload", "Test Data", "0", "0"),
	QNXT_EAM_BEQ_CREATION("QNXT EAM Application", "QNXT EAM Application", "QNXT BEQ_File_Creation",
			"QNXT BEQ Inbound File Creation", "Test Data", "20", "1"),
	QNXT_EAM_BEQ_DOWNLOAD("QNXT EAM Application", "QNXT EAM Application", "QNXT BEQ_File_Download",
			"QNXT BEQ Outbound File Download", "Test Data", "0", "0"),
	QNXT_EAM_BEQ_UPLOAD("QNXT EAM Application", "QNXT EAM Application", "QNXT BEQ_File_Upload",
			"QNXT BEQ Inbound File Upload", "Test Data", "0", "0"),
	QNXT_EAM_CMS_DOWNLOAD("QNXT EAM Application", "QNXT EAM Application", "QNXT CMS_File_Download",
			"QNXT CMS Outbound File Download", "Test Data", "0", "0"),
	QNXT_EAM_TRR_CREATION("QNXT EAM Application", "QNXT EAM Application", "QNXT TRR_File_Creation",
			"QNXT TRR File Creation", "Test Data", "15", "1"),
	QNXT_EAM_TRR_UPLOAD("QNXT EAM Application", "QNXT EAM Application", "QNXT TRR_File_Upload",
			"QNXT TRR Inbound File Upload", "Test Data", "0", "0"),
	QNXT_EAM_VALIDATION("QNXT EAM Application", "QNXT EAM Member Validation", "QNXT EAM Member Validation",
			"QNXT EAM Member Validation", "Test Data", "0", "0"),
	QNXT_EAM_MEMBER_EXPORT("QNXT EAM Application", "QNXT Member Export", "QNXT EAM Member Export",
			"QNXT EAM Member Export", "Test Data", "0", "0"),
	QNXT_EAM_TRANSACTION_EXPORT("QNXT EAM Application", "QNXT Transaction Export", "QNXT EAM Transaction Export",
			"QNXT EAM Transaction Export", "Test Data", "0", "0"),
	VIEW_FULL_FILE_REPORT("TMG Enroll Legacy", "Enrollment","View_Full_File_Report", "View Report", "Miscellaneous Task", "0", "0"),
	AVAILTY_OUTPUT_REPORT("Availity Screenshot Tool", "Enrollment","Availity_BenefitGrid_Validation", "Validation report is generated for ServiceTypes", "Test Execution", "5", "1"),
	INVOICE_ACTIVE_VALIDATE("Invoice Validation", "Invoice Validation Testing","Validate Active Status", "Validate Active", "Test Execution", "15", "1"),
	INVOICE_SUSPEND_VALIDATE("Invoice Validation", "Invoice Validation Testing","Validate Suspend Status", "Validate Suspend Status", "Test Execution", "10", "1"),
	INVOICE_PLAN_VALIDATE("Invoice Validation", "Invoice Validation Testing","Validate Plan and product Status", "Validate Plan and product Status", "Test Execution", "10", "1"),
	INVOICE_FUTURE_DT_VALIDATE("Invoice Validation", "Invoice Validation Testing","Validate if Latest invoice generated", "Validate if Latest invoice generate", "Test Execution", "10", "1"),
	FHG_Create_EDI("FHG Application", "EDI Create or Mockup", "Generate EDI File", "Generate_EDI_File", "Test Data",
			"15", "5"),
	FHG_Intake_File_Copy("FHG Application", "EDI Intake Process", "837 File Copay", "837_File_Copy",
			"Miscellaneous Task", "0", "0"),
	FHG_Intake_837_JobTrigger("FHG Application", "EDI Intake Process", "837 Job Trigger", "837_Job_Trigger",
			"Miscellaneous Task", "0", "0"),
	FHG_Intake_999_277CA_Validation("FHG Application", "EDI Intake Process", "Intake 999 277CA Validation",
			"Intake_999_277CA_Validation", "Test Execution", "10", "3"),
	FHG_Intake_Validate_KWD_ALT_File("FHG Application", "EDI Intake Process", "Validate KWD ALT File",
			"Validate_KWD_ALT_File", "Test Execution", "5", "3"),
	FHG_Intake_Check_Rejected_Claims("FHG Application", "EDI Intake Process", "Check Rejected Claims",
			"Check_Rejected_Claims", "Test Execution", "5", "3"),
	FHG_Validate_Adjudicated_Claims("FHG Application", "837 vs Adjudicated Claims", "Validate Adjudicated Claims",
			"Validate_Adjudicated_Claim", "Test Data", "5", "3"),
	FHG_Generate_Corrected_Claims("FHG Application", "Corrected Claims", "Generate Corrected Claims",
			"Generate_Corrected_Claims", "Test Data", "15", "8"),
	FHG_Validate_Corrected_Claims("FHG Application", "Corrected Claims", "Validate Corrected Claims",
			"Validate_Corrected_Claims", "Test Execution", "10", "8"),
	FHG_Provider_BRD_Extraction("FHG Application", "Provider Match", "BRD Provider Extraction",
			"BRD_Provider_Extraction", "Miscellaneous Task", "0", "0"),
	FHG_Provider_Generate_EDI("FHG Application", "Provider Match", "Generate EDI Provider Match",
			"Generate_EDI_Provider_Match", "Test Data", "10", "3"),
	FHG_Provider_Report_Validation("FHG Application", "Provider Match", "Validate Provider Match",
			"Validate_Provider_Match", "Test Execution", "5", "3"),
	FHG_Member_BRD_Extraction("FHG Application", "Member Match", "BRD Member Extraction", "BRD_Member_Extraction",
			"Miscellaneous Task", "0", "0"),
	FHG_Mebmber_Generate_EDI("FHG Application", "Member Match", "Generate EDI Member Match",
			"Generate_EDI_Member_Match", "Test Data", "10", "3"),
	FHG_Member_Report_Validation("FHG Application", "Member Match", "Validate Member Match", "Validate_Member_Match",
			"Test Execution", "5", "3"),
	FHG_835_Validation("FHG Application", "835 Validation", "Validate 835 File", "Validate_835_File", "Test Execution",
			"0", "0"),
	FHG_275_File_Generation("FHG Application", "275 Validation", "Generate 275 File", "Generate_275_File", "Test Data",
			"10", "4"),
	FHG_275_File_Copy("FHG Application", "275 Validation", "275 File Copy", "275_File_Copy", "Miscellaneous Task", "0",
			"0"),
	FHG_278_File_Copy("FHG Application", "278 Validation", "278 File Copy", "278_File_Copy", "Miscellaneous Task", "0",
			"0"),
	FHG_278_File_Validation("FHG Application", "278 Validation", "278 File Validation", "278_File_Validation",
			"Test Execution", "15", "6"),
	CS_CLAIMS_LOAD_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT CS_Claims_Loading",
			"QNXT Claims Studio Claims Loading", "Test Data", "15", "5"),
	CS_CLAIMS_GENERATION_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT CS_Claims_Generation",
			"QNXT Scenario Based Claims Generation", "Test Data", "0", "0"),
	CS_PROD_CLAIMS_GENERATION_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT CS_Prod_Claims_Generation",
			"QNXT Prod Claims Generation", "Test Data", "0", "0"),
	CS_EDI_GENERATION_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT ClaimsStudio_EDI_Generation",
			"QNXT EDI File Generation", "Test Data", "0", "0"),
	CS_PROVIDER_COPY_CREATION_QNXT("QNXT Claims Studio", "QNXT Provider_Creation", "QNXT Copy_Provider",
			"QNXT Copy Provider Creation", "Test Execution", "20", "5"),
	CS_PROVIDER_NEW_CREATION_QNXT("QNXT Claims Studio", "QNXT Provider_Creation", "QNXT New_Provider_Creation",
			"QNXT New Provider Creation", "Test Execution", "20", "5"),
	CS_IMPORT_AGREEMENT_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT Import_Agreement_Data",
			"QNXT Import Agreement Data", "Test Design", "0", "0"),
	CS_IMPORT_FEESCHEDULE_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT Import_FeeSchedule_Data",
			"QNXT Import FeeSchedule Data", "Test Design", "0", "0"),
	CS_IMPORT_CLAIMS_SCENARIOS_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT Importing_Claims_Scenarios",
			"Import Claims Scenario", "Test Design", "0", "0"),
	CS_BENCHMARK_CLAIMS_GENERATION_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT Benchmark_claims_Generation",
			"Benchmark Claims Generation", "Test Execution", "15", "5"),
	CS_ADDING_CLAIMS_SCENARIOS_QNXT("QNXT Claims Studio", "QNXT Claims Testing", "QNXT Adding_Scenarios",
			"QNXT Adding Claims Scenarios", "Miscellaneous Task", "0", "0"),
	FDI_XWALK_VALIDATION("FDI XWalk Validation", "FDI XWalk Validation", "FDI XWalk Validation", "FDI XWalk Validation",
			"Test Data", "30", "15"),
	ACCUM_OUTBUND_JOB_TRIGGER("AccumsOutbound", "Accum_Outbound_Validation", "Accum_Outbound_Job_Trigger", "Accum Outbound Job Trigger",
			"Miscellaneous Task", "0", "0"),
	ACCUM_OUTBUND_VALIDATION("AccumsOutbound", "Accum_Outbound_Validation", "Accum_Outbound_Report_Validation", "Accum Outbound Report Validation",
			"Test Execution", "20", "10"),
	OVER_ACCUM_JOB_TRIGGER("AccumsOutbound", "Over_Accum_Validation", "Over_Accum_Job_Trigger", "Over Accum Job Trigger",
			"Miscellaneous Task", "0", "0"),
	OVER_ACCUM_VALIDATION("AccumsOutbound", "Over_Accum_Validation", "Over_Accum__Report_Validation", "Over Accum Report Validation",
			"Test Execution", "20", "10"),
	CMS_OEC_ENROLL_GENERATION("CMS OEC Converter Enrollment Application","CMS OEC Enrollment File Process","CMS_OEC_ENROLL_GENERATION","CMS_OEC_ENROLL_GENERATION","Test Data","15","2"),
	LOCKBOX_FILE_CREATION("LockBox File Creation","LockBox_File_Creation","LockBox_File_Creation","LockBox File Creation","Test Data","6","2"),
	FDI_MAESTRO_CROSSWALKCSVTESTCASE("Maestro Testcase Automation", "CrossWalk Testing", "CrossWalkCSVTestcase",
			"Updating Facets ext Crosswalks via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_CROSSWALKEDITTESTCASE("Maestro Testcase Automation", "CrossWalk Testing", "CrossWalkEditTestcase",
			"Updating Facets ext Crosswalks via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_CONFIGTABTESTCASE("Maestro Testcase Automation", "Config Testing", "ConfigTabTestcase",
			"Updating Maestro and FDI configs via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_ADMINFACETSNOTETRIGGERTESTCASE("Maestro Testcase Automation", "Admin Tab Testing", "AdminFacetsNoteTriggerTestcase",
			"Adding Notes to Facets via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_ADMINIDCARDTRIGGERTESTCASE("Maestro Testcase Automation", "Admin Tab Testing", "AdminIdCardTriggerTestcase",
			"Triggering ID Cards via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_ADMINLETTERTRIGGERTESTCASE("Maestro Testcase Automation", "Admin Tab Testing", "AdminLetterTriggerTestcase",
			"Triggering Letters via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_ADMINFDIDISCARDTESTCASE("Maestro Testcase Automation", "Admin Tab Testing", "AdminFDIDiscardTestcase",
			"Discarding Letters from FDI via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_ADMINFDINOTETESTCASE("Maestro Testcase Automation", "Admin Tab Testing", "AdminFDINoteTestcase",
			"Adding Notes to FDI via Maestro UI", "Test Execution", "10", "5"),
	FDI_MAESTRO_ADMINLETTERTRIGGERDELETETESTCASE("Maestro Testcase Automation", "Admin Tab Testing", "AdminLetterTriggerDeleteTestcase",
			"Discarding Letters from Facets via Maestro UI", "Test Execution", "10", "5"),
	BILLING_DOC_ID_REPORT_VALIDATE_MAPPING("Billing Doc Id extract Validation with Mapping Document", "Billing Doc Id extract Validation with Mapping Document Testing","Billing Doc Id extract Validation with Mapping Document", "Billing Doc Id extract Validation with Mapping Document", "Test Execution", "20", "1"),
	BILLING_DOC_ID_REPORT_VALIDATE_DB("Billing Doc Id extract Validation with DB", "Billing Doc Id extract Validation with DB Testing","Billing Doc Id extract Validation with DB", "Billing Doc Id extract Validation with DB", "Test Execution", "30", "1"),
	API_GEN_TESTCASE("API Testing Tool","Generate TestCase","Generate TestCase","Generate TestCase","Test Execution","5","1"),
	API_EXECUTESERVICES("API Testing Tool","Execute Services","Execute Services","Execute Services","Test Execution","5","1");
	
	String appName;
	String moduleName;
	String name;
	String descr;
	String txCategory;
	String mannualEffort;
	String mannualEffortAfterAutomation;

	private BaaC360AppTransactionType(String appName, String moduleName, String name, String descr, String txCategory,
			String mannualEffort, String mannualEffortAfterAutomation) {
		this.appName = appName;
		this.moduleName = moduleName;
		this.name = name;
		this.descr = descr;
		this.txCategory = txCategory;
		this.mannualEffort = mannualEffort;
		this.mannualEffortAfterAutomation = mannualEffortAfterAutomation;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getMannualEffort() {
		return mannualEffort;
	}

	public void setMannualEffort(String mannualEffort) {
		this.mannualEffort = mannualEffort;
	}

	public String getMannualEffortAfterAutomation() {
		return mannualEffortAfterAutomation;
	}

	public void setMannualEffortAfterAutomation(String mannualEffortAfterAutomation) {
		this.mannualEffortAfterAutomation = mannualEffortAfterAutomation;
	}

	public String getTxCategory() {
		return txCategory;
	}

	public void setTxCategory(String txCategory) {
		this.txCategory = txCategory;
	}

	public String getName() {
		return name;
	}

	public String getDescr() {
		return descr;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public static BaaC360AppTransactionType getBaaC360AppTransactionTypeByNmae(String name) {
		BaaC360AppTransactionType appTransactionType = null;
		if (name != null) {
			for (BaaC360AppTransactionType en : BaaC360AppTransactionType.values()) {
				if (en.getName() == null) {
					System.out.println();
				}
				if (name.equals(en.getName())) {
					appTransactionType = en;
					break;
				}
			}
		}
		return appTransactionType;
	}

}
