package com.cts.baac360.app.thread;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.cts.baac360.app.model.AppUsageTrackerVO;

public class AppUsageTrackerBulkUpdateWorker implements Runnable {
	private static final Logger LOG = LoggerFactory.getLogger(AppUsageTrackerBulkUpdateWorker.class);

	private final String apiURL;
	private final List<AppUsageTrackerVO> voList;
	private ResponseEntity<List<AppUsageTrackerVO>> response;

	public AppUsageTrackerBulkUpdateWorker(String apiURL, List<AppUsageTrackerVO> voList) {
		this.apiURL = apiURL;
		this.voList = voList;
	}

	@Override
	public void run() {
		try {
			RestTemplate restTemplate = new RestTemplate();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<List<AppUsageTrackerVO>> request = new HttpEntity<>(voList, headers);

			response = restTemplate.exchange(apiURL, HttpMethod.POST, request,
					new ParameterizedTypeReference<List<AppUsageTrackerVO>>() {
					});
			if (response.getStatusCode().is2xxSuccessful()) {
				LOG.info("Worker thread completed for updating AppUsageTracker via web service");
			} else {
				LOG.error("Failed to update AppUsageTracker via web service: " + response.getStatusCode());
			}

		} catch (Exception e) {
			LOG.error("Error occurred while updating AppUsageTracker via web service: " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public ResponseEntity<List<AppUsageTrackerVO>> getResponse() {
		return response;
	}

	public static ResponseEntity<List<AppUsageTrackerVO>> updateApplicationUsage(String string,
			List<AppUsageTrackerVO> resLst) throws Exception {
		AppUsageTrackerBulkUpdateWorker worker = new AppUsageTrackerBulkUpdateWorker(string, resLst);
		try {
			worker.run();
			LOG.info("Response Payload: " + worker.getResponse().getBody().toString());
		} catch (Exception e) {
			throw new Exception(e);
		}
		return worker.getResponse();
	}

}