package com.cts.baac360.app.common;

import java.text.SimpleDateFormat;

public interface AppUsageTrackerConstant {
	String ON_SHORE="Onshore";
	String OFF_SHORE = "OffShore";
	SimpleDateFormat SDF_DD_MM_YYYY= new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat SDF_MM_DD_YYYY= new SimpleDateFormat("MM/dd/yyyy");
}
