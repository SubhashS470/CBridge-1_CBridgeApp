package com.cts.baac360.app.ui;

import java.awt.GridLayout;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.commons.lang3.StringUtils;

import com.cts.baac360.app.model.InputData;

public class AppUsageInputs {

	public static int getData() {
		JPanel panel = new JPanel(new GridLayout(5, 2));
		JLabel lblProject = new JLabel("Project Name:");
		JTextField txtProject = new JTextField(20);
		panel.add(lblProject);
		panel.add(txtProject);
		JLabel lblLob = new JLabel("LOB:");
		JComboBox<String> drpLob = new JComboBox<String>();
		drpLob.addItem("-----Select------");
		drpLob.addItem("Medicare");
		drpLob.addItem("Medicaid");
		drpLob.addItem("Commercial");
		drpLob.addItem("Dual");
		panel.add(lblLob);
		panel.add(drpLob);
		JLabel lblcfg = new JLabel("CFG:");
		JTextField txtCFG = new JTextField(20);
		panel.add(lblcfg);
		panel.add(txtCFG);
		JLabel lbltower = new JLabel("Tower:");
		JComboBox<String> drpTower = new JComboBox<String>();
		drpTower.addItem("-----Select------");
		drpTower.addItem("Configuration");
		drpTower.addItem("Enrollment");
		drpTower.addItem("Billing");
		drpTower.addItem("Claims");
		drpTower.addItem("FDI & CS");
		drpTower.addItem("Finance & Encounter");
		drpTower.addItem("QNXT");
		panel.add(lbltower);
		panel.add(drpTower);
		JLabel lbltype = new JLabel("OffShore/Onshore");
		JComboBox<String> drpType = new JComboBox<String>();
		drpType.addItem("-----Select------");
		drpType.addItem("OffShore");
		drpType.addItem("Onshore");
		panel.add(lbltype);
		panel.add(drpType);

		int result = JOptionPane.showConfirmDialog(null, panel, "Input Panel", JOptionPane.OK_CANCEL_OPTION);
		if (StringUtils.isNotBlank(txtProject.getText()) && drpLob.getSelectedIndex() > 0
				&& drpTower.getSelectedIndex() > 0 && drpType.getSelectedIndex() > 0) {
			if (result == JOptionPane.OK_OPTION) {
				new InputData(txtProject.getText(), drpLob.getSelectedItem().toString(), txtCFG.getText(),
						drpTower.getSelectedItem().toString(), drpType.getSelectedItem().toString());
				return result;
			} else {
				return -1;
			}
		} else {
			return -1;
		}
	}
}
