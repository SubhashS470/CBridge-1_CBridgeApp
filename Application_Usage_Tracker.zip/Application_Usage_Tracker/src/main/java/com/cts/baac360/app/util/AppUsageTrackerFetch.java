package com.cts.baac360.app.util;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class AppUsageTrackerFetch {
	private static final Logger LOG = LoggerFactory.getLogger(AppUsageTrackerFetch.class);

	public String findByUserandAppname(String apiURL, String userid, String appname) throws IOException {
		RestTemplate restTemplate = new RestTemplate();
		// Create parameter map
		Map<String, String> params = new HashMap<>();
		params.put("userId", userid);
		params.put("appName", appname);

		// Set headers (optional)
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		// Create HttpEntity (optional)
		HttpEntity<String> entity = new HttpEntity<>(headers);

		// Send GET request
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		// Handle the response
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByFromAndToDate(String apiURL, String from, String to) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("from", from);
		params.put("to", to);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByAppNameFromToDate(String apiURL, String appName, String from, String to) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("appName", appName);
		params.put("from", from);
		params.put("to", to);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByAppNameModuleNameFromToDate(String apiURL, String appName, String moduleName, String from,
			String to) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("moduleName", moduleName);
		params.put("appName", appName);
		params.put("from", from);
		params.put("to", to);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByUserFromToDate(String apiURL, String userid, String from, String to) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("userId", userid);
		params.put("from", from);
		params.put("to", to);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByFromToDate(String apiURL, String from, String to) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("from", from);
		params.put("to", to);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByTower(String apiURL, String tower) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("towerName", tower);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findByTowerNameFromToDate(String apiURL, String towerName, String from, String to) {
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("towerName", towerName);
		params.put("from", from);
		params.put("to", to);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	public String findall(String apiURL) throws IOException {
		RestTemplate restTemplate = new RestTemplate();
		// Set headers (optional)
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		// Create HttpEntity (optional)
		HttpEntity<String> entity = new HttpEntity<>(headers);

		// Send GET request
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class);
		String responseBody = "";
		// Handle the response
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

	private static String orNullIfBlank(String s) {
		return (s == null || s.trim().isEmpty()) ? "EON" : s.trim();
	}

	public String findall(String apiURL, String towerName, String userName, String fromDate, String toDate,
			String appName, String moduleName, String txnType) throws IOException {
		LOG.info("Service Method Process starting...");
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> params = new HashMap<>();
		params.put("towerName", orNullIfBlank(towerName));
		params.put("userId", orNullIfBlank(userName));
		params.put("appName", orNullIfBlank(appName));
		params.put("moduleName", orNullIfBlank(moduleName));
		params.put("txnType", orNullIfBlank(txnType));
		params.put("from", orNullIfBlank(fromDate));
		params.put("to", orNullIfBlank(toDate));
		LOG.info("Request Parameter: " + params);
		// Set headers (optional)
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		// Create HttpEntity (optional)
		HttpEntity<String> entity = new HttpEntity<>(headers);
		LOG.info("CBridge service call initiating....URL: {1}, \t Header: {2}, \t Request Parame: {3}",apiURL, entity, params);
		// Send GET request
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		// Handle the response
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

}
