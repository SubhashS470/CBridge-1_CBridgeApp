package com.cts.baac360.app.util;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class TMGUserDetailsFetch {
	private static final Logger LOG = LoggerFactory.getLogger(TMGUserDetailsFetch.class);

	public String findByUserDetails(String apiURL, String userid) throws IOException {
		RestTemplate restTemplate = new RestTemplate();
		// Create parameter map
		Map<String, String> params = new HashMap<>();
		params.put("associateId", userid);
		// Set headers (optional)
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		// Create HttpEntity (optional)
		HttpEntity<String> entity = new HttpEntity<>(headers);

		// Send GET request
		ResponseEntity<String> response = restTemplate.exchange(apiURL, HttpMethod.GET, entity, String.class, params);
		String responseBody = "";
		// Handle the response
		if (response.getStatusCode().is2xxSuccessful()) {
			responseBody = response.getBody();
			LOG.info(responseBody);
		} else {
			LOG.error("Error: " + response.getStatusCode());
		}
		return responseBody;
	}

}
