package com.cts.baac360.app.thread;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cts.baac360.app.common.BaaC360ApplicationName;
import com.cts.baac360.app.model.LoginLogoffTrakerVO;
public class LoginLogoffTrackerUpdateWorker implements Runnable {
	private static final Logger LOG = LoggerFactory.getLogger(LoginLogoffTrackerUpdateWorker.class);

    private final String apiURL;
    private final LoginLogoffTrakerVO vos;
    private ResponseEntity<LoginLogoffTrakerVO> response = null;
	
	private LoginLogoffTrackerUpdateWorker(String id, String userId, String userName, String appName, Date loginDate,
			Date loginTime, Date logoffTime, String logoffRemarks, String apiURL) {
        this.apiURL = apiURL;
        this.vos = new LoginLogoffTrakerVO(id, userId, userName, appName, loginDate, loginTime, logoffTime, logoffRemarks);
    }
    
	@Override
	public void run() {
		try {
            LOG.info("Worker thread started for updating AppUsageTracker via web service");

            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            HttpEntity<LoginLogoffTrakerVO> requestEntity = new HttpEntity<>(vos, headers);

            response = restTemplate.exchange(apiURL, HttpMethod.POST, requestEntity, LoginLogoffTrakerVO.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                LOG.info("Worker thread completed for updating AppUsageTracker via web service");
            } else {
                LOG.error("Failed to update AppUsageTracker via web service: " + response.getStatusCode());
            }
        } catch (Exception e) {
            LOG.error("Error occurred while updating AppUsageTracker via web service: " + e.getMessage(), e);
//            throw new RuntimeException(e);
        }
	}

	public static ResponseEntity<LoginLogoffTrakerVO> updateApplicationUsage(String id, String userId, String userName, String appName, Date loginDate,
			Date loginTime, Date logoffTime, String logoffRemarks, String apiURL) throws Exception {
		LoginLogoffTrackerUpdateWorker worker = new LoginLogoffTrackerUpdateWorker(id, userId, userName, appName, loginDate, loginTime, logoffTime, logoffRemarks, apiURL);
		try {
			new Thread(worker).start();
//			LOG.info("Response Payload: " + worker.getResponse().getBody().toString());
		} catch (Exception e) {
//        	throw new Exception(e);
        }
        return worker.getResponse();
    }
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// Sample usage
		ResponseEntity<LoginLogoffTrakerVO> response;
		try {
			response = LoginLogoffTrackerUpdateWorker.updateApplicationUsage ("20","prengasamy", "username111", BaaC360ApplicationName.BS.getName(), 
					new Date(), new Date(),new Date(), "remarks",
					"http://localhost:7777/cbridge/api/log/v1/update");
			LOG.info("Response Payload: " + response.getBody().toString());
			LOG.info("Response Status: " + response.getStatusCode());
			LOG.info("Response Headers: " + response.getHeaders());
			LOG.info("Response Status Code Value: " + response.getStatusCodeValue());
			LOG.info("Reason Phrase:" + ((HttpStatus) response.getStatusCode()).getReasonPhrase());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ResponseEntity<LoginLogoffTrakerVO> getResponse() {
		return response;
	}

	public void setResponse(ResponseEntity<LoginLogoffTrakerVO> response) {
		this.response = response;
	}
}
