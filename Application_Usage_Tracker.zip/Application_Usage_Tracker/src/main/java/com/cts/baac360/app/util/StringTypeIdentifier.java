package com.cts.baac360.app.util;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
//import java.util.Currency;
import java.util.Locale;

public class StringTypeIdentifier {

	 // Check if string is a valid number
    public static boolean isNumber(Object obt ) {
        try {
            Double.parseDouble(obt.toString());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Check if string is a valid date (supports multiple formats)
    public static boolean isDate(Object obt) {
        String[] dateFormats = {"yyyy/MM/dd", "yyyy-MM-dd", "MM/dd/yyyy", "MM-dd-yyyy","dd/MM/yyyy","dd-MM-yyyy"};
        String str = obt.toString();
        for (String format : dateFormats) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(format);
                sdf.setLenient(false);
                sdf.parse(str);
                return true;
            } catch (ParseException e) {
                // Continue trying other formats
            }
        }
        return false;
    }

    // Check if string is a valid currency amount
    public static boolean isCurrency(Object obt) {
    	boolean flag = true;
    	String str = obt.toString();
        try {
        	if (!str.startsWith("$")){
        		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
                format.parse(obt.toString());
        	}
        } catch (ParseException e) {
        	flag = false;
        }
        return flag;
    }

	public static boolean isBoolean(Object obj) {
		List<String> booleanList = Arrays.asList("True", "true", "Yes", "yes" ,"Y", "y","False","false","No","no","N","n");
		boolean flag = false;
		try {
            if (booleanList.contains(obj.toString())){
            	flag = true;
            }
        } catch (Exception e) {
            
        }
		return flag;
	}
}
