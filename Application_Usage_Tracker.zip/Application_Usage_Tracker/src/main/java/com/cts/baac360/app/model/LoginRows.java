package com.cts.baac360.app.model;

public class LoginRows {
	private String date;
	private String inTime;
	private String outTime;
	private String applicationName;
	public LoginRows(String date, String inTime, String outTime, String applicationName) {
		super();
		this.date = date;
		this.inTime = inTime;
		this.outTime = outTime;
		this.applicationName = applicationName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getInTime() {
		return inTime;
	}
	public void setInTime(String inTime) {
		this.inTime = inTime;
	}
	public String getOutTime() {
		return outTime;
	}
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
}
