package com.cts.baac360.app.common;

public enum BaaC360ApplicationStatus {

	SUCCESS("SUCCESS", "Sucessfuly completed"),
	FAILED("Failed", "Operation Failed"),
	;

	String name;
	String descr;

	private BaaC360ApplicationStatus(String name, String descr) {
		this.name = name;
		this.descr = descr;
	}

	public String getName() {
		return name;
	}

	public String getDescr() {
		return descr;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}
}
