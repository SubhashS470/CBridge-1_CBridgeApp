package com.cts.baac360.app.model;

import java.io.Serializable;
import java.util.Objects;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TmgUserDetailsVO implements Serializable{
	public TmgUserDetailsVO() {
		super();
	}
	public TmgUserDetailsVO(Long associateId, String associateName, String password, String email, String tmgUserId,
			String status, String location, String superviserId, String superviserName, String tower, String project) {
		super();
		this.associateId = associateId;
		this.associateName = associateName;
		this.password = password;
		this.email = email;
		this.tmgUserId = tmgUserId;
		this.status = status;
		this.location = location;
		this.superviserId = superviserId;
		this.superviserName = superviserName;
		this.tower = tower;
		this.project = project;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	private static final long serialVersionUID = 1L;
	@Id
	@JsonProperty("id")
	private String id;
	@JsonProperty("Associate_Id")
	private Long associateId;
	@JsonProperty("Associate_Name")
	private String associateName;
	@JsonProperty("password")
	private String password;
	@JsonProperty("Email_Id")
	private String email;
	@JsonProperty("TMG_User_Id")
	private String tmgUserId;
	@JsonProperty("Status")
	private String status;
	@JsonProperty("Location")
	private String location;
	@JsonProperty("Supervisor_ID")
	private String superviserId;
	@JsonProperty("Supervisor_Name")
	private String superviserName;
	@JsonProperty("Tower")
	private String tower;
	@JsonProperty("Project")
	private String project;
	/**
	 * @return the associateId
	 */
	public Long getAssociateId() {
		return associateId;
	}
	/**
	 * @param associateId the associateId to set
	 */
	public void setAssociateId(Long associateId) {
		this.associateId = associateId;
	}
	/**
	 * @return the associateName
	 */
	public String getAssociateName() {
		return associateName;
	}
	/**
	 * @param associateName the associateName to set
	 */
	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the tmgUserId
	 */
	public String getTmgUserId() {
		return tmgUserId;
	}
	/**
	 * @param tmgUserId the tmgUserId to set
	 */
	public void setTmgUserId(String tmgUserId) {
		this.tmgUserId = tmgUserId;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * @return the superviserId
	 */
	public String getSuperviserId() {
		return superviserId;
	}
	/**
	 * @param superviserId the superviserId to set
	 */
	public void setSuperviserId(String superviserId) {
		this.superviserId = superviserId;
	}
	/**
	 * @return the superviserName
	 */
	public String getSuperviserName() {
		return superviserName;
	}
	/**
	 * @param superviserName the superviserName to set
	 */
	public void setSuperviserName(String superviserName) {
		this.superviserName = superviserName;
	}
	/**
	 * @return the tower
	 */
	public String getTower() {
		return tower;
	}
	/**
	 * @param tower the tower to set
	 */
	public void setTower(String tower) {
		this.tower = tower;
	}
	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(associateId, associateName, email, location, password, project, status, superviserId,
				superviserName, tmgUserId, tower);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TmgUserDetailsVO other = (TmgUserDetailsVO) obj;
		return Objects.equals(associateId, other.associateId) && Objects.equals(associateName, other.associateName)
				&& Objects.equals(email, other.email) && Objects.equals(location, other.location)
				&& Objects.equals(password, other.password) && Objects.equals(project, other.project)
				&& Objects.equals(status, other.status) && Objects.equals(superviserId, other.superviserId)
				&& Objects.equals(superviserName, other.superviserName) && Objects.equals(tmgUserId, other.tmgUserId)
				&& Objects.equals(tower, other.tower);
	}
	@Override
	public String toString() {
		return "TmgUserDetailsVO [associateId=" + associateId + ", associateName=" + associateName + ", password="
				+ password + ", email=" + email + ", tmgUserId=" + tmgUserId + ", status=" + status + ", location="
				+ location + ", superviserId=" + superviserId + ", superviserName=" + superviserName + ", tower="
				+ tower + ", project=" + project + "]";
	}
	
	
}
