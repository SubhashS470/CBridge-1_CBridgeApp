package com.cts.baac360.app.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public class LoginLogoffTrakerVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String userId;
	private String userName;
	private String appName;
	private Date loginDate;
	private Date loginTime;
	private Date logoffTime;
	private String logoffRemarks;

	public LoginLogoffTrakerVO() {
		super();
	}

	public LoginLogoffTrakerVO(String id, String userId, String userName, String appName, Date loginDate,
			Date loginTime, Date logoffTime, String logoffRemarks) {
		super();
		this.id = id;
		this.userId = userId;
		this.userName = userName;
		this.appName = appName;
		this.loginDate = loginDate;
		this.loginTime = loginTime;
		this.logoffTime = logoffTime;
		this.logoffRemarks = logoffRemarks;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Date getLoginDate() {
		return loginDate;
	}

	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}

	public Date getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	public Date getLogoffTime() {
		return logoffTime;
	}

	public void setLogoffTime(Date logoffTime) {
		this.logoffTime = logoffTime;
	}

	public String getLogoffRemarks() {
		return logoffRemarks;
	}

	public void setLogoffRemarks(String logoffRemarks) {
		this.logoffRemarks = logoffRemarks;
	}

	@Override
	public int hashCode() {
		return Objects.hash(appName, id, logoffRemarks, logoffTime, loginDate, loginTime, userId, userName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoginLogoffTrakerVO other = (LoginLogoffTrakerVO) obj;
		return Objects.equals(appName, other.appName) && Objects.equals(id, other.id)
				&& Objects.equals(logoffRemarks, other.logoffRemarks) && Objects.equals(logoffTime, other.logoffTime)
				&& Objects.equals(loginDate, other.loginDate) && Objects.equals(loginTime, other.loginTime)
				&& Objects.equals(userId, other.userId) && Objects.equals(userName, other.userName);
	}

	@Override
	public String toString() {
		return "LoginLogoffTrakerVO [id=" + id + ", userId=" + userId + ", userName=" + userName + ", appName="
				+ appName + ", loginDate=" + loginDate + ", loginTime=" + loginTime + ", logoffTime=" + logoffTime
				+ ", logoffRemarks=" + logoffRemarks + "]";
	}

}
