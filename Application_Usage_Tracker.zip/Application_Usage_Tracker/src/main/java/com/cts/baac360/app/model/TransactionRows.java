package com.cts.baac360.app.model;

public class TransactionRows {
	private String applicationName;
	private String transactionDetail;
	private String transactionType;
	
	private String reocrdCount;
	private String durationInMinitues;
	private String status;
	private String statusRemarks;

	public TransactionRows(String applicationName, String transactionDetail,String transactionType,String reocrdCount,String durationInMinitues, String status,
			String statusRemarks) {
		super();
		this.applicationName = applicationName;
		this.transactionDetail = transactionDetail;
		this.transactionType= transactionType;
		this.reocrdCount=reocrdCount;
		this.durationInMinitues = durationInMinitues;
		this.status = status;
		this.statusRemarks = statusRemarks;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getTransactionDetail() {
		return transactionDetail;
	}
	public void setTransactionDetail(String transactionDetail) {
		this.transactionDetail = transactionDetail;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getreocrdCount() {
		return reocrdCount;
	}
	public void setreocrdCount(String reocrdCount) {
		this.reocrdCount = reocrdCount;
	}
	public String getDurationInMinitues() {
		return durationInMinitues;
	}
	
	public void setDurationInMinitues(String durationInMinitues) {
		this.durationInMinitues = durationInMinitues;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusRemarks() {
		return statusRemarks;
	}
	public void setStatusRemarks(String statusRemarks) {
		this.statusRemarks = statusRemarks;
	}
}
