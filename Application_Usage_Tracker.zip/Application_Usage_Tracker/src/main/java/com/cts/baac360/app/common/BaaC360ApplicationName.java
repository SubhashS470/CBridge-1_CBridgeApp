package com.cts.baac360.app.common;

public enum BaaC360ApplicationName {
	BI("Invoice Validation","Invoice Validation"),
	BS ("Benefit Studio", "Benefit Studio"),
	NS ("NetworX Studio", "NetworX Studio"),
	CS ("Claims Studio", "Claims Studio"),
	FS ("Fees Schedule Studio", "Fee Schedule Studio"),
	/* EDI834 ("FHG Application", "834 EDI File Generation"), */
	EnrolLegacy("TMG Enroll Legacy", "Legacy enrollment tool to perform enroll,TRR,BEQ and DAF transactions"), 
	/*
	 * EDI278("FHG Application - 278", "278 Validation"),
	 * EDI837("FHG Application - 837", "837 Validation"),
	 * EDI837MOCKUP("FHG Application - 837 Mockup", "837 Validation"),
	 */
	QNBS ("QNXT Benefit Studio", "QNXT Benefit Studio"),
	QNFS ("QNXT Fees Schedule Studio", "QNXT Fee Schedule Studio"),
	QNNS ("QNXT NetworX Studio", "QNXT NetworX Studio"),
	AB ("Active Batch", "Active Batch"),
	COB ("COB Studio","COB Studio"),
	FinanceApplication("Finance Extract Validation","Finance Extract Validation"),
	QNCLAIMSCREENSHOT("QNXT Claim UI Screenshot", "QNXT Claim UI Screenshot"), 
	/*
	 * EDICorrectedClaims("FHG Application - EDI Corrected Claims",
	 * "EDI Corrected Claims Validation"),
	 */
	ACCUMSOUTBOUND("AccumsOutbound","AccumsOutbound"),
	QNEAM ("QNXT EAM Application", "QNXT EAM Application"),
	CignaEDI("Cigna","Cigna Process"),
	AVAILITYSCREENSHOT("Availity ServiceType Screenshot","Availity ServiceType Screenshot"),
	FHG("FHG Application","FHG Application"),
	QNXTCS("QNXT Claims Studio", "QNXT Claims Studio"),
	FDIXWALK("FDI XWalk Validation","FDI XWalk Validation"), 
	EDI834("EDI834 Application","EDI834 Application"),
	LockBox("LockBox File Creation","LockBox File Creation"),
	CMSOECCONVERTER("CMS OEC Converter Enrollment Application","CMS OEC Converter Enrollment Application"),
	FDIMAESTRO("Maestro Testcase Automation", "Maestro Testcase Automation"),
	BDEV("Billing Doc Id extract Validation Automation","Billing Doc Id extract Validation Automation"),
	API("API Testing Tool","API Testing Tool");
	;
	
	String name;
	String descr;
	private BaaC360ApplicationName(String name, String descr) {
		this.name = name;
		this.descr = descr;
	}
	public String getName() {
		return name;
	}
	public String getDescr() {
		return descr;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	
}
