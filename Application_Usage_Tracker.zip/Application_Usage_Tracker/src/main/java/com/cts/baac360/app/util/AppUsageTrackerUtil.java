package com.cts.baac360.app.util;

import java.awt.Desktop;
import java.io.File;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppUsageTrackerUtil {
	private static final Logger LOG = LoggerFactory.getLogger(AppUsageTrackerUtil.class);
	
	/**
	 * convert the format of string "0 hr 1 minutes 8 second" to HHMMSS
	 * @param input
	 * @return
	 */
	public static String convertStringToHHMMSS(String input) {
		String timeStr = "00:00:00";
		// Extract numbers using regex
		try {
		if (StringUtils.isNotBlank(input)) {
			String[] parts = input.split("\\D+");
			int hours = Integer.parseInt(parts[0]);
			int minutes = Integer.parseInt(parts[1]);
			int seconds = Integer.parseInt(parts[2]);
			// Format to HH:MM:SS
			timeStr = String.format("%02d:%02d:%02d", hours, minutes, seconds);
		} 
		}catch(Exception e) {
			
		}
		return timeStr;
	}
	
	/**
	 * help to convert time to second
	 * @param time
	 * @return
	 */
	public static int convertHoursHHMMSSToSeconds(String time) {
	    String[] parts = time.split(":");
	    int hours = Integer.parseInt(parts[0]);
	    int minutes = Integer.parseInt(parts[1]);
	    int seconds = Integer.parseInt(parts[2]);
	    //return seconds value
	    return hours * 3600 + minutes * 60 + seconds;
	}
	
	/**
	 * 
	 * @param minutes
	 * @return
	 */
	public static int convertMinuesToSeconds(String minutes) {
	    return Integer.valueOf(minutes) * 60 ;
	}
	
	/**
	 * 
	 * @param seconds
	 * @return
	 */
	public static double convertSecondsToHours(long seconds) {
	    return seconds / 3600.0;
	}
	
	/**
	 * help to convert Seconds into Hours format HH:MM:SS
	 * @param totalSeconds
	 * @return
	 */
	public static String convertSecondsToHHMMSS(long totalSeconds) {
		long hours = totalSeconds / 3600;
		long minutes = (totalSeconds % 3600) / 60;
		long seconds = totalSeconds % 60;

	    return String.format("%02d:%02d:%02d", hours, minutes, seconds);
	}
	
	/**
     * Converts a numeric string to a formatted currency string
     * @param numericString The input string, e.g., "1234.56"
     * @param locale The locale for currency formatting, e.g., Locale.US
     * @return The formatted currency string, e.g., "$1,234.56"
     */
    public static String convertStringToCurrency(String numericString, Locale locale) {
        try {
            // Parse the string to a number (double)
        	numericString = numericString.indexOf("$") > -1 ? numericString.subSequence(1, numericString.length()).toString() : numericString;
            double amount = Double.parseDouble(numericString);
            // Create a currency formatter for the specified locale
            NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
            // Format the number as currency
            return currencyFormatter.format(amount);
        } catch (NumberFormatException ex) { // Handle invalid input gracefully
            LOG.error("Invalid numeric string: " + numericString);
            throw ex;
        }
    }
    public static String convertStringToCurrency(String numericString) {
    	return StringUtils.replaceOnce(numericString,"$", "");
        //return convertStringToCurrency(numericString, Locale.US);
    }

    public static Date convertStringToDate(Object value) {
    	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    	Date dt = null;
    	try {
			dt = formatter.parse(value.toString());
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	return dt;
    }

	public static void openFileWithDefaultApplication(File file) {
		try {
			if (file.exists()) {
				if (Desktop.isDesktopSupported()) {
					Desktop.getDesktop().open(file);
				} else {
					LOG.warn("Desktop is not supported. Cannot open the file.");
				}
			} else {
				LOG.warn("File does not exist: " + file.getAbsolutePath());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static String getFormatedDate(Date dete) {
		String formattedDate = null;
        // Define the input formatter (must match the input string format exactly)
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
        // Parse the string into a ZonedDateTime
        ZonedDateTime zonedDateTime = ZonedDateTime.parse(dete.toString(), inputFormatter);
        // Define the desired output format
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        // Format and print the result
        formattedDate = zonedDateTime.format(outputFormatter);
        System.out.println("Formatted date: " + formattedDate);
		return formattedDate;
	}
	
}
