package com.cts.baac360.app.model;

public class InputData {
	private static String project;
	private static String lob;
	private static String cfg;
	private static String tower;
	private static String type;
	@SuppressWarnings("static-access")
	public InputData(String project, String lob, String cfg, String tower, String type) {
		super();
		InputData.project = project;
		InputData.lob = lob;
		InputData.cfg = cfg;
		InputData.tower = tower;
		InputData.type=type;
	}
	public static String getproject() {
		return project;
	}
	public void setproject(String project) {
		InputData.project = project;
	}
	public static String getlob() {
		return lob;
	}
	public void setlob(String lob) {
		InputData.lob = lob;
	}
	public static String getcfg() {
		return cfg;
	}
	public void setcfg(String cfg) {
		InputData.cfg = cfg;
	}
	public static String gettower() {
		return tower;
	}
	public void settower(String tower) {
		InputData.tower = tower;
	}
	public static String getType() {
		return type;
	}
	public void setType(String type) {
		InputData.type = type;
	}
}
