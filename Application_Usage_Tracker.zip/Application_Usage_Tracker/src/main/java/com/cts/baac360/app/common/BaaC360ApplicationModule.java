package com.cts.baac360.app.common;

public enum BaaC360ApplicationModule {
	//CNFIG("Configuration Testing", "Configuration Testing"),
	BILLING_INVOICE("Invoice Validation","Invoice Validation Testing", "Invoice Validation Testing"),
	CNFIG_BS("Benefit Studio","Benefit Configuration Testing", "Benefit Configuration Testing"),
	CLAIMS_BS("Benefit Studio","Benefit Claims Testing", "Benefit Claims Testing"),
	CNFIG_NS("NetworX Studio","Networx Configuration Testing", "Networx Configuration Testing"),
	CLAIMS_NS("NetworX Studio","Networx Claims Testing", "Networx Claims Testing"),
	TESTCASE_NS("NetworX Studio","Networx Claims TestCase", "Networx Claims TestCase Generation"),
	CNFIG_FS("Fees Schedule Studio","Fee Schedule Configuration Testing", "Fee Schedule Configuration Testing"),
	CLAIMS_FS("Fees Schedule Studio","Fee Schedule Claims Testing", "Fee Schedule Claims Testing"),
	Enroll_EDI("FHG Application","Enrollment", "Regression testing"),
	TMG_Enrol("TMG Enroll Legacy","Enrollment","Enrol, TRR, BEQ and DAF transactions"),
	CLAIMS_CS("Claims Studio","Claims Testing", "Claims Testing"),
	CS_PROVIDER_CREATION("Claims Studio","Provider_Creation","Provider Creation"),
	CS_CONFIG("Claims Studio","Claims_Configuration_Testing","Claims Configuration Testing"),
	CS_BENCHMARK_TESTING("Claims Studio","Claims_Benchmark_Testing","Claims Benchmark Testing"),
	CNFIG_QN_FS("QNXT Fees Schedule Studio","QNXT Fee Schedule Configuration Testing", "QNXT Fee Schedule Configuration Testing"),
	CNFIG_QN_BS("QNXT Benefit Studio","QNXT Benefit Configuration Testing", "QNXT Benefit Configuration Testing"),
	CLAIMS_QN_BS("QNXT Benefit Studio","QNXT Benefit Claims Testing", "QNXT Benefit Claims Testing"),
	CLAIMS_QN_FS("QNXT Fees Schedule Studio","QNXT Fee Schedule Claims Testing", "QNXT Fee Schedule Claims Testing"),
	CNFIG_QN_NS("QNXT NetworX Studio","QNXT Networx Configuration Testing", "QNXT Networx Configuration Testing"),
	CLAIMS_QN_NS("QNXT NetworX Studio","QNXT Networx Claims Testing", "QNXT Networx Claims Testing"),
	PARALLELJOB_AB("Active Batch","Active Batch Parallel Job Process", "Active Batch Parallel Job Process"),
	FUNCTIONALJOB_AB("Active Batch","Active Batch Functional Specific Job Process", "Active Batch Functional Specific Job Process"),
	CLAIMSCREENSHOT("QNXT Claim Screenshot","Create Test Results", "QNXT Claim Screenshot"),
	COB_PROCESS ("COB Application","COB Process Automation Testing","COB Process Automation Testing"),
	EAM_QNXT("QNXT EAM Application","QNXT EAM Application","QNXT EAM Application"),
	FINANCE_EXTRACT_VALIDATION("Finace Extract Validation","Finance Extract automation Testing","Finance Extract automation Testing"),
	AVAILITY_SCREENSHOT_TOOL("Availity Screenshot Tool","Availity Service Type BenefitGrid Validation","Availity Service Type BenefitGrid Validation"),
	FHG_EDI_MOCKUP("FHG Application","EDI Create or Mockup","EDI_Create_or_Mockup"),
	FHG_EDI_INTAKE("FHG Application","EDI Intake Process","EDI_Intake_Process"),
	FHG_ADJUDICATED_CLAIMS("FHG Application","837 vs Adjudicated Claims","837_vs_Adjudicated_Claims"),
	FHG_CORRECTED_CLAIMS("FHG Application","Corrected Claims","Corrected_Claims"),
	FHG_PROVIDER_MATCH("FHG Application","Provider Match","Provider_Match"),
	FHG_MEMBER_MATCH("FHG Application","Member Match","Member_Match"),
	FHG_835_VALIDATION("FHG Application","835 Validation","835_Validation"),
	FHG_275_VALIDATION("FHG Application","275 Validation","275_Validation"),
	FHG_278_VALIDATION("FHG Application","278 Validation","278_Validation"),
	FDI_XWALK("FDI XWalk Validation","FDI XWalk Validation", "FDI XWalk Validation"),
	CLAIMS_CS_QNXT("QNXT Claims Studio","QNXT Claims Testing", "QNXT Claims Testing"),
	CS_PROVIDER_CREATION_QNXT("QNXT Claims Studio","QNXT Provider_Creation","QNXT Provider Creation"),
	CS_CONFIG_QNXT("QNXT Claims Studio","QNXT Claims_Configuration_Testing","QNXT Claims Configuration Testing"),
	CS_BENCHMARK_TESTING_QNXT("QNXT Claims Studio","QNXT Claims_Benchmark_Testing","QNXT Claims Benchmark Testing"),
	ACCUM_OUTBUND_VALIDATION("AccumsOutbound","Accum_Outbound_Validation","Accum Outbound Validation"),
	OVER_ACCUM_VALIDATION("AccumsOutbound","Over_Accum_Validation","Over Accum Validation"),
	CMS_OEC_CONVERTER_TOOL("CMS OEC Converter Enrollment Application","CMS OEC Enrollment File Process","CMS OEC Enrollment File Process"),
	LockBox_File_Creation("LockBox_File_Creation","LockBox_File_Creation","LockBox File Creation"),
	FDI_MAESTRO("Maestro Testcase Automation", "Maestro Regression Testcase Automation testing", "Maestro Regression Testcase Automation testing"),
	BILLING_DOC_ID_EXTRACT("Billing Doc Id extract Validation","Billing Doc Id extract Validation Testing", "Billing Doc Id extract Validation Testing"),
	API_GENTESTCASE("API Testing Tool","Generate Test Case","Generate Test Case"),
	API_EXECUTESERVICES("API Testing Tool","Execute Services","Execute Services");
	;
	String appName;
	String name;
	String descr;

	private BaaC360ApplicationModule(String appName,String name, String descr) {
		this.appName=appName;
		this.name = name;
		this.descr = descr;
	}

	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getName() {
		return name;
	}

	public String getDescr() {
		return descr;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}
}
