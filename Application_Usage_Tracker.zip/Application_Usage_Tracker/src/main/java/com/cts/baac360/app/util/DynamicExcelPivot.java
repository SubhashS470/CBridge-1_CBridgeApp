package com.cts.baac360.app.util;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DynamicExcelPivot {

    /**
     * Generates a pivot table from an Excel file based on dynamic pivot columns and aggregation type.
     *
     * @param inputFile   Path to the input Excel file
     * @param outputFile  Path to the output Excel file
     * @param pivotColumns List of column names to group by
     * @param valueColumn Column name for aggregation
     * @param aggFunc     Aggregation function: COUNT or SUM
     * @throws Exception if any error occurs during processing
     */
    public static void generatePivot(String inputFile, String outputFile,
                                     List<String> pivotColumns, String valueColumn, String aggFunc) throws Exception {
        FileInputStream fis = new FileInputStream(inputFile);
        try (Workbook workbook = new XSSFWorkbook(fis)) {
			Sheet sheet = workbook.getSheetAt(0);

			// Read header
			Row headerRow = sheet.getRow(0);
			List<String> headers = new ArrayList<>();
			for (Cell cell : headerRow) {
			    headers.add(cell.getStringCellValue());
			}

			// Validate columns
			for (String col : pivotColumns) {
			    if (!headers.contains(col)) {
			        throw new IllegalArgumentException("Pivot column not found: " + col);
			    }
			}
			if (!headers.contains(valueColumn)) {
			    throw new IllegalArgumentException("Value column not found: " + valueColumn);
			}

			// Read data
			List<Map<String, String>> data = new ArrayList<>();
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			    Row row = sheet.getRow(i);
			    if (row == null) continue;
			    Map<String, String> rowData = new HashMap<>();
			    for (int j = 0; j < headers.size(); j++) {
			        Cell cell = row.getCell(j);
			        rowData.put(headers.get(j), cell != null ? cell.toString() : "");
			    }
			    data.add(rowData);
			}

			// Group and aggregate
			Map<List<String>, Double> pivotMap = new HashMap<>();
			for (Map<String, String> row : data) {
			    List<String> key = pivotColumns.stream().map(row::get).collect(Collectors.toList());
			    double value = 0;
			    if (aggFunc.equalsIgnoreCase("COUNT")) {
			        value = 1;
			    } else if (aggFunc.equalsIgnoreCase("SUM")) {
			        try {
			            value = Double.parseDouble(row.get(valueColumn));
			        } catch (NumberFormatException e) {
			            value = 0;
			        }
			    }
			    pivotMap.put(key, pivotMap.getOrDefault(key, 0.0) + value);
			}

			// Write pivot to new sheet
			Sheet pivotSheet = workbook.createSheet("PivotReport");
			int rowIndex = 0;
			Row header = pivotSheet.createRow(rowIndex++);
			int colIndex = 0;
			for (String col : pivotColumns) {
			    header.createCell(colIndex++).setCellValue(col);
			}
			header.createCell(colIndex).setCellValue(aggFunc);

			for (Map.Entry<List<String>, Double> entry : pivotMap.entrySet()) {
			    Row row = pivotSheet.createRow(rowIndex++);
			    colIndex = 0;
			    for (String val : entry.getKey()) {
			        row.createCell(colIndex++).setCellValue(val);
			    }
			    row.createCell(colIndex).setCellValue(entry.getValue());
			}

			FileOutputStream fos = new FileOutputStream(outputFile);
			workbook.write(fos);
			fos.close();
			workbook.close();
		}
        fis.close();

        System.out.println("Pivot report generated: " + outputFile);
    }

    public static void main(String[] args) throws Exception {
        // Example usage
        List<String> pivotCols = Arrays.asList("Application", "Module");
        String valueCol = "Effort";
        String aggFunc = "SUM"; // or "COUNT"

        generatePivot("input.xlsx", "pivot_output.xlsx", pivotCols, valueCol, aggFunc);
    }
}
