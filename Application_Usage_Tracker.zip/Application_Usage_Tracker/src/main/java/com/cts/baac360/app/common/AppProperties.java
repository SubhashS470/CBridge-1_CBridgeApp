package com.cts.baac360.app.common;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class AppProperties {
	private static ResourceBundle RESOURCE_BUNDLE = null;
	
	public static void loadResources(String bundleName) {
		RESOURCE_BUNDLE  = ResourceBundle.getBundle(bundleName);
	}

	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return '!' + key + '!';
		}
	}
}
