/**
 * 
 */
package grp.common;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cts.qea.automation.Config;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author aselvan
 *
 */
public class Menu extends WiniumPageObject {
	public String ListCount;
	public String ListCount_Display="0";
	public int TotalListCount=0;
	public int LastListCount=-1;
	public Menu(WrappedWiniumDriver pDriver) {
		super(pDriver);
		
		element("wnFacets", By.name("Facets"));
		element("btnFile", By.name("File"));
		element("btnOpenDatabase", By.name("Open Database"));
		element("lnkLocationBar", By.id("1001"));
		element("lnkFacets", By.name("facets.pzb"));
		element("btnOpen", By.name("Open"));
		element("btnMaximize", By.name("Maximize"));
		element("btnOk", By.name("OK"));
		element("btnClose", By.name("Close"));
		element("lnkFileName", By.name("File name:"));
		
		element("menufile", By.name("File"));
		element("menuedit", By.name("Edit"));
		element("menuitemexit", By.name("Exit"));
		element("menuitemadd", By.name("Add..."));
		
		element("menuitemchange", By.name("Change..."));
		element("menuitemsave", By.name("Save"));
		element("menuitemdelete", By.name("Delete..."));
		
		element("menuitemsubsection", By.name("Subsection"));
		
		element("dialogbtnyes", By.name("Yes"));
		element("dialogbtnNo", By.name("No"));
		element("dialogbtnok", By.name("Ok"));
		///element("dlglogoffbtnok", By.xpath("//*[@@Name='Facets']/*[@Name='OK']"));
		element("dlglogoffbtnok", By.name("OK"));
				
		element("menutransfer", By.name("Transfer"));
		element("menuitemauditinfo", By.name("Audit Information"));
		element("listAddress_home", By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item'][1]"));
	}
	
	/* (non-Javadoc)
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void openFacetsConnection() {
		element("wnFacets").switchTo("Facets");
		element("btnFile").click();
		element("btnOpenDatabase").click();
		String section = Config.getEnvDetails("config", "appname");
		String filepath = Config.getEnvDetails(section, "FILE_PATH");
		element("lnkFileName").click();
		element("lnkFileName").sendKeys(filepath);
		element("btnOpen").click();
		element("lnkFacets").click();
		element("btnOpen").click();
		//element("btnMaximize").click();
	}

	public void closeFacets() {
		element("btnClose").click();
		element("btnOk").click();
	}
	public void ExitFacet() throws InterruptedException {
		element("menufile").click();
		element("menuitemexit").click();
		Thread.sleep(500);
		element("dlglogoffbtnok").click();;
		   
	}
	public void ExitFacetNoSave() throws InterruptedException {
		element("menufile").click();
		element("menuitemexit").click();
		element("dialogbtnNo").click();
		element("dlglogoffbtnok").click();;
		   
	}
	public void ExitFacetSave() throws InterruptedException {
		element("menufile").click();
		element("menuitemexit").click();
		element("dialogbtnyes").click();
		element("dlglogoffbtnok").click();;
		   
	}
	public int totalListCount() {
		element("listAddress_home").click();
		try {
		
		for (int i = 0; i <=TotalListCount; i++) {

	    	WebElement e = driver.findElement(By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item']['"+i+"'+1]"));
		
		e.click();
		
		String web2=e.getAttribute("RuntimeId");
				
		int GroupID_End=web2.indexOf(']');
		//System.out.println("/n first end of ] is :  "+GroupID_End);
		
		int LenofString=web2.length();
		
		LenofString=LenofString-2;
				
		ListCount=web2.substring(GroupID_End-2, GroupID_End);
		
		ListCount=ListCount.trim();
		
		
		Report.log("Occurance of List is:"+ListCount, Status.Pass);
		int ListCountValue=Integer.valueOf(ListCount);
		
		if (ListCountValue==LastListCount){
			
			break;
		
		}
		TotalListCount=TotalListCount+1;
		LastListCount=LastListCount+1;
			}
		}
		catch (Exception e) {
		Report.log("Total number of item present in ListBox is: "+TotalListCount, Status.DONE);	
		}
		return TotalListCount;
	}
	
	
}
