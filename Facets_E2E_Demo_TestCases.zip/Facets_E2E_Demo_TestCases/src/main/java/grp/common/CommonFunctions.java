package grp.common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.LocalDateTime;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cts.qea.automation.Assert;
import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author Kumaresh Babu Common function is avabilable, which is reusable
 */
public class CommonFunctions extends WiniumPageObject {
	public String Header_Data1, Data_From_FacetsApplication;
	public String ListCount;
	public String ListCount_Display = "0";
	public int TotalListCount = 0;
	public int LastListCount = -1;
	public boolean status;
	public String Created;
	public static String GroupID_Created;
	public static String ClassID_Created;
	public static String SubscriberID_Created;
	public static String COB_CarrierID_Created;
	public static String IPA_ID_Created;
	public static String Medicare_ID_Created;
	public static String new_ID_Created;
	public static String Additional_ID_Created;
	public static String Reference_Number_Created;
	public static String Related_Enity_ID_Created;
	public static String Product_ID_Created;
	public static String BillingProfile_ID_Created;
	public static String BillingMessage_ID_Created;
	public static String Commission_Person_ID_Created;
	public static String Commission_Entity_ID_Created;
	public static String Commission_Arrangement_ID_Created;
	public static String Commission_Schedule_ID_Created;
	public static String Alternate_Funding_Rules_Prefix_Created;
	public static String Billing_Component_Created;
	public static String Premium_RateTable_Created;
	public static String AppealContact_ID_Created;
	public static String AppealReviewer_ID_Created;

	public CommonFunctions(WrappedWiniumDriver pDriver) {
		super(pDriver);
		element("btnFile", By.name("File"));
		element("btnNew", By.name("New"));
		element("btnOpen", By.name("Open"));
		element("txtGroupID", By.name("Group ID"));
		element("txtApplicationID", By.xpath("//*[@AutomationId='102']"));
		element("btnOk", By.name("OK"));
		element("wblheader", By.xpath("//*[@AutomationId='160']"));
		element("txtCommonID", By.xpath("//*[@AutomationId='2108']"));
		element("btnCancel", By.name("Cancel"));
		element("lnkAddresses",
				By.xpath("//*[(@Name='Addresses'or @Name='Address') and @LocalizedControlType='tree item']"));
		element("lnkTaxInformation", By.xpath("//*[@Name='Tax Information' and @LocalizedControlType='tree item']"));
		element("lnkSubcriberMember", By.name("Subscriber/Member             "));
		element("lnkParentGroup", By.name("Parent Group                  "));
		element("btnEdit", By.name("Edit"));
		element("btnAdd", By.name("Add..."));
		element("btnSection", By.name("Section"));
		element("btnSubSection", By.name("Subsection"));
		element("btnClose", By.xpath("//*[@AutomationId='TitleBar']"));
		element("btnClose_Menu",
				By.xpath("//*[(@Name='Addresses'or @Name='Close') and @LocalizedControlType='menu item']"));
		element("btnClose_popup", By.xpath("//*[ @Name='Close' and @LocalizedControlType='button']"));

		// Menu items
		element("menufile", By.name("File"));
		element("menuitemClose", By.xpath("//*[ @Name='Close' and @LocalizedControlType='menu item']"));
		element("menuedit", By.name("Edit"));
		element("menuaction", By.name("Actions"));
		element("menuitemnew", By.name("New"));
		element("menuitemopen", By.name("Open"));
		element("menuitemexit", By.name("Exit"));
		element("menuitemadd", By.name("Add..."));
		element("menuitemchangetaxnamadd", By.name("Change Tax Name/Address"));
		element("menuitemterminateprovider", By.name("Terminate Provider"));
		element("menuitemchange", By.name("Change..."));
		element("menuitemsave", By.name("Save"));
		element("menuitemdelete", By.name("Delete..."));
		element("menuitemsection", By.name("Section"));
		element("menuitemsubsection", By.name("Subsection"));
		element("dialogbtnyes", By.name("Yes"));
		element("dialogbtnok", By.name("Ok"));
		element("menutransfer", By.name("Transfer"));
		element("menuitemauditinfo", By.name("Audit Information"));
		element("menuView", By.name("View"));
		element("menuItemAccountBalance", By.xpath("//*[@AutomationId='Item 47877']"));

		// provider IPA Indicative page
		element("lnkProviderIPA", By.name("IPA                           "));
		element("txtName", By.xpath("//*[@AutomationId='2110']"));
		element("cmbStatus", By.xpath("//*[@AutomationId='2140']/*[@AutomationId='1']"));
		element("cmbType", By.xpath("//*[@AutomationId='2101']/*[@AutomationId='1']"));
		element("cmbSpeciality", By.xpath("//*[@AutomationId='2131']/*[@AutomationId='1']"));

		// Checkbox name in Address page
		element("lnkProviderIPAAddress", By.name("Addresses"));
		element("listAddress_home", By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item'][1]"));
		element("chkPrimary", By.xpath("//*[@Name='Primary' and @LocalizedControlType='check box']"));
		element("chkPractice", By.xpath("//*[@Name='Practice' and @LocalizedControlType='check box']"));
		element("chkRemit", By.xpath("//*[@Name='Remit' and @LocalizedControlType='check box']"));
		element("chkHandicap", By.xpath("//*[@Name='Handicap' and @LocalizedControlType='check box']"));
		element("chkDirectory", By.xpath("//*[@Name='Directory' and @LocalizedControlType='check box']"));

		// IPA Tax information page
		element("lnkTaxInformation", By.xpath("//*[@Name='Tax Information' and @LocalizedControlType='tree item']"));
		element("txtEffectiveDate_TaxInformation", By.xpath("//*[@AutomationId='102']"));
		element("txtTerminationDate_TaxInformation", By.xpath("//*[@AutomationId='104']"));
		element("txtCorporationID_TaxInformation", By.xpath("//*[@AutomationId='110']"));
		element("txtZipCode_TaxInformation", By.xpath("//*[@AutomationId='2167']"));
		element("txtCity_TaxInformation", By.xpath("//*[@AutomationId='2166']"));
		element("txtCountry_TaxInformation", By.xpath("//*[@AutomationId='2160']"));
		element("txtAddress_TaxInformation", By.xpath("//*[@AutomationId='2171']"));

		// Provider Group
		element("lnkProvider", By.name("Provider                      "));
		element("lnkProviderGroup", By.name("Provider Group                "));

		// Subscriber/Member->Parent Group
		element("txtName_ParentGroup", By.xpath("//*[@AutomationId='2101']"));
		element("cmbType_ParentGroup", By.xpath("//*[@AutomationId='2114']/*[@AutomationId='1']"));
		element("cmbClient_ParentGroup", By.xpath("//*[@AutomationId='2103']/*[@AutomationId='1']"));
		element("txtAddress_ParentGroup", By.xpath("//*[@AutomationId='2171']"));
		element("txtZipCode_ParentGroup", By.xpath("//*[@AutomationId='2167']"));
		element("txtCity_ParentGroup", By.xpath("//*[@AutomationId='2166']"));
		element("txtState_ParentGroup", By.xpath("//*[@AutomationId='2161']"));
		element("txtCounty_ParentGroup", By.xpath("//*[@AutomationId='2160']"));
		element("cmbCountry_ParentGroup", By.xpath("//*[@AutomationId='2175']/*[@AutomationId='1']"));
		// element("txtPhone_ParentGroup", By.xpath("//*[@AutomationId='2159']"));
		element("txtPhone_ParentGroup", By.xpath("//*[@Name='Phone'][5]"));
		element("txtPhoneExt_ParentGroup", By.xpath("//*[@AutomationId='2158']"));
		element("txtFax_ParentGroup", By.xpath("//*[@AutomationId='2157']"));
		element("txtFaxExt_ParentGroup", By.xpath("//*[@AutomationId='2156']"));
		// element("txtEmail_ParentGroup", By.xpath("//*[@AutomationId='2173]"));
		element("txtEmail_ParentGroup", By.xpath("//*[@Name='Country'][2]"));
		element("txtSIC_NAICS_Code_ParentGroup", By.xpath("//*[@AutomationId='2104]"));

		// Subscriber/Member->Group
		element("lnkGroup", By.name("Group                         "));
		element("txtName_Group", By.xpath("//*[@AutomationId='2112']"));
		element("txtParentGroupId_Group", By.xpath("//*[@AutomationId='2116']"));
		element("cmbType_Group", By.xpath("//*[@AutomationId='2130']/*[@AutomationId='1']"));
		element("cmbClient_Group", By.xpath("//*[@AutomationId='2124']/*[@AutomationId='1']"));
		element("cmbStatus_Group", By.xpath("//*[@AutomationId='2127']/*[@AutomationId='1']"));
		element("txtEffectiveDate_Group", By.xpath("//*[@AutomationId='2121']"));
		element("txtMemo_Group", By.xpath("//*[@AutomationId='2105']"));

		// Facility
		element("lnkFacility", By.name("Facility                      "));

		// Network
		element("lnkNetwork", By.name("Networks"));
		element("txtpgnetworktermdate", By.xpath("//*[@AutomationId='106']"));
		element("txtnteffdate", By.xpath("//*[@AutomationId='105']"));

		// Payment Info
		element("lnkPaymentInfo", By.name("Payment Info."));
		element("txtEffectiveDatePay", By.xpath("//*[@AutomationId='2100']"));
		element("cmbClaimPay", By.xpath("//*[@AutomationId='2101']/*[@AutomationId='1']"));
		element("cmbCapitatedPay", By.xpath("//*[@AutomationId='2102']/*[@AutomationId='1']"));

		// provider Facility Indicative page
		element("txtFacilityName", By.xpath("//*[@AutomationId='2105']"));
		element("txtFNPI", By.xpath("//*[@AutomationId='2119']"));
		element("txtFTaxonomyCode", By.xpath("//*[@AutomationId='2127']"));
		element("cmbFType", By.xpath("//*[@AutomationId='2106']/*[@AutomationId='1']"));
		element("cmbFStatus", By.xpath("//*[@AutomationId='2101']/*[@AutomationId='1']"));
		element("cmbFPreauthRequired", By.xpath("//*[@AutomationId='2113']"));

		// Facility Tax information page
		element("txtEffectiveDateFac", By.xpath("//*[@AutomationId='102']"));
		element("txtTerminationDateFac", By.xpath("//*[@AutomationId='104']"));
		element("txtCorporationNameFac", By.xpath("//*[@AutomationId='110']"));
		element("txtZipCodeFac", By.xpath("//*[@AutomationId='2167']"));
		element("txtCityFac", By.xpath("//*[@AutomationId='2166']"));
		element("txtCountryFac", By.xpath("//*[@AutomationId='2160']"));
		element("txtAddressFac", By.xpath("//*[@AutomationId='2171']"));

		// Total List Count
		element("list_home", By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item'][1]"));

		// Group - Create ID card
		element("btnAction", By.name("Actions"));
		element("btnIDcard", By.name("ID Cards"));
		element("btnFamily", By.name("Family"));
		element("cmbIDcardType", By.xpath("//*[@AutomationId='109']/*[@AutomationId='1']"));
		element("cmbIDcardTypeCombo", By.xpath("//*[@AutomationId='109']]"));
		element("cmbCategory", By.xpath("//*[@AutomationId='116']/*[@AutomationId='1']"));
		element("btnRequests", By.name("Requests..."));

		// Group - Subgroups
		element("lnkSubGroups", By.name("Subgroup                      "));
		element("txtName_SubGroup", By.xpath("//*[@AutomationId='2110']"));
		// element("txtParentSubGroupId_SubGroup",
		// By.xpath("//*[@AutomationId='2116']"));
		element("cmbType_SubGroup", By.xpath("//*[@AutomationId='2124']/*[@AutomationId='1']"));
		element("cmbClient_SubGroup", By.xpath("//*[@AutomationId='2124']/*[@AutomationId='1']"));
		element("cmbStatus_SubGroup", By.xpath("//*[@AutomationId='2127']/*[@AutomationId='1']"));
		element("txtEffectiveDate_SubGroup", By.xpath("//*[@AutomationId='2121']"));
		element("txtConverstionDate_SubGroup", By.xpath("//*[@AutomationId='2118']"));
		element("txtMemo_SubGroup", By.xpath("//*[@AutomationId='2104']"));

		// Subcriber/Family page
		element("lnkSubcriberFamily", By.name("Subscriber/Family             "));
		element("lnkMembers",
				By.xpath("//*[(@Name='Members' or @Name='Member') and @LocalizedControlType='tree item']"));
		element("tabCob", By.xpath("//*[@Name='COB' and @LocalizedControlType='tab item']"));
		element("lnkEligibility", By.name("Eligibility"));

		// Create Class
		element("lnkBillingCapInfo", By.name("Billing/Cap Info"));
		element("lnkMedicalPlan", By.name("Medical Plan                  "));
		element("lnkClassDefinitionPlan", By.name("Class/Plan Definition         "));
		element("lnkPlans", By.xpath("//*[@Name='Plans' and @LocalizedControlType='tree item']"));
		element("lnkClassPlan", By.xpath("//*[@Name='Class/Plan' and @LocalizedControlType='tree item']"));
		element("tabEligibility", By.xpath("//*[@Name='Eligibility' and @LocalizedControlType='tab item']"));
		element("lnkSubscriber", By.xpath("//*[@Name='Subscriber' and @LocalizedControlType='tree item']"));
		element("btnYes", By.name("Yes"));
		element("txtBirthDate", By.xpath("//*[@AutomationId='2112']"));
		element("lnkCOBCarrier", By.name("COB Carrier                   "));

		// Enrollment
		element("lnkEnrollment",
				By.xpath("//*[@Name='Enrollment                    ' and @LocalizedControlType='tree item']"));
		element("btnScrollDown", By.xpath("//*[@Name='Forward by small amount' and @LocalizedControlType='button']"));
		element("btnNext", By.name("Next "));
		element("tabMedicare", By.xpath("//*[@Name='Medicare' and @LocalizedControlType='tab item']"));
		element("txtMedicare", By.xpath("//*[@AutomationId='403']"));
		element("lnkPractitioner", By.name("Practitioner                  "));
		element("lnkClass", By.xpath("//*[@Name='Class' and @LocalizedControlType='tree item']"));
		element("btnScrollUp", By.xpath("//*[@Name='Back by small amount' and @LocalizedControlType='button']"));
		element("btnCOB", By.xpath("//*[@Name='COB' and @LocalizedControlType='button']"));
		element("btnPCP", By.xpath("//*[@Name='PCP' and @LocalizedControlType='button']"));
		element("btnEligibility", By.xpath("//*[@Name='Eligibility' and @LocalizedControlType='button']"));
		element("lnkMassPlanChange",
				By.xpath("//*[@Name='Mass Plan Change              ' and @LocalizedControlType='tree item']"));
		element("lnkHistory", By.xpath("//*[@Name='History' and @LocalizedControlType='tree item']"));
		element("lnkStopAges_WaitingPeriod",
				By.xpath("//*[@Name='Stop Ages/Waiting Periods     ' and @LocalizedControlType='tree item']"));
		element("btnApply", By.name("Apply"));
		element("lnkRelatedEntity",
				By.xpath("//*[@Name='Related Entity                ' and @LocalizedControlType='tree item']"));

		// Enrollment and Maintenance
		element("lnkEnrandMain", By.name("Enrollment and Maintenance    "));
		element("lnkCommonPractitioner", By.name("Common Practitioner"));

		// Medical product
		element("lnkProduct",
				By.xpath("//*[@Name='Product                       ' and @LocalizedControlType='tree item']"));
		element("lnkBusinessInfo", By.xpath("//*[@Name='Business Info' and @LocalizedControlType='tree item']"));
		element("btnOK_ID2", By.xpath("//*[(@Name='OK' and @LocalizedControlType='button') and (@AutomationId='2')]"));
		element("txtpgaddtermdate", By.xpath("//*[@AutomationId='106']"));

		// Billing
		element("lnkBilling",
				By.xpath("//*[@Name='Billing                       ' and @LocalizedControlType='tree item']"));
		element("lnkBillingEntity",
				By.xpath("//*[@Name='Billing Entity                ' and @LocalizedControlType='tree item']"));
		element("lnkBillingDefinition",
				By.xpath("//*[@Name='Billing Definition' and @LocalizedControlType='tree item']"));
		element("tabProcessingParms", By.xpath("//*[@Name='Processing Parms' and @LocalizedControlType='tab item']"));
		element("tabBillingParms", By.xpath("//*[@Name='Billing Parms' and @LocalizedControlType='tab item']"));
		element("tabFundedInvoiceParms",
				By.xpath("//*[@Name='Funded Invoice Parms' and @LocalizedControlType='tab item']"));
		element("titleAccountBalance", By.xpath("//*[@Name='Account Balances' and @LocalizedControlType='title bar']"));
		element("lnkReceiptProcessing",
				By.xpath("//*[@Name='Receipt Processing            ' and @LocalizedControlType='tree item']"));
		element("lnkReceiptHistory",
				By.xpath("//*[@Name='Receipt History               ' and @LocalizedControlType='tree item']"));
		element("lnkReceiptTransfer",
				By.xpath("//*[@Name='Receipts Transfer             ' and @LocalizedControlType='tree item']"));
		element("lnkBatchReceipts",
				By.xpath("//*[@Name='Batch Receipts                ' and @LocalizedControlType='tree item']"));
		element("lnkBillingSummary",
				By.xpath("//*[@Name='Billing Summary               ' and @LocalizedControlType='tree item']"));
		element("tabContractSubtotals",
				By.xpath("//*[@Name='Contract Subtotals' and @LocalizedControlType='tab item']"));
		element("lnkBillingProfile",
				By.xpath("//*[@Name='Billing Profile               ' and @LocalizedControlType='tree item']"));
		element("lnkDiscretionaryBilling",
				By.xpath("//*[@Name='Discretionary Billing Items   ' and @LocalizedControlType='tree item']"));
		element("lnkBillingMessage",
				By.xpath("//*[@Name='Billing Message Definition    ' and @LocalizedControlType='tree item']"));

		// Commission
		element("lnkCommission",
				By.xpath("//*[@Name='Commission                    ' and @LocalizedControlType='tree item']"));
		element("lnkCommonCommissionEntity",
				By.xpath("//*[@Name='Common Commission Entity      ' and @LocalizedControlType='tree item']"));
		element("lnkCommissionEntity",
				By.xpath("//*[@Name='Commission Entity             ' and @LocalizedControlType='tree item']"));
		element("lnkRelationships", By.xpath("//*[@Name='Relationships' and @LocalizedControlType='tree item']"));
		element("lnkCommissionArrangement",
				By.xpath("//*[@Name='Commission Arrangement       ' and @LocalizedControlType='tree item']"));
		element("lnkAgreements", By.xpath("//*[@Name='Agreements' and @LocalizedControlType='tree item']"));
		element("lnkCommissionSchedule",
				By.xpath("//*[@Name='Commission Schedule           ' and @LocalizedControlType='tree item']"));
		element("lnkDurations", By.xpath("//*[@Name='Durations' and @LocalizedControlType='tree item']"));
		element("lnkCommissionAdjustments",
				By.xpath("//*[@Name='Commission Adjustments        ' and @LocalizedControlType='tree item']"));

		// Medical plan
		element("lnkMedicalPlan",
				By.xpath("//*[@Name='Medical Plan                  ' and @LocalizedControlType='tree item']"));
		element("lnkAlternateFundingRules",
				By.xpath("//*[@Name='Alternate Funding Rules       ' and @LocalizedControlType='tree item']"));
		element("lnkExcludedServices",
				By.xpath("//*[@Name='Excluded Services' and @LocalizedControlType='tree item']"));
		element("lnkExcludedDiagnoses",
				By.xpath("//*[@Name='Excluded Diagnoses' and @LocalizedControlType='tree item']"));
		element("lnkBillingComponent",
				By.xpath("//*[@Name='Billing Component             ' and @LocalizedControlType='tree item']"));
		element("lnkPremiumRateTable",
				By.xpath("//*[@Name='Premium Rate Table            ' and @LocalizedControlType='tree item']"));

		// Appeal
		element("lnkCustomerService",
				By.xpath("//*[@Name='Customer Service              ' and @LocalizedControlType='tree item']"));
		element("lnkAppeals",
				By.xpath("//*[@Name='Appeals                       ' and @LocalizedControlType='tree item']"));
		element("lnkAppealsSection", By.xpath("//*[@Name='Appeal' and @LocalizedControlType='tree item']"));
		element("txtTerminationDate_Group", By.xpath("//*[@Name='Reason' and @AutomationId='2102']"));
		element("btnLinks", By.xpath("//*[@Name='Links' or @AutomationId='2114'"));
		element("lnkAppealsContact",
				By.xpath("//*[@Name='Appeals Contact               ' and @LocalizedControlType='tree item']"));
		element("lnkContact", By.xpath("//*[@Name='Contacts' and @LocalizedControlType='tree item']"));
		element("lnkLevelIndicative", By.xpath("//*[@Name='Level Indicative' and @LocalizedControlType='tree item']"));
		element("lnkAppealsReviewer",
				By.xpath("//*[@Name='Appeals Reviewer              ' and @LocalizedControlType='tree item']"));

		element("warningmessage", By.xpath("//*[@Name='Warning Messages' and @LocalizedControlType='title bar']"));
		element("subscriberselection",
				By.xpath("//*[@Name='Subscriber Search' and @LocalizedControlType='title bar']"));

		element("txtInitiationDate", By.xpath("//*[@Name='Reason'][2]"));
		element("txtInitiationTime", By.xpath("//*[@Name='Assigned Users'][2]"));
		element("txtDecisionDate", By.xpath("//*[@Name='by'][7]"));
		element("txtDecisionTime", By.xpath("//*[@Name='Decision Due'][4]"));

		element("lnkCustomerService1",
				By.xpath("//*[@Name='Customer Service              ']/*[@Name='Customer Service              '][1]"));
		element("tabMyToDoList", By.xpath("//*[@Name='My To Do List' and @LocalizedControlType='tab item']"));

		element("cmbPrimaryCustomerService", By.xpath("//*[@AutomationId='2148']/*[@AutomationId='1']"));

		// group ID
		element("boxGroupId", By.id("160"));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.
	 * ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}
	// **********************************************************************************************//
	// General critiria - Below is resuable function, so we need to pass ObjRep
	// 1.Function will check checkbox enability - Selected or Not Selected
	// 2.Function is used to open subscriber, provider or any application
	// 3.Function used to compare text from Facet application and other from
	// datatable
	// **********************************************************************************************//

	// 1.Function will check checkbox enability - Selected or Not Selected
	public void checboxEnability(String checkbox, String Text, int i) throws InterruptedException {
		String chkBoxStatus1;
		try {

			String chkBoxName = element(checkbox).getAttribute("Name");
			// System.out.println("getAttribute name "+chkBoxName);

			Boolean chkBoxStatus = element(checkbox).isSelected();
			// System.out.println("isSelected "+chkBoxStatus);

			if (chkBoxStatus == true) {
				chkBoxStatus1 = "Selected";
			} else {
				chkBoxStatus1 = "Not Selected";
			}

			System.out.println("Check box name " + chkBoxName + " is " + chkBoxStatus1 + " " + Text + " " + Header_Data1
					+ " for List item " + i);
			Report.log("Check box name " + chkBoxName + " is " + chkBoxStatus1 + " " + Text + " " + Header_Data1
					+ " for List item " + i, Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not navigated to targetted page", Status.FAIL);
		}
	}

	// 2.Function is used to open subscriber, provider or any application
	public void openApplication(DataProvider dp, String group) throws InterruptedException {
		try {
			element("btnFile").click();
			element("btnOpen").click();
			element("txtApplicationID").sendKeys(group);
			element("btnOK").click();
			Report.log("openApplication is Displaying", Status.Pass);
		} catch (Exception e) {
			Report.log("openApplication is not working", Status.FAIL);
		}

	}

	// 3.Function used to compare text from Facet application and other from
	// datatable
	public void compare_Text(String ObjRep, String getdata, String Data_From_Datatable, String Text) {
		String blank_Text = " ";
		if (Data_From_Datatable == "") {
			blank_Text = " Blank(No Data Available) ";
		}
		try {
			if (getdata == "getText") {
				Data_From_FacetsApplication = element(ObjRep).getText().trim();
			} else if (getdata == "getAttribute") {
				Data_From_FacetsApplication = element(ObjRep).getAttribute("Name").trim();
			}

			// String web2=element(Data_From_FacetsApplication1).getAttribute("Name");
			// System.out.println("Data_From_FacetsApplication xx
			// "+Data_From_FacetsApplication);
			// System.out.println("Data_From_Datatable xx "+Data_From_Datatable);
			String Data_To_Compare = Data_From_Datatable;
			if (Data_From_FacetsApplication.equals(Data_To_Compare)) {
				System.out.println(Text + " " + Data_From_FacetsApplication + blank_Text
						+ " Compared to status in datasheet," + Data_To_Compare + blank_Text + " is equal");
				Report.log(Text + " " + Data_From_FacetsApplication + blank_Text + " is Displaying", Status.Pass);
			}
		} catch (Exception e) {
			Report.log(Text + " " + Data_From_FacetsApplication + blank_Text + " is not Displaying", Status.FAIL);
		}
	}

	public String header_Elements(String HeaderName1, String HeaderName2) {
		try {

			String web2 = element("wblheader").getAttribute("Name");
			int Data1 = web2.indexOf('[');
			int Data1_End = web2.indexOf(']');
			int Data2 = web2.indexOf('[', Data1_End);
			int Data2_End = web2.indexOf(']', Data2);
			int LenofString = web2.length();
			// System.out.println("/n LenofString "+LenofString);
			LenofString = LenofString - 16;
			Header_Data1 = web2.substring(Data1 + 1, Data1_End);
			// System.out.println("/n Data1 is : "+Data1_Exact);
			// System.out.println("/n Data1 before trim : "+Data1_Exact.length());
			Header_Data1 = Header_Data1.trim();
			// System.out.println("Data1 Displaying is: "+Data1_Exact.length());
			System.out.println(HeaderName1 + "  is: " + Header_Data1);
			Report.log(HeaderName1 + "  is: " + Header_Data1, Status.Pass);

			if (HeaderName2 != "") {
				String Data2_Exact = web2.substring(Data2 + 1, Data2_End);
				Data2_Exact = Data2_Exact.trim();
				SubscriberID_Created = Data2_Exact;
				System.out.println(HeaderName2 + "  is: " + Data2_Exact);
				Report.log(HeaderName2 + "  is: " + Data2_Exact, Status.Pass);
			}
		} catch (Exception e) {
			Report.log(HeaderName2 + "  is not Displaying", Status.FAIL);
		}
		return SubscriberID_Created;
	}

	public void select_ListItem(int i) {
		if (i == 1) {
			element("listAddress_home").click();
		}
		try {

			WebElement e = driver
					.findElement(By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item'][" + i + "]"));
			e.click();

			Report.log("List item " + i + " is clicked", Status.Pass);

		} catch (Exception e) {
			Report.log("List item clicked ", Status.DONE);
		}

	}

	public void edit_ListItem(int i) {
		if (i == 1) {
			element("listAddress_home").click();
		}
		try {

			WebElement e = driver
					.findElement(By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item'][" + i + "]"));
			e.click();
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Report.log("List item " + i + " is clicked", Status.Pass);

		} catch (Exception e) {
			Report.log("List item clicked ", Status.DONE);
		}

	}

	public void navigatetoPage(String ObjRep, String Text) throws InterruptedException {
		try {
			element(ObjRep).click();
			element(ObjRep).doubleClick();
			Report.log("Navigated to " + Text, Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not able to navigated to " + Text, Status.FAIL);
		}
	}

	public void clickAnyElement(String ObjRep, String Text) throws InterruptedException {
		try {
			element(ObjRep).click();

			Report.log("Clicked " + Text, Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not able to Click  " + Text, Status.FAIL);
		}
	}

	public void enter_data(String ObjRep, String Text, String Text1) throws InterruptedException {
		try {
			element(ObjRep).click();
			element(ObjRep).sendKeys(Text);
			Report.log("Data Entered as " + "'" + Text + "'" + " " + Text1, Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not able to enter text for  " + Text1, Status.FAIL);
		}
	}

	public void enter_data_new(String ObjRep, String Text, String Text1) throws InterruptedException {
		try {
			element(ObjRep).click();
			element(ObjRep).sendKeys(Text);
			// Report.log("Data Entered as "+"'"+Text+"'"+" "+ Text1, Status.Pass);
			Report.log("Data Entered in Field - " + Text1, Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not able to enter text for  " + Text1, Status.FAIL);
		}
	}

	public void keyBoard_Operation(String Operation, String Text, String Text_Report)
			throws InterruptedException, AWTException {

		Robot r = new Robot();

		try {

			switch (Operation) {
			case "Type":
				System.out.println("/n Text inside is  " + Text);
				element("wblheader").sendKeys(Text);
				Report.log("Data Entered in Field " + Text + " in " + Text_Report, Status.Pass);
				break;

			case "Type_New":
				System.out.println("/n Text inside is  " + Text);
				element("wblheader").sendKeys(Text);
				Report.log("Data Entered in Field - " + Text_Report, Status.Pass);
				break;

			case "Popup_Type_New":
				System.out.println("/n Text inside is  " + Text);
				element("btnClose").sendKeys(Text);
				Report.log("Data Entered in Field - " + Text_Report, Status.Pass);
				break;

			case "Tab":
				r.keyPress(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_TAB);
				break;
			case "Enter":
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				System.out.println("Enter in enter tab");
				break;
			case "Down":
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyRelease(KeyEvent.VK_DOWN);
				break;
			case "Up":
				r.keyPress(KeyEvent.VK_UP);
				r.keyRelease(KeyEvent.VK_UP);
				break;

			case "Right_Arrow":
				r.keyPress(KeyEvent.VK_RIGHT);
				r.keyRelease(KeyEvent.VK_RIGHT);
				break;

			case "Left_Arrow":
				r.keyPress(KeyEvent.VK_LEFT);
				r.keyRelease(KeyEvent.VK_LEFT);
				break;

			case "Space":
				r.keyPress(KeyEvent.VK_SPACE);
				r.keyRelease(KeyEvent.VK_SPACE);
				break;

			case "Backspace":
				r.keyPress(KeyEvent.VK_BACK_SPACE);
				r.keyRelease(KeyEvent.VK_BACK_SPACE);
				break;

			case "Tab_and_Down":
				r.keyPress(KeyEvent.VK_TAB);
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyRelease(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_DOWN);

				break;

			case "Save_Button":
				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_S);
				r.keyRelease(KeyEvent.VK_S);
				r.keyRelease(KeyEvent.VK_CONTROL);
				Report.log("Clicked " + Operation + " button", Status.Pass);
				break;

			case "Page_Down":
				r.keyPress(KeyEvent.VK_PAGE_DOWN);
				r.keyRelease(KeyEvent.VK_PAGE_DOWN);
				break;

			case "Popup_Type":
				System.out.println("/n Text inside is  " + Text);
				element("btnClose").sendKeys(Text);

				Report.log("Entered Data as " + Text + " in " + Text_Report, Status.Pass);
				// Thread.sleep(5000);
				break;
			case "Page_Up":
				r.keyPress(KeyEvent.VK_PAGE_UP);
				r.keyRelease(KeyEvent.VK_PAGE_UP);
				break;

			case "Shift_Tab":
				r.keyPress(KeyEvent.VK_SHIFT);
				r.keyPress(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_SHIFT);
				break;

			case "Click_Letter_A":
				r.keyPress(KeyEvent.VK_A);
				r.keyRelease(KeyEvent.VK_A);
				break;

			case "Click_Letter_M":
				r.keyPress(KeyEvent.VK_M);
				r.keyRelease(KeyEvent.VK_M);
				break;

			case "Clear":
				r.keyPress(KeyEvent.VK_CLEAR);
				r.keyRelease(KeyEvent.VK_CLEAR);
				break;

			case "Select_All":
				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_A);
				r.keyRelease(KeyEvent.VK_A);
				r.keyRelease(KeyEvent.VK_CONTROL);
				// Report.log("Clicked "+Operation+ " button", Status.Pass);
				break;

			case "Alt_and_Down":
				r.keyPress(KeyEvent.VK_ALT);
				r.keyPress(KeyEvent.VK_DOWN);
				r.keyRelease(KeyEvent.VK_ALT);
				r.keyRelease(KeyEvent.VK_DOWN);

				break;

			case "Copy":
				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_C);
				r.keyRelease(KeyEvent.VK_C);
				r.keyRelease(KeyEvent.VK_CONTROL);
				// Report.log("Clicked "+Operation+ " button", Status.Pass);
				break;

			case "Paste":
				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_V);
				r.keyRelease(KeyEvent.VK_V);
				r.keyRelease(KeyEvent.VK_CONTROL);
				// Report.log("Clicked "+Operation+ " button", Status.Pass);
				break;

			case "Click_Letter_P":
				r.keyPress(KeyEvent.VK_P);
				r.keyRelease(KeyEvent.VK_P);
				break;

			}
			// Report.log("Clicked "+Operation+ " button", Status.Pass);
		} catch (Exception e) {
			Report.log("Not able to perform Operation for  " + Operation, Status.FAIL);
		}

	}

	public static void setClipboardData(String string) {
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}

	/*********** Function to Count the rows of List Control ******************/

	public int totalListCount() {
		element("list_home").click();
		try {

			for (int i = 0; i <= TotalListCount; i++) {

				WebElement e = driver.findElement(
						By.xpath("//*[@ClassName='ListBox']/*[@LocalizedControlType='list item']['" + i + "'+1]"));

				e.click();

				String web2 = e.getAttribute("RuntimeId");

				int GroupID_End = web2.indexOf(']');
				// System.out.println("/n first end of ] is : "+GroupID_End);

				int LenofString = web2.length();

				LenofString = LenofString - 2;

				ListCount = web2.substring(GroupID_End - 2, GroupID_End);

				ListCount = ListCount.trim();

				Report.log("Occurance of List is:" + ListCount, Status.Pass);
				int ListCountValue = Integer.valueOf(ListCount);

				if (ListCountValue == LastListCount) {

					break;

				}
				TotalListCount = TotalListCount + 1;
				LastListCount = LastListCount + 1;
			}
		} catch (Exception e) {
			Report.log("Total number of item present in ListBox is: " + TotalListCount, Status.DONE);
		}
		return TotalListCount;
	}

	public void clickSave() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_S);
		r.keyRelease(KeyEvent.VK_S);
		r.keyRelease(KeyEvent.VK_CONTROL);

	}

	public void clickSpaceTab() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_SPACE);
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_SPACE);

	}

	public void clickBackSpace() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_BACK_SPACE);
		r.keyRelease(KeyEvent.VK_BACK_SPACE);
		r.keyRelease(KeyEvent.VK_CONTROL);

	}

	public void mouserightclick() throws AWTException {
		Robot r = new Robot();
		r.mousePress(KeyEvent.BUTTON3_DOWN_MASK);
		r.mouseRelease(KeyEvent.BUTTON3_DOWN_MASK);

	}

	public void mouseleftclick() throws AWTException {
		Robot r = new Robot();
		r.mousePress(KeyEvent.BUTTON1_DOWN_MASK);
		r.mouseRelease(KeyEvent.BUTTON1_DOWN_MASK);

	}

	public void clickShiftE() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_SHIFT);
		r.keyPress(KeyEvent.VK_E);
		r.keyRelease(KeyEvent.VK_E);
		r.keyRelease(KeyEvent.VK_SHIFT);

	}

	public void clickEnter() throws AWTException {

		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);

	}

	public void clickTab() throws AWTException {

		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);

	}

	public void clickCancel() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ALT);
		r.keyPress(KeyEvent.VK_C);
		r.keyRelease(KeyEvent.VK_C);
		r.keyRelease(KeyEvent.VK_ALT);

	}

	public void clickDownArrow() throws AWTException {

		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_DOWN);
		r.keyRelease(KeyEvent.VK_DOWN);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void clickRightArrow() throws AWTException {

		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_RIGHT);
		r.keyRelease(KeyEvent.VK_RIGHT);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean display_Elements(String ObjRep, String Text) throws InterruptedException {
		try {

			status = element(ObjRep).isDisplayed();
			Report.log(Text + " is Displaying ", Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not displaying " + Text, Status.FAIL);
		}

		return status;
	}

	public String current_time() throws InterruptedException {
		LocalDateTime now = LocalDateTime.now();
		int year = now.getYear();
		String year_str = Integer.toString(year);
		int month = now.getMonthValue();
		String month_str = Integer.toString(month);
		int day = now.getDayOfMonth();
		String day_str = Integer.toString(day);
		int hour = now.getHour();
		String hour_str = Integer.toString(hour);
		int minute = now.getMinute();
		String minute_str = Integer.toString(minute);
		int second = now.getSecond();
		String second_str = Integer.toString(second);
		int millis = now.get(ChronoField.MILLI_OF_SECOND);
		String millis_str = Integer.toString(millis);
		String variable_ID = year_str + month_str + day_str + hour_str + minute_str + second_str + millis_str;
		System.out.println("variable_ID is  " + variable_ID);
		return variable_ID;
	}

	// Group ID is created using "AT" is prefix
	// Generated new Group Id using Millisec, seconds, minute, hour
	public String new_GroupID() throws InterruptedException {
		String current_time = current_time();
		GroupID_Created = current_time.substring(current_time.length() - 5);
		GroupID_Created = "TST" + GroupID_Created;
		System.out.println("GroupID is  " + GroupID_Created);
		return GroupID_Created;
	}

	// Clas ID is created using "AT" is prefix
	public String new_ClassID() throws InterruptedException {
		String current_time = current_time();
		ClassID_Created = current_time.substring(current_time.length() - 3);
		ClassID_Created = "S" + ClassID_Created;
		System.out.println("ClassID is  " + ClassID_Created);
		return ClassID_Created;
	}

	// COB Carrier ID is created using "ATC" is prefix
	public String new_COB_CarrierID() throws InterruptedException {
		String current_time = current_time();
		COB_CarrierID_Created = current_time.substring(current_time.length() - 3);
		COB_CarrierID_Created = "ATC" + COB_CarrierID_Created;
		System.out.println("COB Carrier ID is  " + COB_CarrierID_Created);
		return COB_CarrierID_Created;
	}

	// IPAID is created using "ATIPA" is prefix
	public String new_IPA_ID() throws InterruptedException {
		String current_time = current_time();
		IPA_ID_Created = current_time.substring(current_time.length() - 7);
		IPA_ID_Created = "ATIPA" + IPA_ID_Created;
		System.out.println("IPA ID is  " + IPA_ID_Created);
		return IPA_ID_Created;
	}

	// Medicare ID is created using "ATMED" is prefix
	public String new_Medicare_ID() throws InterruptedException {
		String current_time = current_time();
		Medicare_ID_Created = current_time.substring(current_time.length() - 6);
		Medicare_ID_Created = "ATMED" + Medicare_ID_Created;
		System.out.println("Medicare ID is  " + Medicare_ID_Created);
		return Medicare_ID_Created;
	}

	// Any ID is created as passing data in prefix (in Arguments value)
	public String new_ID(String prefix, int prefix_Length, int new_ID_Length, String ID_Name)
			throws InterruptedException {
		String current_time = current_time();
		new_ID_Created = current_time.substring(current_time.length() - (new_ID_Length - prefix_Length));
		new_ID_Created = prefix + new_ID_Created;
		ID_Name = new_ID_Created;
		System.out.println(" ID is  " + new_ID_Created);
		// new_ID_Created=ID_Name+"_ID_Created";
		return ID_Name;
	}

	// Clear the text
	public void clearAnyElement(String ObjRep, String Text) throws InterruptedException {
		try {
			element(ObjRep).clear();

			Report.log("Cleared " + Text, Status.Pass);
		}

		catch (Exception e) {
			Report.log("Not able to Clear  " + Text, Status.FAIL);
		}
	}

	// Closes application
	public void closeApplication() throws InterruptedException {
		try {
			element("menufile").click();
			element("menuitemClose").click();

		} catch (Exception e) {
			Report.log("close Application is not working", Status.FAIL);
		}

	}

	public String header_Data1(String HeaderName1) {
		try {

			String web2 = element("wblheader").getAttribute("Name");
			int Data1 = web2.indexOf('[');
			int Data1_End = web2.indexOf(']');
			// int Data2 = web2.indexOf('[', Data1_End);
			// int Data2_End = web2.indexOf(']', Data2);
			int LenofString = web2.length();
			// System.out.println("/n LenofString "+LenofString);
			LenofString = LenofString - 16;
			Header_Data1 = web2.substring(Data1 + 1, Data1_End);
			// System.out.println("/n Data1 is : "+Data1_Exact);
			// System.out.println("/n Data1 before trim : "+Data1_Exact.length());
			SubscriberID_Created = Header_Data1.trim();
			// String Header_Data_Displayed1 = Header_Data1;
			// System.out.println("Data1 Displaying is: "+Data1_Exact.length());
			System.out.println(HeaderName1 + "  is: " + Header_Data1);
			Report.log(HeaderName1 + "  is: " + Header_Data1, Status.Pass);

		} catch (Exception e) {
			Report.log(HeaderName1 + "  is not Displaying", Status.FAIL);
		}
		return SubscriberID_Created;
	}

	public String getData(String ObjRep, String Text) throws InterruptedException {
		try {
			// System.out.println("Arrived ");
			display_Elements(ObjRep, "displaying");
			// String Data=element(ObjRep).getAttribute("Value");
			String Data = element(ObjRep).getValue();
			System.out.println("Value " + Data);
			// String Data1=element(ObjRep).getAttribute("Text");
			String Data1 = element(ObjRep).getText();

			System.out.println("Text " + Data1);

			String Data3 = element(ObjRep).getAttribute("Value");
			System.out.println("Data3 " + Data3);

			String Data4 = element(ObjRep).getAttribute("Text");
			System.out.println("Data4 " + Data4);
			// Data=Data.trim();

			SubscriberID_Created = Data;
			Report.log(Text + "  is: " + SubscriberID_Created, Status.Pass);

		} catch (Exception e) {
			Report.log(Text + "  is not Displaying" + e, Status.FAIL);
		}
		return SubscriberID_Created;
	}

	public String header_Elements_Facility(String HeaderName1, String HeaderName2) {
		try {

			String web2 = element("wblheader").getAttribute("Name");
			int Data1 = web2.indexOf('[');
			int Data1_End = web2.indexOf(']');
			int Data2 = web2.indexOf('[', Data1_End);
			int Data2_End = web2.indexOf(']', Data2);
			int Data3 = web2.indexOf('[', Data2_End);
			int Data3_End = web2.indexOf(']', Data3);
			int LenofString = web2.length();
			// System.out.println("/n LenofString "+LenofString);
			LenofString = LenofString - 16;
			Header_Data1 = web2.substring(Data1 + 1, Data1_End);
			// System.out.println("/n Data1 is : "+Data1_Exact);
			// System.out.println("/n Data1 before trim : "+Data1_Exact.length());
			Header_Data1 = Header_Data1.trim();
			// System.out.println("Data1 Displaying is: "+Data1_Exact.length());
			System.out.println(HeaderName1 + "  is: " + Header_Data1);
			Report.log(HeaderName1 + "  is: " + Header_Data1, Status.Pass);
			Report.addMetaInfo(HeaderName1, Header_Data1);

			if (HeaderName2 != "") {
				String Data3_Exact = web2.substring(Data3 + 1, Data3_End);
				System.out.println("Data2_Exact " + Data3_Exact);
				Data3_Exact = Data3_Exact.trim();
				SubscriberID_Created = Data3_Exact;
				SubscriberID_Created = Header_Data1 + "," + SubscriberID_Created;
				System.out.println(HeaderName2 + "  is: " + Data3_Exact);
				Report.log(HeaderName2 + "  is: " + Data3_Exact, Status.Pass);
				Report.addMetaInfo(HeaderName2, Data3_Exact);
			}
		} catch (Exception e) {
			Report.log(HeaderName2 + "  is not Displaying", Status.FAIL);
		}
		return SubscriberID_Created;
	}

	public String getelementData(String ele, String Text) {
		String temp = "";
		if (Text.equalsIgnoreCase("GroupID")) {
			String a = element(ele).getAttribute("Name");
			List<String> claimDetailst = parseSquareBraces(a);
			System.out.println(claimDetailst);
				temp = claimDetailst.get(0).trim();
		} else if(Text.equalsIgnoreCase("ClassID")) {
			String a = element(ele).getAttribute("Name");
			List<String> claimDetailst = parseSquareBraces(a);
			System.out.println(claimDetailst);
			temp = claimDetailst.get(1).trim();
			
		} else if (Text.equals("GroupName")) {
			temp = element(ele).getAttribute("Value");
		} else {
			temp = element(ele).getText();
		}
		return temp;
	}

	public void validateGroup(DataProvider dp) {
		Assert.assertEquals(ValidationType.Verify, "Group ID Validation: ", dp.get("GroupID", "txtGroupID"),
				getelementData("boxGroupId", "GroupID"));
		Assert.assertEquals(ValidationType.Verify, "Group Name Validation: ", dp.get("Name", "txtName"),
				dp.get("Name", "txtName"));
	}

	public void validatePlan(DataProvider dp) {
		try {
		if(GroupID_Created != null) {
		Assert.assertEquals(ValidationType.Verify, "Group Validation: ", GroupID_Created,
				getelementData("boxGroupId", "GroupID"));
		} else {
			Assert.assertEquals(ValidationType.Verify, "Group Validation: ", dp.get("GroupID", "txtGroupID"),
					getelementData("boxGroupId", "GroupID"));
		}
		} catch (NullPointerException e) {
			Assert.assertEquals(ValidationType.Verify, "Group Validation: ", dp.get("GroupID", "txtGroupID"),
					getelementData("boxGroupId", "GroupID"));
		}
		Assert.assertEquals(ValidationType.Verify, "Class Validation: ", dp.get("ClassID", "txtClassID"),
				getelementData("boxGroupId", "ClassID"));
		Assert.assertEquals(ValidationType.Verify, "Plan Validation: ", dp.get("Plan", "txtPlan"),
				dp.get("Plan", "txtPlan"));
		
	}

	public void validateSubscriber(DataProvider dp) {
		Assert.assertEquals(ValidationType.Verify, "Subscriber LastName Validation: ",
				dp.get("LastName", "txtLastName"), dp.get("LastName", "txtLastName"));
	}

	public static List<String> parseSquareBraces(String data) {
		List<String> returndata = new ArrayList<String>();
		Matcher m = Pattern.compile("\\[(.*?)\\]").matcher(data);
		while (m.find()) {
			returndata.add(m.group(1));
		}
		return returndata;
	}

}
