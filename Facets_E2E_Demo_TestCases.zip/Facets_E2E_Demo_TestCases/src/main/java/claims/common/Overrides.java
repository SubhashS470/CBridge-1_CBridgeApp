package claims.common;

import org.openqa.selenium.By;

import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

public class Overrides extends WiniumPageObject {
	public Overrides(WrappedWiniumDriver pDriver) {
		super(pDriver);
		element("btnOverrides", By.name("Overrides"));
		element("cmbLineNo", By.id("//*[@AutomationId='7050']/*[@AutomationId='1']"));
		element("btnOk", By.name("OK"));
		element("txtAllowableAmt", By.id("139"));
		element("cmbAllowableAmt", By.id("//*[@AutomationId='102']/*[@AutomationId='1']"));
		element("txtAllowableUnits", By.id("147"));
		element("cmbAllowableUnits", By.xpath("//*[@AutomationId='181']/*[@AutomationId='1']"));
		element("txtAmountPerUnit", By.id("105"));
		element("cmbAmountPerUnit", By.xpath("//*[@AutomationId='101']/*[@AutomationId='1']"));
		element("txtDisallowAmount", By.id("109"));
		element("cmbDisallowAmount", By.xpath("//*[@AutomationId='185']/*[@AutomationId='1']"));
		element("txtHRADeductible", By.id("127"));
		element("cmbHRADeductible", By.xpath("//*[@AutomationId='213']/*[@AutomationId='1']"));
		element("txtHRAPaidAmount", By.id("124"));
		element("cmbHRAPaidAmount", By.xpath("//*[@AutomationId='207']/*[@AutomationId='1']"));
		element("txtCoinsurance", By.id("176"));
		element("cmbCoinsurance", By.xpath("//*[@AutomationId='104']/*[@AutomationId='1']"));
		element("txtCopayment", By.id("108"));
		element("cmbCopayment", By.xpath("//*[@AutomationId='183']/*[@AutomationId='1']"));
		element("txtDeductible", By.id("123"));
		element("cmbDeductible", By.xpath("//*[@AutomationId='184']/*[@AutomationId='1']"));
		element("txtPatientLiabilityDisallow", By.id("126"));
		element("cmbPatientLiabilityDisallow", By.xpath("//*[@AutomationId='211']/*[@AutomationId='1']"));
		element("txtFSAPaidAmount", By.id("125"));
		element("cmbFSAPaidAmount", By.xpath("//*[@AutomationId='208']/*[@AutomationId='1']"));
		element("chkLineItemDenial", By.name("Line Item Denial"));
		element("cmbLineItemDenial", By.xpath("//*[@AutomationId='234']/*[@AutomationId='1']"));
		element("chkBypassPlanLimits", By.name("Bypass Plan Limits"));
		element("cmbBypassPlanLimits", By.xpath("//*[@AutomationId='106']/*[@AutomationId='1']"));
		element("chkEligibility", By.name("Eligibility"));
		element("cmbEligibility", By.xpath("//*[@AutomationId='107']/*[@AutomationId='1']"));
		element("chkOverideClinicalEditDisallow", By.name("Override Clinical Edit Disallow"));
		element("txtOverideClinicalEditDisallow", By.xpath("//*[@AutomationId='114']/*[@AutomationId='1']"));
		element("chkOverrideUtilizationEditDisallow", By.name("Override Utilization Edit Disallow"));
		element("cmbOverrideUtilizationEditDisallow", By.xpath("//*[@AutomationId='119']/*[@AutomationId='1']"));
		element("chkOverrideDiagnosisDisallow", By.name("Override Diagnosis Disallow"));
		element("cmbOverrideDiagnosisDisallow", By.xpath("//*[@AutomationId='132']/*[@AutomationId='1']"));
		element("chkOverridePCADisallow", By.name("Override PCA Disallow  "));
		element("cmbOverridePCADisallow", By.xpath("//*[@AutomationId='130']/*[@AutomationId='1']"));
		element("txtTypeOfService", By.id("121"));
		element("cmbTypeOfService", By.xpath("//*[@AutomationId='112']/*[@AutomationId='1']"));
		element("txtServiceRule", By.id("122"));
		element("cmbServiceRule", By.xpath("//*[@AutomationId='115']/*[@AutomationId='1']"));
		element("chkBypassDuplicateEdit", By.name("Bypass Duplicate Edit"));
		element("cmbBypassDuplicateEdit", By.xpath("//*[@AutomationId='110']/*[@AutomationId='1']"));
		element("chkBypassGlobalCaseRate", By.name("Bypass Global Case Rate"));
		element("cmbBypassGlobalCaseRate", By.xpath("//*[@AutomationId='117']/*[@AutomationId='1']"));
		element("cmbPaymentLevel", By.xpath("//*[@AutomationId='113']/*[@AutomationId='1']"));
		element("cmbPaymentLevelExplanation", By.xpath("//*[@AutomationId='111']/*[@AutomationId='1']"));
		element("txtAddNetworkXData", By.id("120"));
		element("cmbAddNetworkXData", By.xpath("//*[@AutomationId='210']/*[@AutomationId='1']"));
		element("txtVariableComponentTier", By.id("128"));
		element("cmbVariableComponentTier", By.xpath("//*[@AutomationId='118']/*[@AutomationId='1']"));
		element("chkBypassBenefitCalculationDate", By.name("Bypass Benefit Calculation Date"));
		element("cmbBypassBenefitCalculationDate", By.xpath("//*[@AutomationId='203']/*[@AutomationId='1']"));
		element("chkBypassOtherPartyLiabilityDisallow", By.name("Bypass Oth. Party Liab Disallow"));
		element("cmbBypassOtherPartyLiabilityDisallow", By.xpath("//*[@AutomationId='204']/*[@AutomationId='1']"));
		element("chkBypassValueBasedBenefits", By.name("Bypass Value Based Benefits"));
		element("cmbBypassValueBasedBenefits", By.xpath("//*[@AutomationId='217']/*[@AutomationId='1']"));
		element("cmbCapitationIndicator", By.xpath("//*[@AutomationId='129']/*[@AutomationId='1']"));
		element("cmbCapitationIndicatorExplanation", By.xpath("//*[@AutomationId='229']/*[@AutomationId='1']"));
		element("cmbFundID", By.xpath("//*[@AutomationId='131']/*[@AutomationId='1']"));
		element("cmbFundIDExplanation", By.xpath("//*[@AutomationId='230']/*[@AutomationId='1']"));
		element("chkExternalReferral", By.name("External Referral"));
		element("cmbExternalReferral", By.xpath("//*[@AutomationId='198']/*[@AutomationId='1']"));
		element("chkReferralNotRequired", By.name("Referral Not Required  "));
		element("cmbReferralNotRequired", By.xpath("//*[@AutomationId='191']/*[@AutomationId='1']"));
		element("chkPreAuthNotRequired", By.name("Pre-Auth Not Required  "));
		element("txtPreAuthNotRequired", By.id("190"));
		element("chkPreAuthViolation", By.name("Ref/Pre-Auth Violation"));
		element("cmbPreAuthViolation", By.xpath("//*[@AutomationId='195']/*[@AutomationId='1']"));
		// Claim Page under Overrides
		element("btnClaim", By.name("Claim"));
	}

	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void navigateToOverrides() {
		element("btnOverrides").click();
	}

	public void navigateToClaimOverride() {
		element("btnClaim").click();
	}

	public void enterLineNo(int i) {
		String line = String.valueOf(i);
		element("cmbLineNo").type(line);
		element("cmbLineNo").pressTab();
	}

	public void overideAllowable(DataProvider dp, String group) {
		element("txtAllowableAmt").sendKeys(dp.get(group, "AllowableAmt"));
		element("txtAllowableAmt").pressTab();
		element("cmbAllowableAmt").type(dp.get(group, "AllowableAmtExp"));
		element("cmbAllowableAmt").pressTab();
	}

	public void overideAllowableUnits(DataProvider dp, String group) {
		element("txtAllowableUnits").sendKeys(dp.get(group, "AllowableUnits"));
		element("txtAllowableUnits").pressTab();
		element("cmbAllowableUnits").type(dp.get(group, "AllowableUnitsExp"));
		element("cmbAllowableUnits").pressTab();
	}

	public void overideAmountPerUnit(DataProvider dp, String group) {
		element("txtAmountPerUnit").sendKeys(dp.get(group, "AmountPerUnit"));
		element("txtAmountPerUnit").pressTab();
		element("cmbAmountPerUnit").type(dp.get(group, "AmountPerUnitExp"));
		element("cmbAmountPerUnit").pressTab();
	}

	public void overideDisallowAmount(DataProvider dp, String group) {
		element("txtDisallowAmount").sendKeys(dp.get(group, "DisallowAmount"));
		element("txtDisallowAmount").pressTab();
		element("cmbDisallowAmount").type(dp.get(group, "DisallowAmountExp"));
		element("cmbDisallowAmount").pressTab();
	}

	public void overideHRADeductible(DataProvider dp, String group) {
		element("txtHRADeductible").sendKeys(dp.get(group, "HRADeductible"));
		element("txtHRADeductible").pressTab();
		element("cmbHRADeductible").type(dp.get(group, "HRADeductibleExp"));
		element("cmbHRADeductible").pressTab();
	}

	public void overideHRAPaidAmount(DataProvider dp, String group) {
		element("txtHRAPaidAmount").sendKeys(dp.get(group, "HRAPaidAmount"));
		element("txtHRAPaidAmount").pressTab();
		element("cmbHRAPaidAmount").type(dp.get(group, "HRAPaidAmountExp"));
		element("cmbHRAPaidAmount").pressTab();
	}

	public void overideCoinsurance(DataProvider dp, String group) {
		element("txtCoinsurance").sendKeys(dp.get(group, "Coinsurance"));
		element("txtCoinsurance").pressTab();
		element("cmbCoinsurance").type(dp.get(group, "CoinsuranceExp"));
		element("cmbCoinsurance").pressTab();
	}

	public void overideCopayment(DataProvider dp, String group) {
		element("txtCopayment").sendKeys(dp.get(group, "Copayment"));
		element("txtCopayment").pressTab();
		element("cmbCopayment").type(dp.get(group, "CopaymentExp"));
		element("cmbCopayment").pressTab();
	}

	public void overideDeductible(DataProvider dp, String group) {
		element("txtDeductible").sendKeys(dp.get(group, "Deductible"));
		element("txtDeductible").pressTab();
		element("cmbDeductible").type(dp.get(group, "DeductibleExp"));
		element("cmbDeductible").pressTab();
	}

	public void overidePatientLiabilityDisallow(DataProvider dp, String group) {
		element("txtPatientLiabilityDisallow").sendKeys(dp.get(group, "PatientLiabilityDisallow"));
		element("txtPatientLiabilityDisallow").pressTab();
		element("cmbPatientLiabilityDisallow").type(dp.get(group, "PatientLiabilityDisallowExp"));
		element("cmbPatientLiabilityDisallow").pressTab();
	}

	public void overideFSAPaidAmount(DataProvider dp, String group) {
		element("txtFSAPaidAmount").sendKeys(dp.get(group, "FSAPaidAmount"));
		element("txtFSAPaidAmount").pressTab();
		element("cmbFSAPaidAmount").type(dp.get(group, "FSAPaidAmountExp"));
		element("cmbFSAPaidAmount").pressTab();
	}

	public void overideLineItemDenial() throws InterruptedException {
		element("chkLineItemDenial").enterValueinDropdown("079");
	}

	public void bypassPlanLimits() throws InterruptedException {
		element("chkBypassPlanLimits").enterValueinDropdown("008");
	}

	public void eligibility() throws InterruptedException {
		element("chkEligibility").enterValueinDropdown("022");
	}

	public void overideClinicalEditDisallow() throws InterruptedException {
		element("chkOverideClinicalEditDisallow").enterValueinDropdown("029");
	}

	public void overideUtilizationEditDisallow() throws InterruptedException {
		element("chkOverrideUtilizationEditDisallow").enterValueinDropdown("MUT");
	}

	public void overideDiagnosisDisallow() throws InterruptedException {
		element("chkOverideDiagnosisDisallow").enterValueinDropdown(""); // No value listed in Dropdown
	}

	public void overideOverridePCADisallow() throws InterruptedException {
		element("chkOverridePCADisallow").enterValueinDropdown("OPC");
	}

	public void overideTypeOfService(DataProvider dp, String group) {
		element("txtTypeOfService").sendKeys(dp.get(group, "TypeOfService"));
		element("txtTypeOfService").pressTab();
		element("cmbTypeOfService").type(dp.get(group, "TypeOfServiceExp"));
		element("cmbTypeOfService").pressTab();
	}

	public void overideServiceRule(DataProvider dp, String group) {
		element("txtServiceRule").sendKeys(dp.get(group, "ServiceRule"));
		element("txtServiceRule").pressTab();
		element("cmbServiceRule").type(dp.get(group, "ServiceRuleExp"));
		element("cmbServiceRule").pressTab();
	}

	public void bypassDuplicateEdit() throws InterruptedException {
		element("chkBypassDuplicateEdit").enterValueinDropdown("020");
	}

	public void bypassGlobalCaseRate() throws InterruptedException {
		element("chkBypassGlobalCaseRate").enterValueinDropdown("GLD");
	}

	public void overidePaymentLevel(DataProvider dp, String group) {
		element("cmbPaymentLevel").sendKeys(dp.get(group, "PaymentLevel"));
		element("cmbPaymentLevel").pressTab();
		element("cmbPaymentLevelExplanation").type(dp.get(group, "PaymentLevelExp"));
		element("cmbPaymentLevelExplanation").pressTab();
	}

	public void overideAddNetworkXData(DataProvider dp, String group) {
		element("txtAddNetworkXData").sendKeys(dp.get(group, "AddNetworkXData"));
		element("txtAddNetworkXData").pressTab();
		element("cmbAddNetworkXData").type(dp.get(group, "AddNetworkXDataExp"));
		element("cmbAddNetworkXData").pressTab();
	}

	public void overideVariableComponentTier(DataProvider dp, String group) {
		element("txtVariableComponentTier").sendKeys(dp.get(group, "VariableComponentTier"));
		element("txtVariableComponentTier").pressTab();
		element("cmbVariableComponentTier").type(dp.get(group, "VariableComponentTierExp"));
		element("cmbVariableComponentTier").pressTab();
	}

	public void bypassBenefitCalculationDate() throws InterruptedException {
		element("chkBypassBenefitCalculationDate").enterValueinDropdown("PBB");
	}

	public void bypassOtherPartyLiabilityDisallow() throws InterruptedException {
		element("chkBypassOtherPartyLiabilityDisallow").enterValueinDropdown("PLO");
	}

	public void bypassValueBasedBenefits() throws InterruptedException {
		element("chkBypassValueBasedBenefits").enterValueinDropdown("VBB");
	}

	public void overideCapitationIndicator(DataProvider dp, String group) {
		element("cmbCapitationIndicator").sendKeys(dp.get(group, "CapitationIndicator"));
		element("cmbCapitationIndicator").pressTab();
		element("cmbCapitationIndicatorExplanation").type(dp.get(group, "CapitationIndicatorExp"));
		element("cmbCapitationIndicatorExplanation").pressTab();
	}

	public void overideFundID(DataProvider dp, String group) {
		element("cmbFundID").sendKeys(dp.get(group, "FundID"));
		element("cmbFundID").pressTab();
		element("cmbFundIDExplanation").type(dp.get(group, "FundIDExp"));
		element("cmbFundIDExplanation").pressTab();
	}

	public void externalReferral() throws InterruptedException {
		element("chkExternalReferral").enterValueinDropdown("EXR");
	}

	public void referralNotRequired() throws InterruptedException {
		element("chkReferralNotRequired").enterValueinDropdown("037");
	}

	public void preAuthNotRequired() throws InterruptedException {
		element("chkPreAuthNotRequired").enterValueinDropdown("036");
	}

	public void preAuthViolation() throws InterruptedException {
		element("chkPreAuthViolation").enterValueinDropdown("040");
	}

	public void clickOk() {
		element("btnOk").click();
	}

	public void applyOverrides(DataProvider dp, int lines) throws InterruptedException {
		Report.log("Overrides - Lines", Status.BUSINESSSTEP);
		for (int i = 1; i <= lines; i++) {			
			navigateToOverrides();
			enterLineNo(i);
			overideAllowable(dp, "Override");
			overideAllowableUnits(dp, "Override");
			overideClinicalEditDisallow();
			preAuthNotRequired();
			bypassDuplicateEdit();
			clickOk();
		}
		Report.closeBusinessStep();
	}

}
