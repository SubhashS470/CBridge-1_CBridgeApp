package claims.common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cts.qea.automation.Assert;
import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;
import tmg.qea.custom.data.PatternHelper;

public class CommonActions extends WiniumPageObject {
	public String errMsg = "";

	public CommonActions(WrappedWiniumDriver pDriver) {
		super(pDriver);

		element("lblStatusBar", By.id("59393"));
		element("lblClaimDetails", By.id("160"));
		element("txtClaimID", By.name("Claim ID"));
		element("btnFile", By.name("File"));
		element("btnOpen", By.name("Open"));
		element("btnOk", By.name("OK"));
		element("btnYes", By.name("Yes"));
		element("btnNo", By.name("No"));
		element("btnCancel", By.name("Cancel"));
		element("btnClose", By.name("Close"));
		element("lnkLineItem", By.xpath(".//*[@Name='Line Item' and @ControlType='ControlType.TabItem']"));
		element("lblLineDetail", By.id("2005"));
		element("lnkLineItems", By.name("Line Items"));
		// Pend Input
		element("txtReviewDate", By.xpath("//*[@AutomationId='105']"));
		element("lstReviewReason", By.xpath("//*[@AutomationId='104']/*[@AutomationId='1']"));
		// Error Message window
		element("wndErrorMsg", By.name("Error Messages"));
		// Warning window
		element("wndWarningMsg", By.name("Warning Messages"));
		element("lstWarningMsg", By.className("ListBox"));
		element("lstWarnMsgs", By.xpath("//*[@ControlType='ControlType.ListItem']"));
		// Open Claim Already opened by someone
		element("wndAlreadyOpen", By.xpath(".//*[@Name='File Reservation' and @ControlType='Dialog']"));
		element("boxLineItemNotes", By.id("2101"));
		// Price Calculation
		element("boxPriceCalculation", By.id("2000"));
		element("tabPriceCalculation", By.name("Price Calculation"));
		// GridBox
		element("txtGridBox", By.id("2100"));
		// Claim totals
		element("lnkClaimTotals", By.id("2103"));
		// ActionTab
		element("tabAction", By.id("Item 3"));
		element("tabClaimAdjustReason", By.id("Item 47943"));
		element("boxClaimAdjustReason", By.name("Claim Adjustment Reason"));
		element("chkClaimAdjust", By.id("122"));
		element("cmbClaimAdjust", By.id("123"));
		// OverrideTab
		element("tabOverride", By.name("Override"));
		element("tabClaim", By.id("Item 47877"));
		element("chkBypassDuplicateEdit", By.id("148"));
		element("cmbBypassDuplicateEdit", By.id("149"));
		// EditTab
		element("tabEdit", By.id("Item 2"));
		element("tabAdd", By.id("Item 29278"));
		element("txtAttachmentDescription", By.id("200"));
		element("txtClaimNote", By.id("101"));
		// EOB
		element("btnEOB", By.id("2105"));
		element("wndEOBbox", By.id("101"));
		element("wndEOBLineItemPane", By.id("102"));
		element("cmbLineNo", By.xpath("//*[@AutomationId='7050']/*[@AutomationId='1']"));
		// Notes
		element("subtabNotes", By.name("Notes"));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.
	 * ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	// Opening a claim
	public void openClaim(DataProvider dp, String group) throws InterruptedException {
		Report.log("Opening the Claim: " + dp.get(group, "txtClaimID"), Status.BUSINESSSTEP);
		element("btnFile").click();
		element("btnOpen").click();
		element("txtClaimID").sendKeys(dp.get(group, "txtClaimID"));
		element("btnOK").click();
		Report.closeBusinessStep();
	}

	public void duplicateClaim() {
		element("txtClaimID").pressKey(KeyEvent.VK_F8);
	}

	public void checkClaimStatus() {
		Report.log("Extract Claim Status from Facets", Status.BUSINESSSTEP);
		String claimState = "";
		String claimData = element("lblClaimDetails").getAttribute("Name");
		try {
			List<String> claimDetailst = PatternHelper.parseSquare(claimData);
			// System.out.println(claimDetailst);
			String temp = claimDetailst.get(2);
			// System.out.println(temp);
			claimState = temp.split(";")[0];
			Report.log("Claim State : " + claimState, Status.PASS);
		} catch (Exception e) {
			Report.log("Error occured while extracting claim Status - " + e, Status.Fail);
		}
		Report.closeBusinessStep();
	}

	public boolean adjudicateClaims(String caseType) throws Exception {
		boolean adjudicateFlag = false;
		Report.log("Adjudicate Claims", Status.BUSINESSSTEP);
		element("lblStatusBar").pressKey(KeyEvent.VK_F3);
		if (element("wndErrorMsg").isDisplayed()) {
			if (caseType.equals("pend")) {
				Report.log("Error Message displayed while Adjudication", Status.KEYWORD);
				adjudicateFlag = true;
			} else if (caseType.equals("save")) {
				Report.log("Error Message displayed while Adjudication", Status.Fail);
				adjudicateFlag = false;
			}
			getErrorWndMsg();
		} else {
			adjudicateFlag = true;
		}
		getWarningWndMsg();
		Report.log("Adjudication process completed", Status.KEYWORD);
		Report.closeBusinessStep();
		return adjudicateFlag;
	}

	public String saveClaims() throws InterruptedException {
		String claimID = "";
		Report.log("Save Claims", Status.BUSINESSSTEP);
		element("lblStatusBar").pressKey(KeyEvent.VK_F4);
		if (element("btnYes").isDisplayed()) {
			element("btnYes").click();
			Report.log("Claim Auto Pended when F4 pressed", Status.KEYWORD);
		}
		// Read claim status
		claimID = readStatusBar();
		Report.closeBusinessStep();
		return claimID;
	}

	private String readStatusBar() {
		String claimID = "";
		String claimStatus = "";
		boolean flag = false;
		do {
			String data = element("lblStatusBar").getAttribute("Name");
			try {
				// extract claim id
				claimID = data.split(":")[1];
				// extract claim status
				claimStatus = data.split(":")[0];
				flag = false;
			} catch (ArrayIndexOutOfBoundsException e) {
				flag = true;
			}
		} while (flag);
		if (claimStatus.equals("Ready...Last Claim Accepted")) {
			Report.log("Claim Status :" + claimStatus, Status.KEYWORD);
		} else if (claimStatus.equals("Ready...Last Claim Pended")) {
			Report.log("Claim Status :" + claimStatus, Status.KEYWORD);
		} else {
			Report.log("Claim Status :" + claimStatus, Status.KEYWORD);
		}
		Report.log("Claim ID: " + claimID, Status.Pass);
		Report.log("label", "Claim ID: " + claimID);
		Report.addMetaInfo("Claim ID", claimID);
		return claimID;
	}

	public void navigateToLineItemTab() {
		element("lnkLineItem").click();
	}

	public void stripLineItemData(DataProvider dp, String group, int line, String claimType) {
		Report.log("Validate Line Item: " + line, Status.BUSINESSSTEP);
		String actualAllowed = "";
		String actualCopay = "";
		String actualDeductible = "";
		String actualCoinsurance = "";
		// Expected Copay Extraction
		float temp = Float.parseFloat(dp.get("PreRequisite", "SETR_COPAY_AMT"));
		String copay = "$" + String.format("%.2f", temp);
		dp.set(group, "expectedCopay", copay);
		// Expected Coinsurance Extraction
		float data1 = Float.parseFloat(dp.get("PreRequisite", "SETR_COIN_PCT"));
		float data2 = Float.parseFloat(dp.get("PreRequisite", "CDML_ALLOW"));
		float data = ((100 - data1) / 100) * data2;
		String coinsurance = "$" + String.format("%.2f", data);
		dp.set(group, "expectedCoinsurance", coinsurance);
		if (claimType.equals("Med")) {
			navigateToMedGrid();
		} else if (claimType.equals("Hosp")) {
			navigateToHospGrid();
		}

		gotoLine(line);

		element("lnkLineItem").click();

		String originaldata = element("lblLineDetail").getText();
		System.out.println(originaldata);
		getValue(dp, group + "req", "Considered Charge", originaldata, "Considered Charge", "Deductible", 0);
		getValue(dp, group + "req", "Units", originaldata, "Units", "Copay", 0);
		getValue(dp, group + "req", "Benefit", originaldata, "Benefit", "Disallow", 0);
		actualDeductible = getValue(dp, group + "req", "Deductible", originaldata, "Deductible", "Discount Amount", 0);
		if (claimType.equals("Med")) {
			// For Medical Claim
			actualCoinsurance = getValue(dp, group + "req", "Coinsurance", originaldata, "Coinsurance", "Withhold", 1);
			actualCopay = getValue(dp, group + "req", "Copay", originaldata, "Copay", "COB", 1);
			actualAllowed = getValue(dp, group + "req", "Allowed", originaldata, "AdjustmentAllowed", "Coinsurance", 0);
			getValue(dp, group + "req", "Disallow", originaldata, "Disallow", "Patient", 1);
		}
		// For Hospital Claim
		else if (claimType.equals("Hosp")) {
			getValue(dp, group + "req", "Disallow", originaldata, "Disallow", "Withhold Amount", 0);
			actualCoinsurance = getValue(dp, group + "req", "Coinsurance", originaldata, "Coinsurance",
					"COB Adjustment", 0);
			actualCopay = getValue(dp, group + "req", "Copay", originaldata, "Copay", "Supplemental Discount", 0);
			actualAllowed = "$" + getValue(dp, group + "req", "Allowed", originaldata, "Allowed", "Coinsurance", -1);
		}
		// getValue(dp, group, "Discount Amount", originaldata, "Discount Amount",
		// "Supplemental Discount");

		Report.logDPValuesByGroup(dp, group + "req");
		Report.log("Captured Line Item: " + line, Status.Pass);

		// Validate the Benefit amounts
		claimlineValidate(dp, group, "expectedAllowed", actualAllowed);
		claimlineValidate(dp, group, "expectedCopay", actualCopay);
		claimlineValidate(dp, group, "expectedDeductible", actualDeductible);
		claimlineValidate(dp, group, "expectedCoinsurance", actualCoinsurance);
		Report.closeBusinessStep();
	}

	public void gotoLine(int line) {
		if (line > 1) {
			for (int i = 1; i < line; i++) {
				element("lnkLineItems").pressKey(KeyEvent.VK_DOWN);
			}
		}
	}
	public void gotofirstLine(int line) {
		if (line > 1) {
			for (int i = 1; i < line; i++) {
				element("lnkLineItems").pressKey(KeyEvent.VK_UP);
			}
		}
	}

	public String getValue(DataProvider dp, String group, String name, String originaldata, String firstString,
			String secondString, int position) {
		String temp = StringUtils.substringBetween(originaldata, firstString, secondString);
		if (position == -1) {
			temp = StringUtils.substringAfterLast(temp, "$");
		} else if (position == 1) {
			temp = StringUtils.substringBeforeLast(temp, "$");
		}
		dp.set(group, name, temp);
		return temp;
	}

	public void navigateToLineItems() {
		Report.log("Navigate to lineitem", Status.BUSINESSSTEP);
		element("lnkLineItems").click();
		element("lnkLineItems").doubleClick();
		Report.closeBusinessStep();
	}

	public void navigateToHospGrid() {
		element("lnkLineItems").click();
		element("lnkLineItems").doubleClick();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
	}

	public void navigateToMedGrid() {
		element("lnkLineItems").click();
		element("lnkLineItems").doubleClick();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
	}

	public String pendClaim(DataProvider dp, String group, String claimType) {
		Report.log("Manually Pend Claims", Status.BUSINESSSTEP);
		element("lblStatusBar").pressKey(KeyEvent.VK_F5);
		element("txtReviewDate").sendKeys(group, "reviewdate");
		element("btnOk").click();
		if (claimType.equals("Hosp")) {
			for (int i = 0; i <= 80; i++) {
				element("lstReviewReason").pressKey(KeyEvent.VK_DOWN);
			}
		} else if (claimType.equals("Med")) {
			for (int i = 0; i <= 112; i++) {
				element("lstReviewReason").pressKey(KeyEvent.VK_DOWN);
			}
		}
		element("btnOk").click();
		String claimID = "";
		claimID = readStatusBar();
		Report.closeBusinessStep();
		return claimID;
	}

	public boolean openAlreadyOpenClaim() throws InterruptedException {
		boolean wndexist = false;
		Report.log("Check - Claim Already Open", Status.BUSINESSSTEP);
		if (element("wndAlreadyOpen").isDisplayed()) {
			wndexist = true;
			Report.log("Claim Already open in another session", Status.Fail);
			element("wndAlreadyOpen").click();
			element("btnCancel").click();
			element("btnOk").click();
		}
		Report.closeBusinessStep();
		return wndexist;
	}

	public void getErrorWndMsg() throws InterruptedException {
		boolean bWndExist = false;
		if (element("wndWarningMsg").isDisplayed()) {
			element("wndWarningMsg").click();
			element("btnClose").click();
			bWndExist = true;
		}
		element("wndErrorMsg").click();
		StringBuilder eMsg = new StringBuilder("Error Message Obtained: \n");
		String temp = "";
		String processid = element("wndErrorMsg").getAttribute("ProcessId");
		for (WebElement ele : driver.findElements(By.xpath("//*[@ControlType='ControlType.ListItem']"))) {
			if ((ele.getAttribute("ProcessId").equals(processid))) {
				temp = " " + ele.getAttribute("Name").trim() + "\n";
				eMsg.append(temp);
				// System.out.println(ele.getAttribute("Name"));
			}
		}
		errMsg = eMsg.toString();
		Report.log("Error Message Obtained: ", errMsg);
		element("btnClose").click();
		if (bWndExist) {
			element("lblStatusBar").pressKey(KeyEvent.VK_F3);
			element("wndErrorMsg").click();
			element("btnClose").click();
		}
	}

	public void getWarningWndMsg() throws InterruptedException {
		if (element("wndWarningMsg").isDisplayed()) {
			element("wndWarningMsg").click();
			StringBuilder wMsg = new StringBuilder("Warning Message Obtained: \n");
			String temp = "";
			String processid = element("wndWarningMsg").getAttribute("ProcessId");
			for (WebElement ele : driver.findElements(By.xpath("//*[@ControlType='ControlType.ListItem']"))) {
				if (ele.getAttribute("ProcessId").equals(processid)) {
					temp = " " + ele.getAttribute("Name").trim() + "\n";
					wMsg.append(temp);
					// System.out.println(ele.getAttribute("Name"));
				}
			}
			Report.log("Warning Message Obtained: ", wMsg.toString());
			element("btnClose").click();
		}
	}

	private void claimlineValidate(DataProvider dp, String group, String element, String actualValue) {
		String expected = dp.get(group, element);
		// System.out.println("Group " + group + " and Element" + element + " and
		// ExpecedVal = " + expected);
		System.out.println("Expected " + expected + " . Actual " + actualValue);
		switch (element) {
		case "expectedAllowed":
			Assert.assertEquals(ValidationType.Verify, "Claim Allowed amount - ", expected, actualValue);
			break;
		case "expectedCopay":
			Assert.assertEquals(ValidationType.Verify, "Claim Copay amount - ", expected, actualValue);
			break;
		case "expectedDeductible":
			Assert.assertEquals(ValidationType.Verify, "Claim Deductible amount - ", expected, actualValue);
			break;
		case "expectedCoinsurance":
			Assert.assertEquals(ValidationType.Verify, "Claim Coinsurance amount - ", expected, actualValue);
			break;
		default:
			Report.log("Expected claim line element not found for validation.", Status.WARN);
			break;
		}
	}

	public boolean readLineItemNotes(DataProvider dp, String group, String cType, int lines) {
		boolean editFlag = false;
		Report.log("Check - Claim Clinical Notes", Status.BUSINESSSTEP);
		element("lnkLineItem").click();
		for (int i = 1; i <= lines; i++) {
			if (cType.equals("M")) {
				navigateToMedGrid();
			} else if (cType.equals("H")) {
				navigateToHospGrid();
			}
			gotofirstLine(lines);
			gotoLine(i);
			element("lnkLineItem").click();
			element("boxLineItemNotes").click();
			String claimNotes = element("boxLineItemNotes").getAttribute("Name");
			System.out.println(claimNotes);
			String claimEditNote = "";
			try {
				List<String> claimEditNotelst = PatternHelper.parseCurlyBraces(claimNotes);
				List<String> claimEditNotelt = PatternHelper.parseSquare(claimNotes);
				if(!claimEditNotelst.isEmpty() && !claimEditNotelt.isEmpty()) {
				if ((claimEditNotelst.size()) > 1) {
					for (String data : claimEditNotelst) {
						claimEditNote += "_" + data.trim();
					}
					claimEditNote = claimEditNote + "_" + claimEditNotelt.get(0).trim();
				} else {
					claimEditNote = claimEditNotelst.get(0).trim() + "_" + claimEditNotelt.get(0).trim();
				}
				}
				else if(!claimEditNotelst.isEmpty() && claimEditNotelt.isEmpty()) {
					for (String data : claimEditNotelst) {
						claimEditNote += "_" + data.trim();
					}
				}
				System.out.println("EditNote obtained " + claimEditNote);
				Report.log("Line No - "+i+"\nClaim Clinical Note: ", claimEditNote);
			} catch (Exception e) {
				Report.log("Error occured while extracting claim clinical notes - " + e, Status.Fail);
			}
			// String expectedEditNote = dp.get(group, "editNote");
			// if (claimEditNote.equals(expectedEditNote)) {
			// editFlag = true;
			// System.out.println("Matched");
			// Report.log("Expected Claim Clinical Notes Matched: " + claimEditNote,
			// Status.PASS);
			// }
		}
		Report.closeBusinessStep();
		return editFlag;
	}

	public void errorAnalyse(String eType) {
		Report.log("Validate - claim error message", Status.BUSINESSSTEP);
		if (!errMsg.isEmpty()) {
			switch (eType) {
			case "InvalidValues":
				if (errMsg.contains("No Rate Record Match found")) {
					Report.log("Claim error message - [No Rate Record Match found] is matched.", Status.PASS);
				} else {
					Report.log("Claim error message - [" + errMsg + "] is not matched.", Status.Fail);
				}
				break;
			case "InvalidCodes":
				if (errMsg.contains("No terms qualified")) {
					Report.log("Claim error message - [No terms qualified] is matched.", Status.PASS);
				} else {
					Report.log("Claim error message - [" + errMsg + "] is not matched.", Status.Fail);
				}
				break;
			default:
				Report.log("Expected claim error type not found for validation.", Status.WARN);
				break;
			}
		} else {
			Report.log("Claim error message is null or empty.", Status.Fail);
		}
		Report.closeBusinessStep();
	}

	private void navigatetoPriceCalculationtab() {
		element("tabPriceCalculation").click();
	}

	public void validatePriceCalculation(DataProvider dp, String cType, int lines) {
		Report.log("Validate - claim price calculation", Status.BUSINESSSTEP);
		for (int i = 1; i <= lines; i++) {
			if (cType.equals("M")) {
				navigateToMedGrid();
			} else if (cType.equals("H")) {
				navigateToHospGrid();
			}
			gotofirstLine(lines);
			gotoLine(i);
			navigatetoPriceCalculationtab();
			String data = element("boxPriceCalculation").getAttribute("Name");
			System.out.println("Price Calculation : " + data);
			String AgreementID = StringUtils.substringBetween(data, "Agreement ID", "Source");
			String finalPriceAllowable = StringUtils.substringBetween(data, "Final Pricing Allowable",
					"Penalty Amount");
			String Rate = StringUtils.substringBetween(data, "Rate", "Allowed");
			String Allowed = StringUtils.substringBetween(data, "Allowed", "Qualifier");
			Report.log("Line no - " + i, Status.KEYWORD);
			Report.log("AgreementID - " + AgreementID, Status.KEYWORD);
			Report.log("Final Price Allowable - " + finalPriceAllowable, Status.KEYWORD);
			Report.log("NetworX Pricer Details", Status.KEYWORD);
			Report.log("Rate - " + Rate, Status.KEYWORD);
			Report.log("Allowed - " + Allowed, Status.KEYWORD);
			// Assert.assertEquals(ValidationType.Verify, "Claim Agreement ID: ",
			// dp.get(group, "AgreementID"), AgreementID);
		}
		Report.closeBusinessStep();
	}

	public int checkGridValue(DataProvider dp, String LineCount)
			throws AWTException, UnsupportedFlavorException, IOException, InterruptedException {
		String chkColValue = dp.get("Grid", "Proc");
		int lineno = 0;
		System.out.println(LineCount);
		int lines = Integer.parseInt(LineCount);
		for (int i = 1; i <= lines; i++) {
			gotoLine(i);
			if (!chkColValue.isEmpty()) {
				if (i == 1) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
				} else {
					element("txtGridBox").pressKey(KeyEvent.VK_DOWN);
					Thread.sleep(1000);
				}
				copy();
				String actualProc = paste();
				// System.out.println("Actual Proc code"+actualProc);
				if (actualProc.equals(chkColValue)) {
					lineno = i;
				}
			}
		}
		return lineno;
	}

	public void textClear() throws AWTException {
		for (int x = 1; x <= 10; x++) {
			clickRightArrow();
		}
		for (int x = 1; x <= 10; x++) {
			clickBackSpace();
		}
	}

	public void clickRightArrow() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_RIGHT);
		r.keyRelease(KeyEvent.VK_RIGHT);
		r.keyRelease(KeyEvent.VK_CONTROL);

	}

	public void clickBackSpace() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_BACK_SPACE);
		r.keyRelease(KeyEvent.VK_BACK_SPACE);
		r.keyRelease(KeyEvent.VK_CONTROL);

	}

	public void selectText() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_HOME);
		r.keyPress(KeyEvent.VK_SHIFT + KeyEvent.VK_END);
		// r.keyPress(KeyEvent.VK_END);
		r.keyRelease(KeyEvent.VK_END);
		r.keyRelease(KeyEvent.VK_SHIFT);
		r.keyRelease(KeyEvent.VK_HOME);
		r.keyRelease(KeyEvent.VK_CONTROL);
	}

	public void copy() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_C);
		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyRelease(KeyEvent.VK_C);
	}

	public String paste() throws UnsupportedFlavorException, IOException {
		String text = "";
		Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
		DataFlavor flavor = DataFlavor.stringFlavor;
		if (cb.isDataFlavorAvailable(flavor)) {
			text = (String) cb.getData(flavor);
			System.out.println(text);
		}
		return text;
	}

	public void validateLineItem(DataProvider dp, String group, String claimType, int lines) {
		Report.log("Check - LineItem", Status.BUSINESSSTEP);
		for (int i = 1; i <= lines; i++) {
			if (claimType.equals("M")) {
				navigateToMedGrid();
			} else if (claimType.equals("H")) {
				navigateToHospGrid();
			}
			Report.log("LineItem - " + i, Status.KEYWORD);
			gotofirstLine(lines);
			gotoLine(i);
			element("lnkLineItem").click();
			String originaldata = element("lblLineDetail").getText();
			System.out.println(originaldata);
			getValue(dp, group, "Considered Charge", originaldata, "Considered Charge", "Deductible", 0);
			getValue(dp, group, "Units", originaldata, "Units", "Copay", 0);
			getValue(dp, group, "Benefit", originaldata, "Benefit", "Disallow", 0);
			getValue(dp, group, "Deductible", originaldata, "Deductible", "Discount Amount", 0);
			if (claimType.equals("M")) {
				// For Medical Claim
				getValue(dp, group, "Coinsurance", originaldata, "Coinsurance", "Withhold", 1);
				getValue(dp, group, "Copay", originaldata, "Copay", "COB", 1);
				getValue(dp, group, "Allowed", originaldata, "AdjustmentAllowed", "Coinsurance", 0);
				getValue(dp, group, "Disallow", originaldata, "Disallow", "Patient", 1);
				getValue(dp, group, "Type Of Service", originaldata, "Type of Service", "Network Indicator", 0);
				getValue(dp, group, "Network Indicator", originaldata, "Network Indicator", "Place of Service", 0);
				getValue(dp, group, "Place of Service", originaldata, "Place of Service", "Line of Business", 0);
			}
			// For Hospital Claim
			else if (claimType.equals("H")) {
				getValue(dp, group, "Disallow", originaldata, "Disallow", "Withhold Amount", 0);
				getValue(dp, group, "Coinsurance", originaldata, "Coinsurance", "COB Adjustment", 0);
				getValue(dp, group, "Copay", originaldata, "Copay", "Supplemental Discount", 0);
				getValue(dp, group, "Allowed", originaldata, "Allowed", "Coinsurance", -1);
				getValue(dp, group, "Type Of Service", originaldata, "Type of Service", "Primary", 0);
				getValue(dp, group, "Network Indicator", originaldata, "Network Indicator", "Type of Service", 0);
			}
			getValue(dp, group, "Referral", originaldata, "Referral", "Referral ID", 0);
			getValue(dp, group, "Preauth", originaldata, "Preauth", "Preauth ID", 0);
			// getValue(dp, group, "Discount Amount", originaldata, "Discount Amount",
			// "Supplemental Discount");
			Report.logDPValuesByGroup(dp, group);
			Report.log("Captured Line Item: " + i, Status.Pass);
		}
		Report.closeBusinessStep();
	}

	public boolean CheckClaimTotal(DataProvider dp, String group) {
		Report.log("Validate Claim total: ", Status.BUSINESSSTEP);
		boolean flag = false;
		gotoLine(1);
		element("lnkClaimTotals").click();
		String originaldata = element("lnkClaimTotals").getText();
		// System.out.println(originaldata);
		String actualBenefit = getValue(dp, group, "Adjustment", originaldata, "Adjustment$", "$", 0);
		// System.out.println("actualBenefit is:" + actualBenefit);
		if (!(actualBenefit.isEmpty())) {
			float value = Float.parseFloat(actualBenefit);
			// System.out.println("value is " + value);
			if (value > 0.00) {
				Report.log("Verified Claim Totals - Benefit is greater than 0", Status.PASS);
				flag = true;
			}
			else {
				Report.log("Verified Claim Totals - Benefit is greater than 0", Status.Fail);
			}
		}
		Report.log("Benefit Amount -  $" + actualBenefit, Status.KEYWORD);
		Report.closeBusinessStep();
		return flag;
	}

	public void bypassDuplicateEditBox() {
		Report.log("Applied - BypassDuplicateEditBox", Status.BUSINESSSTEP);
		element("tabAction").click();
		element("tabOverride").click();
		element("tabClaim").click();
		element("chkBypassDuplicateEdit").enterValueinDropdown("098");
		element("btnOk").click();
		Report.closeBusinessStep();
	}

	public void claimAdjustReasonDialogueBox() {
		Report.log("Applied - claimAdjustReason", Status.BUSINESSSTEP);
		element("tabAction").click();
		element("tabClaimAdjustReason").click();
		element("boxClaimAdjustReason").click();
		element("chkClaimAdjust").enterValueinDropdown("100");
		element("btnOk").click();
		Report.closeBusinessStep();
	}

	public void navigateToNotes() {
		element("subtabNotes").click();
		element("subtabNotes").doubleClick();
	}

	public void addNotes(DataProvider dp, String group) {
		Report.log("Add Notes", Status.BUSINESSSTEP);
		navigateToNotes();
		element("tabEdit").click();
		element("tabAdd").click();
		element("txtAttachmentDescription").sendKeys(dp.get(group, "Description"));
		element("txtClaimNote").sendKeys(dp.get(group, "Note"));
		element("btnOk").click();
		Report.closeBusinessStep();
	}

	public void eobButton(int lineno) {
		Report.log("Applied - EOB", Status.BUSINESSSTEP);
		if (element("wndWarningMsg").isDisplayed()) {
			element("btnClose").click();
		}
		element("btnEOB").click();
		element("wndEOBbox").click();
		for (int j = 1; j <= 3; j++) {
			element("wndEOBbox").pressKey(KeyEvent.VK_DOWN);
		}
		element("wndEOBbox").pressKey(KeyEvent.VK_ENTER);
		for (int i = 1; i <= lineno; i++) {
			element("cmbLineNo").click();
			if(i!=1) {
			element("cmbLineNo").pressKey(KeyEvent.VK_DOWN);
			}
			element("cmbLineNo").pressTab();
			for (int j = 1; j <= 3; j++) {
				element("wndEOBLineItemPane").pressKey(KeyEvent.VK_DOWN);
			}
			element("wndEOBLineItemPane").pressKey(KeyEvent.VK_ENTER);
		}
		element("btnOk").click();
		Report.closeBusinessStep();
	}
}
