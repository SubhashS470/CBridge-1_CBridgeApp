package claims.common;

import org.openqa.selenium.By;
import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

public class Overrides_Claim extends WiniumPageObject {

	protected Overrides_Claim(WrappedWiniumDriver pDriver) {
		super(pDriver);
		// TODO Auto-generated constructor stub
		element("btnClaim", By.id("215"));
		element("btnOk", By.name("OK"));
		element("btnCancel", By.name("Cancel"));
		element("chkBypassPromptPaymentDiscount", By.name("Bypass Prompt Payment Discount"));
		element("cmbBypassPromptPaymentDiscount", By.xpath("//*[@AutomationId='263032']/*[@AutomationId='1']"));
		element("chkSuppressEOB", By.name("Suppress EOB"));
		element("cmbSuppressEOB", By.xpath("//*[@AutomationId='125']/*[@AutomationId='1']"));
		element("chkEligibilitybyEarliestDate", By.name("Eligibility by Earliest Date "));
		element("cmbEligibilitybyEarliestDate", By.xpath("//*[@AutomationId='129']/*[@AutomationId='1']"));
		element("chkAgreementbyEarliestDate", By.name("Agreement by Earliest Date"));
		element("cmbAgreementbyEarliestDate", By.xpath("//*[@AutomationId='142']/*[@AutomationId='1']"));
		element("chkBypassOverpaymentRecovery", By.name("Bypass Overpayment Recovery"));
		element("cmbBypassOverpaymentRecovery", By.xpath("//*[@AutomationId='130']/*[@AutomationId='1']"));
		element("chkStatisticalClaimAdjustment", By.name("Statistical Claim Adjustment"));
		element("cmbStatisticalClaimAdjustment", By.xpath("//*[@AutomationId='131']/*[@AutomationId='1']"));
		element("chkSuppressClaimcheck", By.name(" Suppress Claim check"));
		element("cmbSuppressClaimcheck", By.xpath("//*[@AutomationId='136']/*[@AutomationId='1']"));
		element("chkBypassReferralEdit", By.name("Bypass Referral Edit"));
		element("cmbBypassReferralEdit", By.xpath("//*[@AutomationId='138']/*[@AutomationId='1']"));
		element("chkBypassPreauthEdit", By.name(" Bypass Preauth Edit"));
		element("cmbBypassPreauthEdit", By.xpath("//*[@AutomationId='137']/*[@AutomationId='1']"));
		element("chkApplyProviderPaymentDrag", By.name("Apply Provider Payment Drag"));
		element("cmbApplyProviderPaymentDrag", By.xpath("//*[@AutomationId='117']/*[@AutomationId='1']"));
		element("chkBypassClaimAcceptMonths", By.name("Bypass Claim Accept Months"));
		element("cmbBypassClaimAcceptMonths", By.xpath("//*[@AutomationId='143']/*[@AutomationId='1']"));
		element("chkBypassClaimPaymentHold", By.name("Bypass Claim Payment Hold"));
		element("cmbBypassClaimPaymentHold", By.xpath("//*[@AutomationId='144']/*[@AutomationId='1']"));
		element("chkBypassPCAPend", By.name("Bypass PCA Pend"));
		element("cmbBypassPCAPend", By.xpath("//*[@AutomationId='145']/*[@AutomationId='1']"));
		element("chkBypassDuplicateEdit", By.name("Bypass Duplicate Edit"));
		element("cmbBypassDuplicateEdit", By.xpath("//*[@AutomationId='149']/*[@AutomationId='1']"));
		element("chkBypassHRAProcessing", By.name("Bypass HRA Processing"));
		element("cmbBypassPCAPend", By.xpath("//*[@AutomationId='152']/*[@AutomationId='1']"));
		element("chkBypassFSAProcessing", By.name("Bypass FSA Processing"));
		element("cmbBypassFSAProcessing", By.xpath("//*[@AutomationId='153']/*[@AutomationId='1']"));
		element("chkBypassFSAAdjustment", By.name(" Bypass FSA Adjustment"));
		element("cmbBypassFSAAdjustment", By.xpath("//*[@AutomationId='338']/*[@AutomationId='1']"));
		element("chkBypassInterestCalculation", By.name("Bypass Interest Calculation"));
		element("cmbBypassInterestCalculation", By.xpath("//*[@AutomationId='159']/*[@AutomationId='1']"));
		element("chkBypassProviderTerminationDate", By.name("Bypass Provider Termination Date"));
		element("cmbBypassProviderTerminationDate", By.xpath("//*[@AutomationId='364']/*[@AutomationId='1']"));
		element("chkDenyAllClaimLines", By.name("Deny All Claim Lines"));
		element("cmbDenyAllClaimLines", By.xpath("//*[@AutomationId='155']/*[@AutomationId='1']"));
		element("txtPaymentDate", By.id("102"));
		element("cmbPaymentDate", By.xpath("//*[@AutomationId='103']/*[@AutomationId='1']"));
		element("cmbRecoupInterest", By.xpath("//*[@AutomationId='146']/*[@AutomationId='1']"));
		element("cmbRecoupInterestExplanation", By.xpath("//*[@AutomationId='147']/*[@AutomationId='1']"));
		element("txtInterestContestedDays", By.id("161"));
		element("cmbInterestContestedDays", By.xpath("//*[@AutomationId='162']/*[@AutomationId='1']"));
		element("txtInterestCleanDate", By.id("107"));
		element("cmbInterestCleanDate", By.xpath("//*[@AutomationId='109']/*[@AutomationId='1']"));
		element("txtBenefitCalculationDate", By.id("102"));
		element("cmbBenefitCalculationDate", By.xpath("//*[@AutomationId='121']/*[@AutomationId='1']"));
		element("cmbPaymentLevel", By.xpath("//*[@AutomationId='339']/*[@AutomationId='1']"));
		element("cmbPaymentLevelExplanation", By.xpath("//*[@AutomationId='340']/*[@AutomationId='1']"));		
		element("txtSubscriberPayment", By.id("140"));
		element("cmbSubscriberPayment", By.xpath("//*[@AutomationId='141']/*[@AutomationId='1']"));
	}

	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void navigateToClaimOverrides() {
		element("btnClaim").click();
	}
	
	public void overideBypassPromptPaymentDiscount() throws InterruptedException {
		element("chkBypassPromptPaymentDiscount").enterValueinDropdown("012");
	}

	public void overideSuppressEOB() throws InterruptedException {
		element("chkSuppressEOB").enterValueinDropdown("024");
	}

	public void overideEligibilitybyEarliestDate() throws InterruptedException {
		element("chkEligibilitybyEarliestDate").enterValueinDropdown("023");
	}

	public void overideAgreementbyEarliestDate() throws InterruptedException {
		element("chkAgreementbyEarliestDate").enterValueinDropdown("047");
	}

	public void overideBypassOverpaymentRecovery() throws InterruptedException {
		element("chkBypassOverpaymentRecovery").enterValueinDropdown("032");
	}

	public void overideStatisticalClaimAdjustment() throws InterruptedException {
		element("chkStatisticalClaimAdjustment").enterValueinDropdown("031");
	}

	public void overideSuppressClaimcheck() throws InterruptedException {
		element("chkSuppressClaimcheck").enterValueinDropdown("038");
	}

	public void overidePaymentdate(DataProvider dp, String group) {
		element("txtPaymentdate").sendKeys(dp.get(group, "Paymentdate"));
		element("txtPaymentdate").pressTab();
		element("cmbPaymentdate").type(dp.get(group, "Paymentdatecmb"));
		element("cmbPaymentdate").pressTab();
	}

	public void overideBypassReferralEdit() throws InterruptedException {
		element("chkBypassReferralEdit").enterValueinDropdown("001");
	}
	
	public void overideBypassPreauthEdit() throws InterruptedException {
		element("chkBypassPreauthEdit").enterValueinDropdown("034");
	}
	public void overideSubscriberPayment(DataProvider dp, String group) {
		element("txtSubscriberPayment").sendKeys(dp.get(group, "SubscriberPayment"));
		element("txtSubscriberPayment").pressTab();
		element("cmbSubscriberPayment").type(dp.get(group, "SubscriberPaymentcmb"));
		element("cmbSubscriberPayment").pressTab();
	}
	public void overideApplyProviderPaymentDrag() throws InterruptedException {
		element("chkApplyProviderPaymentDrag").enterValueinDropdown(" ");
	}
	public void overideBypassClaimAcceptMonths() throws InterruptedException {
		element("chkBypassClaimAcceptMonths").enterValueinDropdown("OCA ");
	}
	public void overideBypassClaimPaymentHold() throws InterruptedException {
		element("chkBypassClaimPaymentHold").enterValueinDropdown("HLD ");
	}
	public void overideBypassPCAPend() throws InterruptedException {
		element("chkBypassPCAPend").enterValueinDropdown("9PC");
	}
	public void overideBypassDuplicateEdit() throws InterruptedException {
		element("chkBypassDuplicateEdit").enterValueinDropdown("098");
	}
	public void overideBypassHRAProcessing() throws InterruptedException {
		element("chkBypassHRAProcessing").enterValueinDropdown("059");
	}
	public void overideBypassFSAProcessing() throws InterruptedException {
		element("chkBypassFSAProcessing").enterValueinDropdown("058");
	}
	public void overideBypassFSAAdjustment() throws InterruptedException {
		element("chkBypassFSAAdjustment").enterValueinDropdown("FAO");
	}
	public void overideBypassInterestCalculation() throws InterruptedException {
		element("chkBypassInterestCalculation").enterValueinDropdown("387");
	}
	public void overideBypassProviderTerminationDate() throws InterruptedException {
		element("chkBypassProviderTerminationDate").enterValueinDropdown("PT1");
	}
	public void overideDenyAllClaimLines() throws InterruptedException {
		element("chkDenyAllClaimLines").enterValueinDropdown("073");
	}	

	public void overideInterestContestedDate(DataProvider dp, String group) {
		element("txtInterestContestedDays").sendKeys(dp.get(group, "InterestContestedDays"));
		element("txtInterestContestedDays").pressTab();
		element("cmbInterestContestedDays").type(dp.get(group, "InterestContestedDayscmb"));
		element("cmbInterestContestedDays").pressTab();
	}
	public void overideInterestCleanDate(DataProvider dp, String group) {
		element("txtInterestCleanDate").sendKeys(dp.get(group, "InterestCleanDate"));
		element("txtInterestCleanDate").pressTab();
		element("cmbInterestCleanDate").type(dp.get(group, "InterestCleanDateExplanation"));
		element("cmbInterestCleanDate").pressTab();
	}
	public void overideBenefitCalculationDate(DataProvider dp, String group) {
		element("txtBenefitCalculationDate").sendKeys(dp.get(group, "BenefitCalculationDate"));
		element("txtBenefitCalculationDate").pressTab();
		element("cmbBenefitCalculationDate").type(dp.get(group, "BenefitCalculationDatecmb"));
		element("cmbBenefitCalculationDate").pressTab();
	}
	public void overideRecoupInterest(DataProvider dp, String group) {
		element("cmbRecoupInteres").sendKeys(dp.get(group, "RecoupInteres"));
		element("cmbRecoupInteres").pressTab();
		element("cmbRecoupInterestExplanation").type(dp.get(group, "RecoupInterestExplanation"));
		element("cmbRecoupInterestExplanation").pressTab();
	}
	public void overidePaymentLevel(DataProvider dp, String group) {
		element("cmbcmbPaymentLevel").sendKeys(dp.get(group, "cmbPaymentLevel"));
		element("cmbcmbPaymentLevel").pressTab();
		element("cmbPaymentLevelExplanation").type(dp.get(group, "PaymentLevelExplanation"));
		element("cmbPaymentLevelExplanation").pressTab();
	}
	
	public void clickOk() {
		element("btnOk").click();
	}
	public void applyClaimOverrides(DataProvider dp) throws InterruptedException {
		Report.log("ClaimOverrides", Status.BUSINESSSTEP);
		int lines = Integer.parseInt(dp.get("LineCount", "LineItem"));
		for (int i = 1; i <= lines; i++) {
			navigateToClaimOverrides();
			overideSuppressClaimcheck();
			overideBypassPCAPend();
			clickOk();			
		}
		Report.closeBusinessStep();
	}
	
}
