/**
 * 
 */
package claims.medical;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;

import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;

/**
 * @author aselvan
 *
 */
public class MedicalClaimsLineItems extends WiniumPageObject {
	public MedicalClaimsLineItems(WrappedWiniumDriver pDriver) {
		super(pDriver);

		element("txtPatientPaidGrid", By.name("Patient Paid"));
		element("txtPatientPaid", By.xpath("//*[@Name='Patient Paid'][2]"));
		element("txtGridBox", By.id("2100"));
		element("txtDiagnosisCd", By.id("2110"));
		element("btnYes", By.name("Yes"));
		element("btnNo", By.name("No"));
		element("btnOk", By.name("OK"));
		element("lnkLineItems", By.name("Line Items"));
		element("lblStatusBar", By.id("59393"));

		element("btnClose", By.name("Close"));
		element("btnOverrides", By.name("Overrides"));
		element("lnkLineItem", By.xpath(".//*[@Name='Line Item' and @ControlType='ControlType.TabItem']"));

		element("lblLineDetail", By.id("2005"));
		
		element("wndErrorMsg", By.xpath(".//*[@Name='Error Messages']"));
		
		element("wndWarningMsg", By.xpath(".//*[@Name='Warning Messages']"));
	}

	private List<String> gridboxColList = Arrays.asList("dt_FrmDt", "dt_ToDt", "POS", "Proc", "txtDiagnosisCd",
			"charges", "units");

	/*
	 * (non-Javadoc)
	 * 
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.
	 * ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void fillTheGrid(DataProvider dp, String group) {
			element("txtGridBox").type(dp.get(group, "dt_FrmDt"));
			element("txtGridBox").pressTab();		
			element("txtGridBox").type(dp.get(group, "dt_ToDt"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "POS"));
			element("txtGridBox").pressTab();
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "Proc"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "txtDiagnosisCd"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "charges"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "units"));
	}

	public void adjustGridValue(DataProvider dp, String group) throws AWTException {
		String adjColValue = "";
		for (String cValue : gridboxColList) {
			if (cValue.equals("dt_FrmDt")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					for (int x = 1; x <= 10; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 10; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("dt_ToDt")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 10; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 10; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("POS")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 5; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 5; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("Proc")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 7; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 7; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("txtDiagnosisCd")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 7; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 7; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("charges")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 15; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 15; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("units")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
//					element("txtGridBox").clear();
					for (int x = 1; x <= 5; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 5; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			}
		}
	}

	public void navigateToOverrides() {
		element("btnOverrides").click();
	}

	public void enterTotalCharges(DataProvider dp, String group) throws AWTException {
			element("txtPatientPaid").click();
			element("txtPatientPaid").pressTab();
			element("txtPatientPaid").pressShiftTab();
			for (int x = 1; x <= 20; x++) {
				clickRightArrow();
			}
			for (int x = 1; x <= 20; x++) {
				clickBackSpace();
			}
			element("txtPatientPaid").type(dp.get(group, "totalcharges"));
			element("txtPatientPaid").pressTab();
	}

	public void addNewLine() {
		element("txtGridBox").pressEnter();
	}
	
	
	/*public void FillGridLoop(DataProvider dp, String group, String cType) {
		int lineItemCount = Integer.parseInt(dp.get(group, "Count"));
		for(int i=1; i<=lineItemCount; i++) {
			if(cType.equals("FillFresh")) {
				fillTheGrid(dp, "Grid"+i);
				if(!(i==lineItemCount))
				addNewLine();
			}
			else if (cType.equals("FillAdjust")) {
				adjustGridValue(dp, "Grid"+i);
			}
		}
	}*/
	public void clickRightArrow() throws AWTException {
    	Robot r = new Robot();
    	r.keyPress(KeyEvent.VK_CONTROL);
    	r.keyPress(KeyEvent.VK_RIGHT);
        r.keyRelease(KeyEvent.VK_RIGHT);
        r.keyRelease(KeyEvent.VK_CONTROL);
        	
    
    }
	public void clickBackSpace() throws AWTException {
    	Robot r = new Robot();
    	r.keyPress(KeyEvent.VK_CONTROL);
    	r.keyPress(KeyEvent.VK_BACK_SPACE);
        r.keyRelease(KeyEvent.VK_BACK_SPACE);
        r.keyRelease(KeyEvent.VK_CONTROL);
        	
    
    }
}
