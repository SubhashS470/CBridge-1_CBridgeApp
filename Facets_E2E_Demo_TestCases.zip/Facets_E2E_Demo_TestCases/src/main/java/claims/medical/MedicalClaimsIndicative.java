/**
 * 
 */
package claims.medical;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;

import com.cts.caffe360.cbridge.client.connect.impl.CBeridgeConnectImpl;

import common.GetKeyValueMap;
import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;
import cts.qea.automation.utils.DbHelper;

/**
 * @author aselvan
 *
 */
public class MedicalClaimsIndicative extends WiniumPageObject {

	public MedicalClaimsIndicative(WrappedWiniumDriver pDriver) {
		super(pDriver);
		
		element("txtMember", By.xpath("//*[@Name='Member'][2]"));
		element("txtProviderID", By.xpath("//*[@Name='Provider ID'][2]"));
		element("txtDiagnosisCd", By.id("2110"));
		element("txtProTaxCd", By.xpath("//*[@AutomationId='2149']"));
		element("txtPatientAcctNo", By.xpath("//*[@AutomationId='2114']"));
		element("btnOk", By.name("OK"));
		element("wndErrorMsg", By.xpath(".//*[@Name='Error Messages']"));
		element("btnClose", By.name("Close"));
	}
	
	/* (non-Javadoc)
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}
	
	public String getsubscriberId(DataProvider dp, String group) throws Exception {
		CBeridgeConnectImpl app = new CBeridgeConnectImpl();
		GetKeyValueMap ke=new GetKeyValueMap();
		String hicn=dp.get(group, "memberid");
		String memque = "select * from CMC_SBSB_SUBSC where SBSB_CK in (select SBSB_CK from CMC_MEME_MEMBER where MEME_HICN='hicndata')";
		memque = memque.replaceAll("hicndata", hicn);
		String in = app.cbridgeGetMethod("",hicn);
		JSONArray jsonArr = new JSONArray(in);
		JSONObject jsonObj = jsonArr.getJSONObject(0);
		Map<String, Object> ma=ke.toMap(jsonObj);
		@SuppressWarnings("unchecked")
		Map<String,String>keyvalue=(Map<String, String>) ma.get("key_value");
		System.out.println(keyvalue.get("HICN"));
		DbHelper db = new DbHelper();
		db.connectDatabase();
		ResultSet rssample = rset(memque, db);
		rssample.next();
		return rssample.getString("SBSB_ID");
	}

	public static ResultSet rset(String memque, DbHelper db) throws SQLException {
		ResultSet rssample = null;
		if (memque != null) {
			PreparedStatement s = db.getConnection().prepareStatement(memque, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rssample = s.executeQuery();
		} else {
			Report.log("Query is Null", Status.fail);
		}
		return rssample;
	}
	
	public void enterSubscriberDetails(DataProvider dp, String group) throws InterruptedException {
		element("txtMember").sendKeys_clone(dp.get(group, "txtMember"));
		element("txtMember").pressTab();
		if (element("btnOk").isDisplayed())
			element("btnOk").click();
	}
	
	public void enterProviderDetails(DataProvider dp, String group) {
		element("txtProviderID").sendKeys_clone(dp.get(group, "txtProviderID"));
		element("txtProviderID").pressTab();
		
	}
	
	public void enterDiagnosisCode(DataProvider dp, String group) {
		element("txtDiagnosisCd").sendKeys_clone(dp.get(group, "txtDiagnosisCd"));
		element("txtDiagnosisCd").pressTab();
	}
	
	public void enterProviderTaxCode(DataProvider dp, String group) {
		element("txtProTaxCd").sendKeys_clone(dp.get(group, "ptcode"));
	}
	
	public void enterPatientAcctNo(DataProvider dp, String group) {
		element("txtPatientAcctNo").sendKeys_clone(dp.get(group, "patacctno"));
	}
}
