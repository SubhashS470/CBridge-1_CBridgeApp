/**
 * 
 */
package claims.hospital;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;

import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
/**
 * @author aselvan
 *
 */
public class HospitalClaimsIndicative extends WiniumPageObject {
	public HospitalClaimsIndicative(WrappedWiniumDriver pDriver) {
		super(pDriver);
		
		element("txtMember", By.xpath("//*[@Name='Member'][2]"));
		element("txtProviderID", By.xpath("//*[@Name='Provider ID'][2]"));
		element("txtReceivedDate", By.id("2104"));
		element("cmbTypeClass", By.xpath("//*[@AutomationId='2148']/*[@AutomationId='1']"));
		element("cmbFrequency", By.xpath("//*[@AutomationId='2149']/*[@AutomationId='1']"));
		element("txtStmtCvrFrmDate", By.id("2155"));
		element("txtStmtCvrToDate", By.id("2156"));
		element("AdmissionBox", By.id("2141"));
		element("DischargeBox", By.id("2140"));
		element("txtAdmissionDate", By.id("2101"));
		element("txtDischargeDate", By.id("2103"));
		element("cmbAdmitType", By.xpath("//*[@AutomationId='2106']/*[@AutomationId='1']"));
		element("cmbAdmitSource", By.xpath("//*[@AutomationId='2139']/*[@AutomationId='1']"));
		element("cmbDischargeStatus", By.xpath("//*[@AutomationId='2105']/*[@AutomationId='1']"));
		element("txtDiagnosisCd", By.id("2129"));
		element("txtAdmittingCd", By.id("2130"));
		element("txtProTaxCd", By.id("2164"));
		element("txtPatientAcctNo", By.id("2123"));
		element("txtProcedureCode", By.id("2138"));
		element("txtProcedureCodeDate", By.id("2102"));
		element("btnOk", By.name("OK"));
		element("btnClose", By.name("Close"));
		element("wndErrorMsg", By.xpath(".//*[@Name='Error Messages']"));
		element("wndWarningMsg", By.xpath(".//*[@Name='Warning Messages']"));
	}
	
	/* (non-Javadoc)
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void enterSubscriberDetails(DataProvider dp, String group) throws InterruptedException{
//		element("txtMember").click();
			element("txtMember").sendKeys_clone(dp.get(group, "txtMember"));
			element("txtMember").pressTab();
			if (element("btnOk").isDisplayed())
				element("btnOk").click();
		
	}
	
	public void enterProviderDetails(DataProvider dp, String group) throws AWTException {
		/*for (int x = 1; x <= 15; x++) {
			clickRightArrow();
		}
		for (int x = 1; x <= 15; x++) {
			clickBackSpace();
		}*/
		element("txtProviderID").sendKeys_clone(dp.get(group, "txtProviderID"));
		element("txtProviderID").pressTab();
		
	}
	
	public void enterTypeOfBill(DataProvider dp, String group) {
		
		element("cmbTypeClass").sendKeys_clone(dp.get(group, "TypeClass"));
		element("cmbFrequency").sendKeys_clone(dp.get(group, "Frequency"));
		
	}
	
	public void enterStmtCoverDates(DataProvider dp, String group) {
		
		element("txtStmtCvrFrmDate").sendKeys_clone(dp.get(group, "st_frm_dt"));
		element("txtStmtCvrToDate").sendKeys_clone(dp.get(group, "st_to_dt"));
		
	}
	
	public void enterReceivedDate(DataProvider dp, String group) {
		element("txtReceivedDate").sendKeys_clone(dp.get(group, "recvd_dt"));
	}
	
	public void enterAdmissionDetails(DataProvider dp, String group) {
		element("txtAdmissionDate").sendKeys_clone(dp.get(group, "admit_dt"));
		element("AdmissionBox").pressTab();
		element("AdmissionBox").sendKeys_clone(dp.get(group, "Ahour"));
		element("cmbAdmitType").sendKeys_clone(dp.get(group, "Atype"));
		element("cmbAdmitSource").sendKeys_clone(dp.get(group, "Asource"));	
	}
	
	public void enterDischargeDetails(DataProvider dp, String group) {
		element("cmbDischargeStatus").sendKeys_clone(dp.get(group, "DStatus"));
		element("txtDischargeDate").sendKeys_clone(dp.get(group, "discharge_dt"));
		element("txtDischargeDate").pressTab();
		element("DischargeBox").sendKeys_clone(dp.get(group, "Dhour"));
	}
	
	public void enterDiagnosisCode(DataProvider dp, String group) {
		element("txtDiagnosisCd").sendKeys_clone(dp.get(group, "Pri_Code"));
		
	}
	public void enterAdmittingCode(DataProvider dp, String group) {
		element("txtAdmittingCd").sendKeys_clone(dp.get(group, "AdmitCode"));
	}
	public void enterProviderTaxCode(DataProvider dp, String group) {
		element("txtProTaxCd").sendKeys_clone(dp.get(group, "ptcode"));
	}
	
	public void enterPatientAcctNo(DataProvider dp, String group) {
		element("txtPatientAcctNo").sendKeys_clone(dp.get(group, "patacctno"));
	}
	
	public void enterProcedureCode(DataProvider dp, String group) {
		element("txtProcedureCode").sendKeys_clone(dp.get(group, "proc"));
		element("txtProcedureCodeDate").sendKeys_clone(dp.get(group, "procDate"));
	}
	
	public void navigateToLineItems() {
		element("lnkLineItems").click();
		element("lnkLineItems").doubleClick();
	}
	public void errorClose() {
		if(element("wndErrorMsg").isDisplayed())
			element("btnClose").click();
	}
	public void clickRightArrow() throws AWTException {
    	Robot r = new Robot();
    	r.keyPress(KeyEvent.VK_CONTROL);
    	r.keyPress(KeyEvent.VK_RIGHT);
        r.keyRelease(KeyEvent.VK_RIGHT);
        r.keyRelease(KeyEvent.VK_CONTROL);
    }
	public void clickBackSpace() throws AWTException {
    	Robot r = new Robot();
    	r.keyPress(KeyEvent.VK_CONTROL);
    	r.keyPress(KeyEvent.VK_BACK_SPACE);
        r.keyRelease(KeyEvent.VK_BACK_SPACE);
        r.keyRelease(KeyEvent.VK_CONTROL);
    }
	public void closeWarningWnd() {
		if(element("wndWarningMsg").isDisplayed()) {
			element("btnClose").click();
		}
	}
}
