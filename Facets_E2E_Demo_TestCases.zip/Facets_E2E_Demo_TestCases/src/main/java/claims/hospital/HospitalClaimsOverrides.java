package claims.hospital;

import org.openqa.selenium.By;

import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

public class HospitalClaimsOverrides extends WiniumPageObject{
	public HospitalClaimsOverrides(WrappedWiniumDriver pDriver) {
		super(pDriver);
		element("chkOverideClinicalEditDisallow", By.name("Override Clinical Edit Disallow"));
		element("txtOverideClinicalEditDisallow", By.id("114"));
		element("chkPreAuthNotRequired", By.name("Pre-Auth Not Required  "));
		element("txtPreAuthNotRequired", By.id("190"));
		element("chkBypassDuplicateEdit", By.name("Bypass Duplicate Edit"));
		element("btnClaim", By.name("Claim"));
		element("chkByProviderTermination", By.name("Bypass Provider Termination Date"));
		element("cmbByProviderTermination", By.xpath("//*[@AutomationId='364']/*[@AutomationId='1']"));
		element("btnOk", By.name("OK"));
}
	
	/* (non-Javadoc)
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}
	public void applyOverrides(String LineNo) throws InterruptedException {
		element("chkOverideClinicalEditDisallow").type(LineNo);
		element("chkOverideClinicalEditDisallow").pressTab();
		
		element("chkOverideClinicalEditDisallow").enterValueinDropdown("029");
		element("chkPreAuthNotRequired").enterValueinDropdown("036");
		
		Report.log("Overrides Entered", Status.Pass);
		element("btnOk").click();
	}
	public void BypassDuplicateOverrides(String LineNo) throws InterruptedException {
		element("chkOverideClinicalEditDisallow").type(LineNo);
		element("chkOverideClinicalEditDisallow").pressTab();
		
		element("chkOverideClinicalEditDisallow").enterValueinDropdown("029");
		element("chkPreAuthNotRequired").enterValueinDropdown("036");
		element("chkBypassDuplicateEdit").enterValueinDropdown("020");
		
		Report.log("Overrides Entered", Status.Pass);
		element("btnOk").click();
	}
	public void ByProviderTermination(String LineNo) throws InterruptedException {
		
	}
}
