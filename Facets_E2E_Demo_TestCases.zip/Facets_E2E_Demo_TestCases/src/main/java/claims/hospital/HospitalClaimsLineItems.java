/**
 * 
 */
package claims.hospital;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;

import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author aselvan
 *
 */
public class HospitalClaimsLineItems extends WiniumPageObject {

	public HospitalClaimsLineItems(WrappedWiniumDriver pDriver) {
		super(pDriver);

		element("txtPatientPaidGrid", By.name("Patient Paid"));
		element("txtPatientPaid", By.xpath("//*[@Name='Patient Paid'][2]"));
		element("txtGridBox", By.id("2100"));
		element("txtSubmittedDRG", By.xpath("//*[@AutomationId='2115']"));
		
		element("btnOk", By.name("OK"));
		element("btnYes", By.name("Yes"));
		element("btnNo", By.name("No"));
		element("btnClose", By.name("Close"));
		element("btnOverrides", By.name("Overrides"));
		
		element("lnkLineItems", By.name("Line Items"));
		element("lnkLineItem", By.xpath(".//*[@Name='Line Item' and @ControlType='ControlType.TabItem']"));
		
		element("lblStatusBar", By.id("59393"));
		element("lblLineDetail", By.id("2005"));
		
		element("wndAutoPend", By.xpath(
				".//*[@Name='Processing Control Agent Will Pend this Claim \nfor Reason HOSP - Hospital claims pend hold\nDo you want to continue?']"));
		element("wndErrorMsg", By.xpath(".//*[@Name='Error Messages']"));
		
		element("wndWarningMsg", By.xpath(".//*[@Name='Warning Messages']"));
	}

	private List<String> gridboxColList = Arrays.asList("dt_FrmDt", "dt_ToDt", "rev", "Proc", "units", "charges",
			"txtDiagnosisCd");

	/*
	 * (non-Javadoc)
	 * 
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.
	 * ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void fillTheGrid(DataProvider dp, String group) {
			element("txtGridBox").type(dp.get(group, "dt_FrmDt"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "dt_ToDt"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "rev"));
			element("txtGridBox").pressTab();
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "Proc"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "units"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "charges"));
			element("txtGridBox").pressTab();
			element("txtGridBox").type(dp.get(group, "txtDiagnosisCd"));
	}

	public void adjustGridValue(DataProvider dp, String group) throws AWTException {
		String adjColValue = "";
		for (String cValue : gridboxColList) {
			if (cValue.equals("dt_FrmDt")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					for (int x = 1; x <= 10; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 10; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("dt_ToDt")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 10; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 10; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("rev")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 5; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 5; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("Proc")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 5; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 5; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("units")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 5; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 5; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("charges")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					//element("txtGridBox").clear();
					for (int x = 1; x <= 15; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 15; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			} else if (cValue.equals("txtDiagnosisCd")) {
				adjColValue = dp.get(group, cValue);
				if (!adjColValue.isEmpty()) {
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					element("txtGridBox").pressTab();
					for (int x = 1; x <= 9; x++) {
						clickRightArrow();
					}
					for (int x = 1; x <= 9; x++) {
						clickBackSpace();
					}
					element("txtGridBox").type(adjColValue);
				}
			}
		}
	}

	public void enterTotalCharges(DataProvider dp, String group) throws AWTException {		
			element("txtPatientPaid").click();
			element("txtPatientPaid").pressTab();
			element("txtPatientPaid").pressShiftTab();
			for (int x = 1; x <= 20; x++) {
				clickRightArrow();
			}
			for (int x = 1; x <= 20; x++) {
				clickBackSpace();
			}
			element("txtPatientPaid").type(dp.get(group, "totalcharges"));
			element("txtPatientPaid").pressTab();
	}

	public void navigateToOverrides() {
		element("btnOverrides").click();
	}

	public void navigateToGrid() {
		element("lnkLineItems").doubleClick();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
		element("lnkLineItems").pressTab();
	}

	public void addNewLine() {
		element("txtGridBox").pressEnter();
	}

	public boolean autoPend() {
		boolean wndPend = false;
		if (element("wndAutoPend").isDisplayed()) {
			wndPend = true;
			element("btnYes").click();
			Report.log("Claim Auto Pended when F4 Pressed", Status.Fail);
		}
		return wndPend;
	}
	
	/*public void FillGridLoop(DataProvider dp, String group, String cType) {
		try {
			String count = dp.get(group, "Count");
			System.out.println(count );
			int lineItemCount = Integer.parseInt(count);
			System.out.println(count + "   "+ lineItemCount);
		for(int i=1; i<=lineItemCount; i++) {
			if(cType.equals("FillFresh")) {
				fillTheGrid(dp, "HGrid"+i);
			}
			else if (cType.equals("FillAdjust")) {
				adjustGridValue(dp, "HGrid"+i);
			}
		}
		}
		catch (Exception e) {
			Report.log("Error Occured - "+e, Status.Fail);
		}
	}*/
	public void clickRightArrow() throws AWTException {
    	Robot r = new Robot();
    	r.keyPress(KeyEvent.VK_CONTROL);
    	r.keyPress(KeyEvent.VK_RIGHT);
        r.keyRelease(KeyEvent.VK_RIGHT);
        r.keyRelease(KeyEvent.VK_CONTROL);
        	
    
    }
	public void clickBackSpace() throws AWTException {
    	Robot r = new Robot();
    	r.keyPress(KeyEvent.VK_CONTROL);
    	r.keyPress(KeyEvent.VK_BACK_SPACE);
        r.keyRelease(KeyEvent.VK_BACK_SPACE);
        r.keyRelease(KeyEvent.VK_CONTROL);
        	
    
    }
}
