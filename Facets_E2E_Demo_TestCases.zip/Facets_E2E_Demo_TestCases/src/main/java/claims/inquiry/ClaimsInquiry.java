package claims.inquiry;

import java.awt.event.KeyEvent;

import org.openqa.selenium.By;

import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

public class ClaimsInquiry extends WiniumPageObject {
	public ClaimsInquiry(WrappedWiniumDriver pDriver) {
		super(pDriver);
		element("lblStatusBar", By.id("59393"));
		element("wndTitleBar", By.id("TitleBar"));
		element("cmbInquiryName", By.name("Inquiry Name"));
		element("radio_medQueryType", By.name("Medical"));
		element("radio_denQueryType", By.name("Dental"));
		element("radio_FSAQueryType", By.name("FSA"));
		element("txtSubsriberID", By.id("160"));
		element("cmbMember", By.id("175"));
		element("cmbProvider", By.id("239"));
		element("txtProviderID", By.id("240"));
		element("cmbClaim", By.xpath("//*[@AutomationId='242']/*[@AutomationId='1']"));
		element("txtClaimID", By.id("243"));
		element("cmbUser1", By.id("102"));
		element("cmbUser2", By.id("107"));
		element("cmbStatus", By.id("104"));
		element("txtNextReviewDate", By.id("105"));
		element("txtLastActionDate", By.id("106"));
		element("chkCurrentDate", By.id("245"));
		element("txtSVCFromDate", By.id("247"));
		element("txtSVCToDate", By.id("248"));
		element("cmbStatusReason", By.id("249"));
		element("txtReceivedDate", By.id("251"));
		element("cmbSelection", By.id("2100"));
		element("txtValue", By.id("200"));
		element("cmbOptions", By.id("2100"));
		element("txtChoice", By.id("2101"));
		element("chkDiplayResults", By.id("250"));
		element("cmbGoto", By.id("255"));
		element("btnRun", By.name("Run"));
		element("btnCancel", By.name("Cancel"));
		element("btnSearch", By.name("Search..."));
	}
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}
	
	public void openClaimsInquiryWindow() {
		Report.log("Open Claims Inquiry Window", Status.BUSINESSSTEP);
		element("lblStatusBar").pressKey(KeyEvent.VK_F9);
		element("wndTitleBar").click();
		Report.closeBusinessStep();
	}
	
	public void enterSubscriberID(DataProvider dp, String group) throws InterruptedException {
		element("txtSubsriberID").sendKeys(dp.get(group, "txtSubscriber"));
		element("txtSubsriberID").pressTab();
	}
	
	public void enterMember(DataProvider dp, String group) throws InterruptedException {
		element("cmbMember").type(dp.get(group, "txtMember"));
		element("cmbMember").pressTab();
	}
	
	public void selectProvider(DataProvider dp, String group) throws InterruptedException {
		element("cmbProvider").type(dp.get(group, "Provider"));
		element("cmbProvider").pressTab();
	}
	
	public void enterProviderID(DataProvider dp, String group) throws InterruptedException {
		element("txtProviderID").sendKeys(dp.get(group, "txtProviderID"));
		element("txtProviderID").pressTab();
	}
	
	public void selectClaim() throws InterruptedException {
		element("cmbClaim").click();
		element("cmbClaim").pressKey(KeyEvent.VK_DOWN);
		element("cmbClaim").pressKey(KeyEvent.VK_DOWN);
		element("cmbClaim").pressTab();
	}
	
	public void enterClaim(DataProvider dp, String group) throws InterruptedException {
		element("txtClaimID").sendKeys(dp.get(group, "ClaimID"));
		element("txtClaimID").pressTab();
	}
	
	public void selectStatus(DataProvider dp, String group) throws InterruptedException {
		element("cmbStatus").type(dp.get(group, "claimStatus"));
		element("cmbStatus").pressTab();
	}
	
	public void runInquiry() throws InterruptedException {
		element("btnRun").click();
	}
	
	public void cancelInquiry() throws InterruptedException {
		element("btnCancel").click();
	}
}
