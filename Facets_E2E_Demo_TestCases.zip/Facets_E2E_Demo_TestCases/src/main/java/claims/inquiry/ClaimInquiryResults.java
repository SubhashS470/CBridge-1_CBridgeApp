package claims.inquiry;

import java.awt.event.KeyEvent;

import org.openqa.selenium.By;

import claims.common.CommonActions;
import cts.qea.automation.DataProvider;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

public class ClaimInquiryResults extends WiniumPageObject {
	CommonActions cmnAction;
	public ClaimInquiryResults(WrappedWiniumDriver pDriver) {
		super(pDriver);
		element("boxInquiryResults", By.id("153"));
		element("btnOk", By.name("OK"));
		element("btnCancel", By.name("Cancel"));
		element("btnClose", By.name("Close"));
		//Claim Detail elements
		element("LineItemDetailstab", By.name("Line Item Details"));
		element("LineItemDetails", By.id("2000"));	
		element("MemberProvidertab", By.name("Member/Provider"));
		element("MemberProviderDetails", By.id("2101"));
		cmnAction = new CommonActions(pDriver);
	}
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}
	
	public void selectInquiryRow() throws InterruptedException {
		element("boxInquiryResults").click();
		//Selects first row
		element("boxInquiryResults").pressKey(KeyEvent.VK_DOWN);
	}
	
	private void navigatetoLineItemsTab() throws InterruptedException {
		element("LineItemDetailstab").click();
	}
	
	private void navigatetoMemberProviderTab() throws InterruptedException {
		element("MemberProvidertab").click();
		
	}
	
	private void navigatetoBenefitsSummary() throws InterruptedException {
		element("LineItemDetailstab").pressKey(KeyEvent.VK_F6);
	}

	public void extractLineItemDetails(DataProvider dp, String group) throws InterruptedException {
		Report.log("Extract Claim Line Item details", Status.BUSINESSSTEP);
		String data ="";
		navigatetoLineItemsTab();
		data = element("LineItemDetails").getAttribute("Name");
		System.out.println(data);
		cmnAction.getValue(dp, group, "Considered Charge", data, "Consd Chg", "Deductible", 0);
		cmnAction.getValue(dp, group, "Allowed", data, "Allowed", "Coinsurance", -1);
		cmnAction.getValue(dp, group, "Coinsurance", data, "Coinsurance", "COB", 0);
		cmnAction.getValue(dp, group, "Benefit", data, "Benefit", "Disallow", -1);
		cmnAction.getValue(dp, group, "Disallow", data, "Disallow", "Withhold", 0);
		Report.logDPValuesByGroup(dp, group);
		Report.log("Captured Line Item Details successfully", Status.Pass);
		Report.closeBusinessStep();
	}

	public void extractMemberProviderDetails(DataProvider dp, String group) throws InterruptedException {
		Report.log("Extract Claim Member Provider Details", Status.BUSINESSSTEP);
		String data ="";
		navigatetoMemberProviderTab();
		data = element("MemberProviderDetails").getAttribute("Name");
		System.out.println(data);
		cmnAction.getValue(dp, group, "Subscriber ID", data, "Subscriber ID", "Group ID", 0);
		cmnAction.getValue(dp, group, "Agreement ID", data, "Agreement", "Input Taxonomy Code", 0);
		cmnAction.getValue(dp, group, "Group ID", data, "Group ID", "Subgroup ID", 0);
		Report.logDPValuesByGroup(dp, group);
		Report.log("Captured Member Provider Details successfully", Status.Pass);
		Report.closeBusinessStep();
	}

	public void benefitsSummaryDetails() throws InterruptedException {
		Report.log("Benefits Summary Details", Status.BUSINESSSTEP);
		navigatetoBenefitsSummary();
		element("btnClose").click();
		Report.closeBusinessStep();
	}
	
	public void clickOK() throws InterruptedException {
		element("btnOk").click();
	}
}

