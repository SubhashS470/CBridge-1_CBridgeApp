/**
 * 
 */
package common;

import org.openqa.selenium.By;

import cts.qea.automation.Config;
import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author aselvan
 *
 */
public class Menu extends WiniumPageObject {

	public Menu(WrappedWiniumDriver pDriver) {
		super(pDriver);

		element("wnFacets", By.xpath("//*[@Name='Facets' and @ControlType='ControlType.Window']"));
		element("btnFile", By.name("File"));
		element("btnOpenDatabase", By.name("Open Database"));
		element("lnkLocationBar", By.id("1001"));
		element("lnkFacets", By.name("facets.pzb"));
		element("btnOpen", By.name("Open"));
		element("btnMaximize", By.name("Maximize"));
		element("btnOk", By.name("OK"));
		element("btnNo", By.name("No"));
		element("btnClose", By.name("Close"));
		element("lnkFileName", By.name("File name:"));
		// Error Message window
		element("wndErrorMsg", By.name("Error Messages"));
		// Warning window
		element("wndWarningMsg", By.name("Warning Messages"));		
		//Save changes window
		element("wndSaveChanges", By.id("65535"));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.
	 * ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}

	public void openFacetsConnection() {
		Report.log("Open Facets", Status.BUSINESSSTEP);
		element("wnFacets").switchTo("Facets");
		element("wnFacets", "btnMaximize").click();
		element("btnFile").click();
		element("btnOpenDatabase").click();
		String section = Config.getEnvDetails("config", "appname");
		String filepath = Config.getEnvDetails(section, "FILE_PATH");
		element("lnkFileName").click();
		element("lnkFileName").sendKeys(filepath);
		element("btnOpen").click();
		element("lnkFacets").click();
		element("btnOpen").click();
		element("btnMaximize").click();
		Report.closeBusinessStep();
	}

	public void openMAPDFacetsConnection() {
		element("wnFacets").switchTo("Facets");
		element("btnFile").click();
		element("btnOpenDatabase").click();
		element("lnkFacets").click();
		element("btnOpen").click();
		element("btnMaximize").click();
	}

	public void closeFacets() throws InterruptedException {
		Report.log("Close Facets", Status.BUSINESSSTEP);
		closeErrorWnd();
		closeWarningWnd();
		element("btnClose").click();
		element("btnOk").click();
		Report.closeBusinessStep();
	}

	public void clickOpen() {
		element("btnFile").click();
		element("btnOpen").click();
	}

	public void closeErrorWnd() throws InterruptedException {
		if (element("wndErrorMsg").isDisplayed()) {
			element("wndErrorMsg").click();
			element("btnClose").click();
		}
	}

	public void closeWarningWnd() throws InterruptedException {
		if (element("wndWarningMsg").isDisplayed()) {
			element("wndWarningMsg").click();
			element("btnClose").click();
		}
	}

	public void closeSaveChangesDialog() throws InterruptedException {
		if (element("wndSaveChanges").isDisplayed()) {
			String data = element("wndSaveChanges").getText();
			if (data.contains("Do you want to return\nto save changes?")) {
				element("btnNo").click();
//				if(element("btnNo").isDisplayed()) {
//					element("btnNo").click();
//				}
				Report.log("Claim could not be saved", Status.KEYWORD);
			}
		}
	}

}
