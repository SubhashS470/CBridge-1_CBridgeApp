package common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cts.caffe360.cbridge.client.app.CBridgeApplicationClient;
import com.cts.caffe360.cbridge.client.connect.impl.CBeridgeConnectImpl;
import com.cts.caffe360.cbridge.client.constant.CBeridgeConnectConstant;
import com.cts.caffe360.cbridge.client.exception.CBridgeURLConnectionExcetion;
import com.cts.caffe360.cbridge.client.vo.CBridgeTestDataVO;

@SuppressWarnings("unused")
public class GetKeyValueMap {

//	public static void main(String[] args) throws Exception {
//		// TODO Auto-generated method stub
//		CBeridgeConnectImpl app = new CBeridgeConnectImpl();
//		String in = app.cbridgeGetMethod("","8WF6YE7MG71");
////		CBridgeTestDataVO po=app.getCBridgeTestDataVOFromJsonString(in);
////		 JSONObject jsonObject = getjsonobjectbyKey(in);
//		JSONObject jsonObject = new JSONObject(in);
//		Map<String, Object> ma=toMap(jsonObject);
//		Map<String,String>keyvalue=(Map<String, String>) ma.get("key_value");
//		System.out.println(keyvalue.get("HICN"));
//	}

//	public static JSONObject getjsonobjectbyKey(String in) {
//		JSONArray jsonArr = new JSONArray(in);
//		 for (int i = 0; i < jsonArr.length(); i++)
//	        {
//	            JSONObject jsonObj = jsonArr.getJSONObject(i);
//	            System.out.println(jsonObj);
//	        }
//		
//		return jsonObject;
//	}

	public  Map<String, Object> toMap(JSONObject object) throws JSONException {
		Map<String, Object> map = new HashMap<String, Object>();

		Iterator<String> keysItr = object.keys();
		while (keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);

			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			map.put(key, value);
		}
		return map;
	}

	public  List<Object> toList(JSONArray array) throws JSONException {
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			list.add(value);
		}
		return list;
	}

}
