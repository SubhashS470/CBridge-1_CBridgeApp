/**
 * 
 */
package common;

import org.openqa.selenium.By;

import cts.qea.automation.ValidationType;
import cts.qea.automation.WiniumPageObject;
import cts.qea.automation.WrappedWiniumDriver;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author aselvan
 *
 */
public class Applications extends WiniumPageObject {

	public Applications(WrappedWiniumDriver pDriver) {
		super(pDriver);
		
		element("lnkClaimsProcessing", By.name("Claims Processing             "));
		element("lnkMedicalClaimsProcessing", By.name("Medical Claims Processing     "));
		element("lnkHospitalClaimsProcessing", By.name("Hospital Claims Processing    "));
		element("lnkMedicalClaimElectronicLog", By.name("Medical Claims Electronic Log "));
		element("lnkHospitalClaimElectronicLog", By.name("Hospital Claims Electronic Log"));
		element("lnkClaimInquiry", By.name("Claims Inquiry                "));
		element("lnkNetworX", By.name("NetworX                       "));
		element("lnkMedicalAgreementConfigurator", By.name("Medical Agreement Configurator"));
	}
	
	/* (non-Javadoc)
	 * @see cts.qea.automation.PageObject#validatePageExists(cts.qea.automation.ValidationType)
	 */
	@Override
	public void validatePageExists(ValidationType vType) {
		// TODO Auto-generated method stub

	}
	
	public void navigatetoMedicalClaimsProcessing() throws InterruptedException {
		Report.log("Open Medical Claim Processing", Status.BUSINESSSTEP);
		element("lnkClaimsProcessing").click();
		element("lnkClaimsProcessing").doubleClick();
		element("lnkMedicalClaimsProcessing").click();
		element("lnkMedicalClaimsProcessing").doubleClick();
		Report.closeBusinessStep();
	}
	
	public void navigatetoHospitalClaimsProcessing() throws InterruptedException {
		Report.log("Open Hospital Claim Processing", Status.BUSINESSSTEP);
		element("lnkClaimsProcessing").click();
		element("lnkClaimsProcessing").doubleClick();
		element("lnkHospitalClaimsProcessing").click();
		element("lnkHospitalClaimsProcessing").doubleClick();
	}
	
	public void navigatetoMedicalClaimsElectronicLog() throws InterruptedException {
		Report.log("Open Medical Claim Electronic Log", Status.BUSINESSSTEP);
		element("lnkClaimsProcessing").click();
		element("lnkClaimsProcessing").doubleClick();
		element("lnkMedicalClaimElectronicLog").click();
		element("lnkMedicalClaimElectronicLog").doubleClick();
	}
	
	public void navigatetoHospitalClaimsElectronicLog() throws InterruptedException {
		Report.log("Open Hospital Claim Electronic Log", Status.BUSINESSSTEP);
		element("lnkClaimsProcessing").click();
		element("lnkClaimsProcessing").doubleClick();
		element("lnkHospitalClaimElectronicLog").click();
		element("lnkHospitalClaimElectronicLog").doubleClick();
	}

	public void navigatetoClaimsInquiry() throws InterruptedException {
		Report.log("Open Claims Inquiry", Status.BUSINESSSTEP);
		element("lnkClaimsProcessing").click();
		element("lnkClaimsProcessing").doubleClick();
		element("lnkClaimInquiry").click();
		element("lnkClaimInquiry").doubleClick();
	}
	
	public void navigatetoMedicalAgreementConfig() throws InterruptedException {
		element("lnkNetworX").click();
		element("lnkNetworX").doubleClick();
		element("lnkMedicalAgreementConfigurator").click();
		element("lnkMedicalAgreementConfigurator").doubleClick();
	}
}
