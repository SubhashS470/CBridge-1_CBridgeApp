/**
 * 
 */
package tdm;

import cts.qea.automation.DataFactory;
import cts.qea.automation.DataProvider;
import org.openqa.selenium.WebDriver;

/**
 * @author aselvan
 *
 */
public class GenericSqlFactory extends DataFactory {

	@Override
	public boolean executeTDM(WebDriver driver, DataProvider dp) throws Exception {
		// This is dummy opening
		return false;
	}

}
