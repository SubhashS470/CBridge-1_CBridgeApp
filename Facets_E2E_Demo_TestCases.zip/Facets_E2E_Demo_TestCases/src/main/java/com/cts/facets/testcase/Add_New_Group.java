package com.cts.facets.testcase;

import org.junit.Before;

import cts.qea.automation.DataFactory;
import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;
import grp.common.CommonFunctions;
import grp.common.Menu;

/**
 * 
 * Create New GroupID by Entering Name, Type, Address, Zipcode, City, State, Phone, Ext, Fax, email,Total number of employees, Total number of eligible employees,
 Total number of contracts, SIC/NAICS code an click save Button
 *Input Data: Please provide required input in testdata.xlxs at section subscriber.Add_New_Group
**/

public class Add_New_Group extends TestCase {

	@Before
	public void before() {
		iteration = "1";
	}
	@Override
	public void test() throws Exception {
		
		String Text_Report=" in Group Indicative Section";
		String Text_Report1=" in Group Address Section";
		String Text_Report2=" in Group Billing/Cap Info Section";	
		
		//Get Client Data from SQL Query
		DataFactory.loadData("tdm.GenericSqlFactory", "Client", dp, driver);
		dp.set("Client", "cmdClient", dp.get("PreRequisite", "CICI_ID"));
		dp.set("Type", "cmdType", dp.get("PreRequisite", "GRGR_MCTR_TYPE"));
			
		
		Report.log("Open Facets Application", Status.BUSINESSSTEP);
		//Open Facet 
		Menu mnu = new Menu(wdriver);
		mnu.openFacetsConnection();
		Report.closeBusinessStep();	
				
		Report.log("Navigate to Subcriber/Family  Application", Status.BUSINESSSTEP);
		CommonFunctions func = new CommonFunctions(wdriver);
		func.navigatetoPage("lnkSubcriberMember", "Subcriber/Member Application Group");
		func.navigatetoPage("lnkGroup", "Group Application");
		Report.closeBusinessStep();
		
		Report.log("Create New GroupID", Status.BUSINESSSTEP);
		func.clickAnyElement("btnFile", "File Menu");
		func.clickAnyElement("btnNew", "New button under File Menu");
						
		//Enter Group ID
		String groupID_New=func.new_GroupID();
		System.out.println("GroupID newly created is"+groupID_New);
		dp.set("GroupID", "txtGroupID", groupID_New);
		String NewGroup_ID=dp.get("GroupID", "txtGroupID");
		func.enter_data("txtApplicationID",NewGroup_ID,"In Creating new Group ID");
		func.clickAnyElement("btnOk", " 'OK' button");
		Report.closeBusinessStep();
		
		Report.log("Enter data for Adding New Group", Status.BUSINESSSTEP);
		//Enter Name
		String Name=dp.get("Name", "txtName");
		func.enter_data_new("txtName_Group",Name,"'Name' as "+"'"+Name+"'"+" "+Text_Report);
		//func.enter_data("txtName_Group",Name,"In Group ID page");
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
				
		//Enter Parent Group ID
//		String ParentGroup_ID=dp.get("ParentGroupID", "txtParentGroupID");
		//func.enter_data_new("txtParentGroupId_Group",ParentGroup_ID,"'ParentGroup_ID' as "+"'"+ParentGroup_ID+"'"+" "+Text_Report);
		//func.enter_data("txtParentGroupId_Group",ParentGroup_ID,"In Group ID page");
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
				
		//Enter Type
		String Type=dp.get("Type", "cmdType");
		func.keyBoard_Operation("Type_New",Type,"'Type' as "+"'"+Type+"'"+" "+Text_Report);
		//func.keyBoard_Operation("Type",Type,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
		
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		
		//Enter Client  txtClient
		String Client=dp.get("Client", "cmdClient");
		func.keyBoard_Operation("Type_New",Client,"'Client' as "+"'"+Client+"'"+" "+Text_Report);
		//func.keyBoard_Operation("Type",Client,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Active
		String Active=dp.get("Active", "cmdActive");
		func.keyBoard_Operation("Type_New",Active,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
		//func.keyBoard_Operation("Type",Active,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
	
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter ITS_Host
		//String ITS_Host=dp.get("ITS_Host", "cmdITS_Host");
		//func.keyBoard_Operation("Type",ITS_Host,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter EffectiveDate
		String EffectiveDate=dp.get("EffectiveDate", "txtEffectiveDate");
		func.keyBoard_Operation("Type",EffectiveDate,"'EffectiveDate' as "+"'"+EffectiveDate+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter Class
		String Class=dp.get("Class", "txtClass");
		func.keyBoard_Operation("Type",Class,"'Class' as "+"'"+Class+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter VIP_Code
		//String VIP_Code=dp.get("VIP_Code", "cmdVIP_Code");
		//func.keyBoard_Operation("Type",VIP_Code,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
				
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Language
		String Language=dp.get("Language", "cmdLanguage");
		func.keyBoard_Operation("Type",Language,"'Language' as "+"'"+Language+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");	
		
		//Select Accepts Accumulator Transfers
		//func.keyBoard_Operation("Space","","");		
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");	
		
		//Select Auto-Number Subscribers
		func.keyBoard_Operation("Space","","");
		
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");	
		
		//Select External Address
		func.keyBoard_Operation("Space","","");	
		
		//Enter Memo
		String Memo=dp.get("Memo", "txtMemo");
		func.enter_data("txtMemo_Group",Memo,"'Memo' as "+"'"+Memo+"'"+" "+Text_Report);
		System.out.println("user enetered memo");
//		Thread.sleep(2000);
	
		//Navigate to address page
		func.navigatetoPage("lnkAddresses", "Group Addresses Section");
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Address
		String Address=dp.get("Address", "txtAddress");
		func.keyBoard_Operation("Type",Address,"'Address' as "+"'"+Address+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter ZipCode
		String ZipCode=dp.get("ZipCode", "txtZipCode");
		func.keyBoard_Operation("Type",ZipCode,"'ZipCode' as "+"'"+ZipCode+"'"+" "+Text_Report1);
		//func.keyBoard_Operation("Backspace","","");
		//func.keyBoard_Operation("Type","9","'ZipCode' as "+"'"+ZipCode+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Select Country
		String Country=dp.get("Country", "cmdCountry");
		func.keyBoard_Operation("Type",Country,"'Country' as "+"'"+Country+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Phone
		String Phone=dp.get("Phone", "txtPhone");
		func.keyBoard_Operation("Type",Phone,"'Phone' as "+"'"+Phone+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter PhoneExt
		String PhoneExt=dp.get("PhoneExt", "txtPhoneExt");
		func.keyBoard_Operation("Type",PhoneExt,"'PhoneExt' as "+"'"+PhoneExt+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Fax
		String Fax=dp.get("Fax", "txtFax");
		func.keyBoard_Operation("Type",Fax,"'Fax' as "+"'"+Fax+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter FaxExt
		String FaxExt=dp.get("FaxExt", "txtFaxExt");
		func.keyBoard_Operation("Type",FaxExt,"'FaxExt' as "+"'"+FaxExt+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter Email
	//	String Email=dp.get("Email", "txtEmail");
	//	func.keyBoard_Operation("Type",Email,"'Active' as "+"'"+Active+"'"+" "+Text_Report);
		
		//Navigate to Billing/Cap Info page
		func.navigatetoPage("lnkBillingCapInfo", "Group Billing/Cap Info Section");
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter BillLevel
		String BillLevel=dp.get("BillLevel", "txtBillLevel");
		func.keyBoard_Operation("Type",BillLevel,"'BillLevel' as "+"'"+BillLevel+"'"+" "+Text_Report2);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter AdjMonths
		String AdjMonths=dp.get("AdjMonths", "txtAdjMonths");
		func.keyBoard_Operation("Type",AdjMonths,"'AdjMonths' as "+"'"+AdjMonths+"'"+" "+Text_Report2);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
				
		//select 'Pay capitation
		func.keyBoard_Operation("Space","","");
		
		//Click Save button
		func.keyBoard_Operation("Save_Button","","");
//		Thread.sleep(2000);
		
		//Checking New Group is created in Facets Application
		func.clickAnyElement("btnFile", "File Menu");
		func.clickAnyElement("btnOpen", "Open Menu");
		func.enter_data("txtApplicationID",groupID_New,"for opening existing Group");
		func.clickAnyElement("btnOk", " 'OK' button");
		Report.closeBusinessStep();
		
		//Validate Group Created
		Report.log("Group Validation", Status.BUSINESSSTEP);
		func.validateGroup(dp);
		Report.closeBusinessStep();
		
		Report.log("Save and close Record", Status.BUSINESSSTEP);
		//Close Application
		func.closeApplication();
		func.navigatetoPage("lnkSubcriberMember", "Subcriber/Member Application Group");
		//Close Facet
		mnu.closeFacets();
		Report.closeBusinessStep();
	}
}