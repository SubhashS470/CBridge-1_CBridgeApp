package com.cts.facets.testcase;

import org.junit.Before;

import cts.qea.automation.DataFactory;
import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;
import grp.common.CommonFunctions;
import grp.common.Menu;

/**
 * 
 * Add Plan for Existing Group by entering all manditory data
 * @Date=12-Mar-19
 * Input Data: Please provide required input in testdata.xlxs at section subscriber.Create_Plan_For_Group
*/

public class Create_Plan_For_Group extends TestCase {

	@Before
	public void before() {
	
		iteration = "1";
		
	}
	@Override
	public void test() throws Exception {
		
		String Text_Report1=" in Medical Plan - Class/Plan Definition - Indicative Section";
		String Text_Report=" in Medical Plan - Class/Plan Definition - Plans Section";
	
		
		//Get Plan Data from SQL Query
		DataFactory.loadData("tdm.GenericSqlFactory", "Plan", dp, driver);
		dp.set("Plan", "txtPlan", dp.get("PreRequisite", "Plan"));
		
		//Get ProductID Data from SQL Query
		//DataFactory.loadData("tdm.GenericSqlFactory", "ProductID", dp, driver);
		dp.set("ProductID", "txtProductID", dp.get("PreRequisite", "Product"));
		
		//Get ClienNetworkSet Data from SQL Query
		//DataFactory.loadData("tdm.GenericSqlFactory", "NetworkSet", dp, driver);
		dp.set("NetworkSet", "txtNetworkSet", dp.get("PreRequisite", "Provider Network Set"));
		
		Report.log("Open Facets Application", Status.BUSINESSSTEP);
		//Open Facet 
		Menu mnu = new Menu(wdriver);
		mnu.openFacetsConnection();
		Report.closeBusinessStep();	
		
		Report.log("Navigate to Class/Plan Definition Application", Status.BUSINESSSTEP);
		CommonFunctions func = new CommonFunctions(wdriver);
			
		//Navigate to Medical Plan page
		func.navigatetoPage("lnkMedicalPlan", "Medical Plan  Application Group");
		
		//Navigate to Class Definition Plan page
		func.navigatetoPage("lnkClassDefinitionPlan", "Class/Plan Definition Application");
		Report.closeBusinessStep();	
		
		Report.log("Create new Plan for Existing Group", Status.BUSINESSSTEP);
		//Steps to create new class
		//Set Group id
		func.clickAnyElement("btnFile", "File Menu");
		func.clickAnyElement("btnNew", "File New");
		
		//Enter Group ID
		//String GroupID=dp.get("GroupID", "txtGroupID");
		String GroupID=CommonFunctions.GroupID_Created;
		
		if(GroupID==null) {
		GroupID=dp.get("GroupID", "txtGroupID");	
		}
		System.out.println("GroupID is  "+GroupID);
		func.enter_data("txtApplicationID",GroupID,"for opening existing Group");
		
		func.clickAnyElement("btnOk", " 'OK' button");
		
		
		//Enter ClassID
		//ClassID_Created
		String classID_New=func.new_ClassID();
		System.out.println("ClassID newly created is"+classID_New);
		dp.set("ClassID", "txtClassID", classID_New);
		String newClass_ID=dp.get("ClassID", "txtClassID");
		func.enter_data("txtApplicationID",newClass_ID,"In Creating new Class ID");
		func.clickAnyElement("btnOk", " 'OK' button");
		Report.closeBusinessStep();
		/*
		//String GroupID=dp.get("GroupID", "txtGroupID");
		String classID=func.ClassID_Created;
		
		if(classID==null) {
			classID=dp.get("ClassID", "txtClassID");	
		}
		System.out.println("ClassID is  "+classID);
		func.enter_data("txtApplicationID",classID,"In Creating new  GroupID");
		
		func.clickAnyElement("btnOk", " 'OK' button");
		func.clickAnyElement("btnYes", " 'Yes' button");
		*/
		
		//**************************
		Report.log("Enter data for creating New Plan for Group", Status.BUSINESSSTEP);
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Description
		String Description=dp.get("Description", "txtDescription"	);
		func.keyBoard_Operation("Type_New",Description,"'Description' as "+"'"+Description+"'"+" "+Text_Report1);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Procedure, Revenue and Service Code Conversion
		String Procedure=dp.get("Procedure", "txtProcedure");
		func.keyBoard_Operation("Type_New",Procedure,"'Procedure' as "+"'"+Procedure+"'"+" "+Text_Report1);
		
		//Click Save button
		func.keyBoard_Operation("Save_Button","","");
		
		
		//************************
		
		//Navigate to Medical Plan page
		func.navigatetoPage("lnkPlans", "Plans Section");
		
		//Click Button 'Add'
		func.clickAnyElement("btnEdit", "File Menu");
		func.clickAnyElement("btnAdd", "File New");
		
		//Enter EffectiveDate
		String EffectiveDate=dp.get("EffectiveDate", "txtEffectiveDate");
		func.keyBoard_Operation("Popup_Type_New",EffectiveDate,"'EffectiveDate' as "+"'"+EffectiveDate+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter UserMessage
		String UserMessage=dp.get("UserMessage", "txtUserMessage");
		func.keyBoard_Operation("Popup_Type_New",UserMessage,"'UserMessage' as "+"'"+UserMessage+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter Plan
		String Plan=dp.get("Plan", "txtPlan");
		func.keyBoard_Operation("Popup_Type_New",Plan,"'Plan' as "+"'"+Plan+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter ProductID
		String ProductID=dp.get("ProductID", "txtProductID");
		func.keyBoard_Operation("Popup_Type_New",ProductID,"'ProductID' as "+"'"+ProductID+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter WaitingPeriodID
		String WaitingPeriodID=dp.get("WaitingPeriodID", "txtWaitingPeriodID");
		func.keyBoard_Operation("Popup_Type_New",WaitingPeriodID,"'WaitingPeriodID' as "+"'"+WaitingPeriodID+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter NetworkSet
		String NetworkSet=dp.get("NetworkSet", "txtNetworkSet");
		func.keyBoard_Operation("Popup_Type_New",NetworkSet,"'NetworkSet' as "+"'"+NetworkSet+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter CoveringProviderSet
		String CoveringProviderSet=dp.get("CoveringProviderSet", "txtCoveringProviderSet");
		func.keyBoard_Operation("Popup_Type_New",CoveringProviderSet,"'CoveringProviderSet' as "+"'"+CoveringProviderSet+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter CoveringMembers
		String CoveringMembers=dp.get("CoveringMembers", "txtCoveringMembers");
		func.keyBoard_Operation("Popup_Type_New",CoveringMembers,"'CoveringMembers' as "+"'"+CoveringMembers+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
			
		//Enter Category
		String Category=dp.get("Category", "txtCategory");
		func.keyBoard_Operation("Popup_Type_New",Category,"'Category' as "+"'"+Category+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter IDCardType
		String IDCardType=dp.get("IDCardType", "txtIDCardType");
		func.keyBoard_Operation("Popup_Type_New",IDCardType,"'Category' as "+"'"+Category+"'"+" "+Text_Report);
		
		//click ok button
		func.clickAnyElement("btnOk", "Ok button");
		Report.closeBusinessStep();
		
		// Validate Plan
		Report.log("Plan Validation", Status.BUSINESSSTEP);
		func.validatePlan(dp);
		Report.closeBusinessStep();
		
		Report.log("Save and close Record", Status.BUSINESSSTEP);		
		//Click Save button
		func.keyBoard_Operation("Save_Button","","");		
		//Close Application
		func.closeApplication();	
		func.navigatetoPage("lnkMedicalPlan", "Medical Plan  Application Group");
		mnu.closeFacets();
		Report.closeBusinessStep();
	}
}