package com.cts.facets.testcase;

import org.junit.Before;

import claims.common.ClaimsCommon;
import claims.hospital.HospitalClaimsIndicative;
import claims.hospital.HospitalClaimsLineItems;
import claims.hospital.HospitalClaimsOverrides;
import common.Applications;
import common.Menu;
import cts.qea.automation.DataFactory;
import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author Gokula Lakshmi TM
 * 
 * Creates hospital claim (using input data) -> Applies Overrides -> Adjudicates(F3) -> 
 * checks and captures error and warning messages if occurred any -> Pend(F5) -> Reads claim id generated ->
 * Reopens the claim -> reads claim status -> validates clinical edit notes against expected(ST(P) Termination). 
 *Input Data: Please provide required input in testdata.xlxs at claims.Hosp_InvalidSubscriber
 */

public class Hosp_InvalidSubscriber extends TestCase {
	@Before
	public void before() {
		iteration = "1";
	}

	@Override
	public void test() throws Exception {

		// Load member data from the SQL query based on the network prefix
		DataFactory.loadData("tdm.GenericSqlFactory", "Subscriber", dp, driver);
		dp.set("Subscriber", "txtMember", dp.get("PreRequisite", "SBSB_ID"));

		// Load provider data from the SQL query based on the network prefix
		DataFactory.loadData("tdm.GenericSqlFactory", "Provider", dp, driver);
		dp.set("Provider", "txtProviderID", dp.get("PreRequisite", "PRPR_ID"));

		// Open Facets
		ClaimsCommon clmcmn = new ClaimsCommon(wdriver);
		Menu mnu = new Menu(wdriver);
		mnu.openFacetsConnection();

		// Navigate to Medical Claims
		Applications app = new Applications(wdriver);
		app.navigatetoHospitalClaimsProcessing();

		// Enter Claims Indicative
		Report.log("Enter Claims Indicative", Status.BUSINESSSTEP);
		HospitalClaimsIndicative ind = new HospitalClaimsIndicative(wdriver);
		ind.enterSubscriberDetails(dp, "Subscriber");
		ind.enterProviderDetails(dp, "Provider");
		ind.enterTypeOfBill(dp, "TypeOfBill");
		ind.enterStmtCoverDates(dp, "StmtCvrPrd");
		// clmcmn.closeErrorMsgWnd();
		ind.enterAdmissionDetails(dp, "Admission");
		ind.enterDischargeDetails(dp, "Discharge");
		ind.enterDiagnosisCode(dp, "DiagnosisCd");
		ind.enterProviderTaxCode(dp, "ProviderTaxCode");
		Report.log("Indicatives Filled", Status.Pass);
		Report.closeBusinessStep();

		// Enter Claim Line Items
		Report.log("Enter Claim Line Items", Status.BUSINESSSTEP);
		clmcmn.navigateToLineItems();
		HospitalClaimsLineItems line = new HospitalClaimsLineItems(wdriver);
		HospitalClaimsOverrides overrides = new HospitalClaimsOverrides(wdriver);

		// Enter first line item
		clmcmn.navigateToHospGrid();
		line.fillTheGrid(dp, "HGrid1");

		// Enter total charges
		line.enterTotalCharges(dp, "HGrid");
		Report.log("Line Items Filled", Status.Pass);

		// Apply Overrides for given lines
		if (!dp.get("Overrides", "Lines").equals("")) {
			for (String li : dp.get("Overrides", "Lines").split(",")) {
				line.navigateToOverrides();
				overrides.applyOverrides(li.trim());
			}
		}
		Report.closeBusinessStep();
		// Adjudicate and pend
		clmcmn.adjudicateClaims("pend");
		String clmid = clmcmn.pendClaim(dp, "Pend", "Hosp");
		if (!clmid.isEmpty()) {
			// Open the claims again to validate
			dp.set("clm", "txtClaimID", clmid.trim());
			clmcmn.openClaim(dp, "clm");
			// Checks the claim status
			clmcmn.checkClaimStatus();
			// Reads clinical edit notes
			clmcmn.readLineItemNotes();
		}
		mnu.closeFacets();
	}
}
