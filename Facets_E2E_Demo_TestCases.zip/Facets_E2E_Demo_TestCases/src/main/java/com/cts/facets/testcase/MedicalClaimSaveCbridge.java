package com.cts.facets.testcase;

import org.junit.Before;

import claims.common.ClaimsCommon;
import claims.medical.MedicalClaimsIndicative;
import claims.medical.MedicalClaimsLineItems;
import claims.medical.MedicalClaimsOverrides;
import common.Applications;
import common.Menu;
import cts.qea.automation.DataFactory;
import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * 
 * Creates medical claim (using input data) -> Applies Overrides -> Adjudicates(F3) -> 
 * checks and captures error and warning messages if occurred any -> Saves(F4) -> Reads claim id generated ->
 * Reopens the claim -> Validates claim lineItems tab and PriceCalculation tab. 
 *Input Data: Please provide required input in testdata.xlxs at claims.MedicalClaimSave_withAgreementValidation
 */

public class MedicalClaimSaveCbridge extends TestCase {
	private static final String CODE = "Code";
	private static final String LINES = "Lines";
	private static final String OVERRIDES2 = "Overrides";
	private static final String PROVIDER_TAX_CODE = "ProviderTaxCode";
	private static final String DIAGNOSIS = "Diagnosis";
	private static final String TXT_PROVIDER_ID = "txtProviderID";
	private static final String TXT_MEMBER = "txtMember";
	private static final String PROVIDER = "Provider";
	private static final String SUBSCRIBER = "Subscriber";
	private static final String PRE_REQUISITE = "PreRequisite";
	private static final String TDM_GENERIC_SQL_FACTORY = "tdm.GenericSqlFactory";

	@Before
	public void before() {
		iteration = "1";
	}

	@Override
	public void test() throws Exception {

		// Load member data from the SQL query based on the network prefix
//		DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, SUBSCRIBER, dp, driver);
//		dp.set(SUBSCRIBER, TXT_MEMBER, dp.get(PRE_REQUISITE, "SBSB_ID"));
		ClaimsCommon clmcmn = new ClaimsCommon(wdriver);
		Menu mnu = new Menu(wdriver);
		Applications app = new Applications(wdriver);
		MedicalClaimsLineItems line = new MedicalClaimsLineItems(wdriver);
		MedicalClaimsOverrides overrides = new MedicalClaimsOverrides(wdriver);
		MedicalClaimsIndicative mi=new MedicalClaimsIndicative(wdriver);
		String sbid=mi.getsubscriberId(dp, "member");
		dp.set(SUBSCRIBER, TXT_MEMBER,sbid );

		// Load provider data from the SQL query based on the network prefix and Agreement ID
		DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, PROVIDER, dp, driver);
		dp.set(PROVIDER, TXT_PROVIDER_ID, dp.get(PRE_REQUISITE, "PRPR_ID"));
//		dp.set(PROVIDER, TXT_PROVIDER_ID, 	"H08JD74601"  );
		
		//Load POS and Diagnosis code based on Procedure code
		DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, CODE, dp, driver);
		dp.set("Diagnosis", "txtDiagnosisCd", dp.get(PRE_REQUISITE, "IDCD_ID"));
		dp.set("Grid1", "POS", dp.get(PRE_REQUISITE, "PSCD_ID"));
		dp.set("Grid1", "Proc", dp.get("DFSub", "IPCD_ID"));
		dp.set("Grid1", "txtDiagnosisCd", dp.get(PRE_REQUISITE, "IDCD_ID"));
		
		
		
		// Open Facets
		mnu.openFacetsConnection();

		// Navigate to Medical Claims
		app.navigatetoMedicalClaimsProcessing();

		// Enter Claims Indicative
		Report.log("Enter Claims Indicative", Status.BUSINESSSTEP);
		MedicalClaimsIndicative ind = new MedicalClaimsIndicative(wdriver);
		ind.enterSubscriberDetails(dp, SUBSCRIBER);
		ind.enterProviderDetails(dp, PROVIDER);
		ind.enterDiagnosisCode(dp, DIAGNOSIS);
		ind.enterProviderTaxCode(dp, PROVIDER_TAX_CODE);
		Report.log("Indicatives Filled", Status.Pass);
		Report.closeBusinessStep();

		// Enter Claim Line Items
		Report.log("Enter Claim Line Items", Status.BUSINESSSTEP);
		clmcmn.navigateToLineItems();

		// Enter first line item
		clmcmn.navigateToMedGrid();
		line.fillTheGrid(dp, "Grid1");

		// Enter total charges
		line.enterTotalCharges(dp, "Grid");
		Report.log("Line Items Filled", Status.Pass);

		// Apply Overrides for given lines
		if (!dp.get(OVERRIDES2, LINES).equals("")) {
			for (String li : dp.get(OVERRIDES2, LINES).split(",")) {
				line.navigateToOverrides();
				overrides.applyOverrides(li.trim());				
			}
		}
		Report.closeBusinessStep();

		// Adjudicate and Save the claim
		if (clmcmn.adjudicateClaims("save")) {
			String clmid = clmcmn.saveClaims();
			if (!clmid.isEmpty()) {
				// Load Claim Benefit data from the SQL query based on the network prefix
				dp.set("DFSub", "CLCL_ID", clmid.trim());
//				DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, "ClaimValidate", dp, driver);
				
				// Open the claims again to validate
				dp.set("clm", "txtClaimID", clmid.trim());
				clmcmn.openClaim(dp, "clm");
				clmcmn.checkClaimStatus();
				// Validate Line item tab
//				clmcmn.stripLineItemData(dp, "LineItem1", 1, "Med");
//				// Validate Price Calculation tab
//				clmcmn.validatePriceCalculation(dp, "Reference");
			}
		}
		mnu.closeFacets();
	}
}
