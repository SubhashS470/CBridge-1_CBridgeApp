package com.cts.facets.testcase;

import org.junit.Before;

import claims.common.ClaimsCommon;
import claims.medical.MedicalClaimsIndicative;
import claims.medical.MedicalClaimsLineItems;
import claims.medical.MedicalClaimsOverrides;
import common.Applications;
import common.Menu;
import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * @author Gokula Lakshmi TM
 * 
 * Creates medical claim (using input data) -> Applies Overrides -> Adjudicates(F3) -> 
 * checks and captures error and warning messages if occurred any -> Pend(F5) -> Reads claim id generated ->
 * Reopens the claim -> reads claim status -> validates actual error message with expected(No Rate Record Match found). 
 *Input Data: Please provide required input in testdata.xlxs at claims.Med_InvalidProviderTaxCode
 */

public class Med_InvalidProviderTaxCode extends TestCase{
	@Before
	public void before() {
		iteration = "1";
	}
	@Override
	public void test() throws Exception {
		
		//Open Facets
		ClaimsCommon clmcmn = new ClaimsCommon(wdriver);
		Menu mnu = new Menu(wdriver);
		mnu.openFacetsConnection();
		
		//Navigate to Medical Claims 
		Applications app= new Applications(wdriver);
		app.navigatetoMedicalClaimsProcessing();
		
		//Enter Claims Indicative
		Report.log("Enter Claims Indicative", Status.BUSINESSSTEP);
		MedicalClaimsIndicative ind= new MedicalClaimsIndicative(wdriver);
		ind.enterSubscriberDetails(dp, "Subscriber");
		ind.enterProviderDetails(dp, "Provider");
		ind.enterDiagnosisCode(dp, "Diagnosis");
		ind.enterProviderTaxCode(dp, "ProviderTaxCode");
		Report.log("Indicatives Filled", Status.Pass);
		Report.closeBusinessStep();
		
		//Enter Claim Line Items
		Report.log("Enter Claim Line Items", Status.BUSINESSSTEP);
		clmcmn.navigateToLineItems();
		MedicalClaimsLineItems line = new MedicalClaimsLineItems(wdriver);
		MedicalClaimsOverrides overrides = new MedicalClaimsOverrides(wdriver);
		
		//Enter first line item
		clmcmn.navigateToMedGrid();
		line.fillTheGrid(dp, "Grid1");
				
		//Enter total charges
		line.enterTotalCharges(dp, "Grid");
		Report.log("Line Items Filled", Status.Pass);
		
		//Apply Overrides for given lines
		if (!dp.get("Overrides", "Lines").equals("")) {
			for (String li: dp.get("Overrides", "Lines").split(",")) {
				line.navigateToOverrides();	
				overrides.BypassDuplicateOverrides(li.trim());
			}
		}
		Report.closeBusinessStep();
		//Adjudicate and pend
		clmcmn.adjudicateClaims("pend");
		String clmid = clmcmn.pendClaim(dp, "Pend", "Med");
		if (!clmid.isEmpty()) {
			
			// Open the claims again to validate
			dp.set("clm", "txtClaimID", clmid.trim());
			clmcmn.openClaim(dp, "clm");			
			// checks claim status
			clmcmn.checkClaimStatus();			
			// Validates actual error msg with expected
			clmcmn.errorAnalyse("InvalidValues");
		}
		mnu.closeFacets();
	}
}
