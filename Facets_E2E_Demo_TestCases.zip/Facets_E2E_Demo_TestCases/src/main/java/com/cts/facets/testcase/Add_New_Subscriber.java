package com.cts.facets.testcase;

import org.junit.Before;

import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;
import grp.common.CommonFunctions;
import grp.common.Menu;
/**
 * @Date: 28-Feb-19
 *Creating new subscriber for existing member ID
 */
public class Add_New_Subscriber extends TestCase {

	@Before
	public void before() {
	
		iteration = "1";
		
	}
	@Override
	public void test() throws Exception {
		
		String Text_Report=" in Subcriber/Family Indicative Section";
		//String Text_Report1=" in Group Address Section";
		
		Report.log("Open Facets Application", Status.BUSINESSSTEP);
		//Open Facet 
		Menu mnu = new Menu(wdriver);
		mnu.openFacetsConnection();
		Report.closeBusinessStep();
		
		
		Report.log("Navigate to Subcriber/Family  Application", Status.BUSINESSSTEP);
		CommonFunctions func = new CommonFunctions(wdriver);
		//Applications app= new Applications(wdriver);
		//app.navigatetoSubscriberFamily();
		
		//navigate subscriber Member page
		func.navigatetoPage("lnkSubcriberMember", "Subcriber/Member Application Group");
		
		//Enter pagedown key
		func.keyBoard_Operation("Page_Down","","");
		//Enter pagedown key
		func.keyBoard_Operation("Page_Down","","");
				
		//navigate subscriber Family page
		func.navigatetoPage("lnkSubcriberFamily", "Subcriber/Family Application");
//		Thread.sleep(3000);
		Report.closeBusinessStep();
		
		Report.log("Open Existing GroupID", Status.BUSINESSSTEP);
		//Steps to create new class
		//Set Group id
		func.clickAnyElement("btnFile", "File Menu");
		func.clickAnyElement("btnNew", "File New");
		
		//Enter Group ID
		//String GroupID=dp.get("GroupID", "txtGroupID");
		String GroupID=CommonFunctions.GroupID_Created;
		
		if(GroupID==null) {
		GroupID=dp.get("GroupID", "txtGroupID");	
		
		}
		System.out.println("GroupID is  "+GroupID);
		func.enter_data("txtApplicationID",GroupID,"for opening existing Group");
		
		func.clickAnyElement("btnOk", " 'OK' button");
		Report.closeBusinessStep();
		
		Report.log("Enter data for Adding New Subscriber", Status.BUSINESSSTEP);
		//Enter Tab key
		func.keyBoard_Operation("Enter","",""); 
		/*
		//ClassID_Created
		String classID_New=func.new_ClassID();
		System.out.println("ClassID newly created is"+classID_New);
		dp.set("ClassID", "txtClassID", classID_New);
		String newClass_ID=dp.get("ClassID", "txtClassID");
		func.enter_data("txtApplicationID",newClass_ID,"In Creating newGroup ID page");
		func.clickAnyElement("btnOk", " 'OK' button");
		
		//common.enterGroupID(dp, "MemberID");
		//Enter Tab key
		func.keyBoard_Operation("Enter","","");
		*/
			
		//common.enterSubscriberDetails(dp, "MemberID");
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
	
		
		//Enter LastName
		String LastName=dp.get("LastName", "txtLastName");
		func.keyBoard_Operation("Type_New",LastName,"'LastName' as "+"'"+LastName+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter FirstName
		String FirstName=dp.get("FirstName", "txtFirstName");
		func.keyBoard_Operation("Type_New",FirstName,"'FirstName' as "+"'"+FirstName+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter Address
		String Address=dp.get("Address", "txtAddress");
		func.keyBoard_Operation("Type_New",Address,"'Address' as "+"'"+Address+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter ZipCode
		String ZipCode=dp.get("ZipCode", "txtZipCode");
		func.keyBoard_Operation("Type_New",ZipCode,"'ZipCode' as "+"'"+ZipCode+"'"+" "+Text_Report);
//		func.keyBoard_Operation("Backspace","","");
//		func.keyBoard_Operation("Type_New","9","'ZipCode' as "+"'"+ZipCode+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter Country
		String Country=dp.get("Country", "cmdCountry");
		func.keyBoard_Operation("Type_New",Country,"'Country' as "+"'"+Country+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Phone
		String Phone=dp.get("Phone", "txtPhone");
		func.keyBoard_Operation("Type_New",Phone,"'Phone' as "+"'"+Phone+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter PhoneExt
		String PhoneExt=dp.get("PhoneExt", "txtPhoneExt");
		func.keyBoard_Operation("Type_New",PhoneExt,"'PhoneExt' as "+"'"+PhoneExt+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Fax
		String Fax=dp.get("Fax", "txtFax");
		func.keyBoard_Operation("Type_New",Fax,"'Fax' as "+"'"+Fax+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter FaxExt
		String FaxExt=dp.get("FaxExt", "txtFaxExt");
		func.keyBoard_Operation("Type_New",FaxExt,"'FaxExt' as "+"'"+FaxExt+"'"+" "+Text_Report);
		
		//Enter Birth date
		func.clickAnyElement("txtBirthDate", " on Birthdate"+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Shift_Tab","","");
		
		//Enter EffectiveDate
		String EffectiveDate=dp.get("EffectiveDate", "txtEffectiveDate");
		func.keyBoard_Operation("Type_New",EffectiveDate,"'EffectiveDate' as "+"'"+EffectiveDate+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter BirthDate
		String BirthDate=dp.get("BirthDate", "txtBirthDate");
		func.keyBoard_Operation("Type_New",BirthDate,"'BirthDate' as "+"'"+BirthDate+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		
		//Enter Gender
		String Gender=dp.get("Gender", "cmbGender");
		func.keyBoard_Operation("Type_New",Gender,"'Gender' as "+"'"+Gender+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter MaritalStatus
		String MaritalStatus=dp.get("MaritalStatus", "cmdMaritalStatus");
		func.keyBoard_Operation("Type_New",MaritalStatus,"'MaritalStatus' as "+"'"+MaritalStatus+"'"+" "+Text_Report);
		
		//Enter Tab key
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		func.keyBoard_Operation("Tab","","");
		
		//Enter Status
		String Status=dp.get("Status", "cmdStatus");
		func.keyBoard_Operation("Type_New",Status,"'Status' as "+"'"+Status+"'"+" "+Text_Report);
		
		//Click Save button
		func.keyBoard_Operation("Save_Button","","");
//		Thread.sleep(2000);
		
		//common.getSubscriberIDcreated(dp, "");
		func.header_Elements("Existing GroupID", "SubscriberID_Created");
		func.validateSubscriber(dp);
		//Report.closeBusinessStep();
		
		//Report.log("Save and close Record", Status.BUSINESSSTEP);
		//Close Application
		func.closeApplication();
		
		//Enter page up key
		func.keyBoard_Operation("Page_Up","","");
		func.keyBoard_Operation("Page_Up","","");
		
		//navigate subscriber Member page
		func.navigatetoPage("lnkSubcriberMember", "Subcriber/Member Application Group");
		mnu.closeFacets();
		Report.closeBusinessStep();

		
	}

}
