package com.cts.facets.ui;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import cts.qea.automation.runners.TestRunner;

public class FacetsCaffe360 extends JFrame {
	private static final long serialVersionUID = 1L;
	private JButton cGrp;
	private JButton cSubscriber;
	private JButton cPlanGroup;
	private JButton claim;
	private JTextArea appConsole = null;
	
	FacetsCaffe360(){
		init();
	}

	private void init() {
//		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(683, 447);
		setTitle("CAFFe360 - Facets Demo");
		setBackground(Color.GREEN);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		JPanel jp = new JPanel();
		jp.setBackground(new Color(204, 204, 153));
		getContentPane().add(jp);
		jp.setLayout(null);
		
		cGrp = new JButton("Create Group");
		cGrp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				testCaseButtonAction("com.cts.facets.testcase.Add_New_Group");
			}
		});
		cGrp.setBounds(20, 63, 147, 23);
		jp.add(cGrp);
		
		cPlanGroup = new JButton("Create Plan");
		cPlanGroup.setBounds(177, 63, 147, 23);
		jp.add(cPlanGroup);
		cPlanGroup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				testCaseButtonAction("com.cts.facets.testcase.Create_Plan_For_Group");
			}
		});
		
		cSubscriber = new JButton("Create Subscriber");
		cSubscriber.setBounds(340, 63, 147, 23);
		jp.add(cSubscriber);
		cSubscriber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				testCaseButtonAction("com.cts.facets.testcase.Add_New_Subscriber");
			}
		});
		
		claim = new JButton("Create Claim");
		claim.setBounds(504, 63, 147, 23);
		jp.add(claim);
		claim.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				testCaseButtonAction("com.cts.facets.testcase.HospitalClaimSave");
			}
		});
		
		JLabel lblCaffeFacets = new JLabel("CAFFe360 - Facets Demo");
		lblCaffeFacets.setHorizontalAlignment(SwingConstants.CENTER);
		lblCaffeFacets.setForeground(new Color(220, 20, 60));
		lblCaffeFacets.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCaffeFacets.setBounds(0, 11, 675, 31);
		jp.add(lblCaffeFacets);
		
		Button button = new Button("Close");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				windowClose();
			}
		});
		button.setBounds(514, 388, 151, 22);
		jp.add(button);
		
		setAppConsole();
		appConsole.setForeground(Color.WHITE);
		appConsole.setBackground(Color.BLACK);
		appConsole.setText("CAFFe360 - Facets Demo. Click each button to run the test cases. ");
		appConsole.setBounds(10, 96, 655, 199);
		jp.add(appConsole);
		JScrollPane spConsole = new JScrollPane(appConsole);
		spConsole.setBounds(10, 96, 655, 286);
		jp.add(spConsole);
	}
	
//	private static void testCaseButtonAction(Class<TestCase> clz) {
	private static void testCaseButtonAction(String clz) {
		try{
			//org.junit.runner.JUnitCore.runClasses(clz);
//			new TestCaseThread(clz, "1").run();
			TestRunner.clearTestRunner();
			TestRunner.addTC(clz, "1", true);
			TestRunner.runSeqential();
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			
		}
	}
	
	private void windowClose() {
		if (JOptionPane.showConfirmDialog(this, "Are you sure you want to close this window?", "Close Window?", 
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION){
			System.exit(0);
		}
	}
	
	public static void main(String a[]) {
		FacetsCaffe360 fc = new FacetsCaffe360();
		fc.setVisible(true);
	}
	
	private class GuiOutputStream extends OutputStream {
		JTextArea textArea;

		public GuiOutputStream(JTextArea textArea) {
			this.textArea = textArea;
		}

		@Override
		public void write(int data) throws IOException {
			textArea.append(new String(new byte[] { (byte) data }));
		}
	}

	private void setAppConsole() {
		appConsole = new JTextArea();
		appConsole.setWrapStyleWord(true);
		GuiOutputStream rawout = new GuiOutputStream(appConsole);
		// Set new stream for System.out
		System.setOut(new PrintStream(rawout, true));
		System.setErr(new PrintStream(rawout, true));
	}
}
