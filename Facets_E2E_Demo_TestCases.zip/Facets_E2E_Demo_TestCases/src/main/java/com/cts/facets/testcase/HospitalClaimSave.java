package com.cts.facets.testcase;		
import org.junit.Before;

import claims.common.ClaimsCommon;
import claims.hospital.HospitalClaimsIndicative;
import claims.hospital.HospitalClaimsLineItems;
import claims.hospital.HospitalClaimsOverrides;
import common.Applications;
import common.Menu;
import cts.qea.automation.DataFactory;
import cts.qea.automation.TestCase;
import cts.qea.automation.reports.Report;
import cts.qea.automation.reports.Status;

/**
 * 
 * Creates hospital claim (using input data) -> Applies Overrides -> Adjudicates(F3) -> 
 * checks and captures error and warning messages if occurred any -> Saves(F4) -> Reads claim id generated ->
 * Reopens the claim -> Validates claim lineItems tab and PriceCalculation tab. 
 *Input Data: Please provide required input in testData/testData.xlxs at com.cts.facets.claims.testcase.HospitalClaimSave
 */

public class HospitalClaimSave extends TestCase {

	private static final String LINES = "Lines";
	private static final String OVERRIDES2 = "Overrides";
	private static final String TXT_MEMBER = "txtMember";
	private static final String PROVIDER_TAX_CODE = "ProviderTaxCode";
	private static final String A_DIAGNOSIS_CD = "ADiagnosisCd";
	private static final String DIAGNOSIS_CD = "DiagnosisCd";
	private static final String DISCHARGE = "Discharge";
	private static final String ADMISSION = "Admission";
	private static final String STMT_CVR_PRD = "StmtCvrPrd";
	private static final String TYPE_OF_BILL = "TypeOfBill";
	private static final String PRE_REQUISITE = "PreRequisite";
	private static final String TXT_PROVIDER_ID = "txtProviderID";
	private static final String PROVIDER = "Provider";
	private static final String SUBSCRIBER = "Subscriber";
	private static final String TDM_GENERIC_SQL_FACTORY = "tdm.GenericSqlFactory";
	private static final String CODE = "Code";

	@Before
	public void before() {
		iteration = "1";
	}

	@Override
	public void test() throws Exception {
		// Load member data from the SQL query based on the network prefix
		 DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, SUBSCRIBER, dp, driver);
		 dp.set(SUBSCRIBER, TXT_MEMBER, dp.get(PRE_REQUISITE, "SBSB_ID"));

		// Load provider data from the SQL query based on the network prefix and Agreement ID
		 DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, PROVIDER, dp, driver);
		 dp.set(PROVIDER, TXT_PROVIDER_ID, dp.get(PRE_REQUISITE, "PRPR_ID"));

		//Load Type_class, Frequency, Rev and Diagnosis code based on Procedure code
		DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, CODE, dp, driver);
		dp.set("TypeOfBill", "TypeClass", (dp.get(PRE_REQUISITE, "CLHP_FAC_TYPE"))+(dp.get(PRE_REQUISITE, "CLHP_BILL_CLASS")));
		dp.set("TypeOfBill", "Frequency", dp.get(PRE_REQUISITE, "CLHP_FREQUENCY"));
		dp.set("DiagnosisCd", "Pri_Code", dp.get(PRE_REQUISITE, "IDCD_ID"));
		dp.set("ADiagnosisCd", "AdmitCode", dp.get(PRE_REQUISITE, "IDCD_ID"));
		dp.set("HGrid1", "rev", dp.get(PRE_REQUISITE, "RCRC_ID"));
		dp.set("HGrid1", "Proc", dp.get("DFSub", "IPCD_ID"));
		dp.set("HGrid1", "txtDiagnosisCd", dp.get(PRE_REQUISITE, "IDCD_ID"));
		
		ClaimsCommon clmcmn = new ClaimsCommon(wdriver);
		Menu mnu = new Menu(wdriver);
		Applications app = new Applications(wdriver);
		HospitalClaimsLineItems line = new HospitalClaimsLineItems(wdriver);
		HospitalClaimsOverrides overrides = new HospitalClaimsOverrides(wdriver);
		
		// Open Facets
		mnu.openFacetsConnection();
		
		// Navigate to Medical Claims
		app.navigatetoHospitalClaimsProcessing();

		// Enter Claims Indicative
		Report.log("Enter Claims Indicative", Status.BUSINESSSTEP);
		HospitalClaimsIndicative ind = new HospitalClaimsIndicative(wdriver);
		ind.enterSubscriberDetails(dp, SUBSCRIBER);
		ind.enterProviderDetails(dp, PROVIDER);
		ind.enterTypeOfBill(dp, TYPE_OF_BILL);
		ind.enterStmtCoverDates(dp, STMT_CVR_PRD);
		ind.enterAdmissionDetails(dp, ADMISSION);
		ind.enterDischargeDetails(dp, DISCHARGE);
		ind.enterDiagnosisCode(dp, DIAGNOSIS_CD);
		ind.enterAdmittingCode(dp, A_DIAGNOSIS_CD);
		ind.enterProviderTaxCode(dp, PROVIDER_TAX_CODE);
		Report.log("Indicatives Filled", Status.Pass);
		Report.closeBusinessStep();

		//Enter Claim Line Items
		Report.log("Enter Claim Line Items", Status.BUSINESSSTEP);
		
		clmcmn.navigateToLineItems();		

		//Enter first line item
		clmcmn.navigateToHospGrid();
		line.fillTheGrid(dp, "HGrid1");

		//Enter second line item
		// line.addNewLine();
		// line.fillTheGrid(dp, "HGrid2");

		// Enter total charges
		line.enterTotalCharges(dp, "HGrid");
		Report.log("Line Items Filled", Status.Pass);
		// Apply Overrides for given lines
		if (!dp.get(OVERRIDES2, LINES).equals("")) {
			for (String li : dp.get(OVERRIDES2, LINES).split(",")) {
				line.navigateToOverrides();
				overrides.BypassDuplicateOverrides(li.trim());
			}
		}
		Report.closeBusinessStep();

		// Adjudicate the claim
		if (clmcmn.adjudicateClaims("save")) {
			String clmid = clmcmn.saveClaims();
			if (!clmid.isEmpty()) {					
				// Load Claim Benefit data from the SQL query based on the network prefix
				dp.set("DFSub", "CLCL_ID", clmid.trim());
				DataFactory.loadData(TDM_GENERIC_SQL_FACTORY, "ClaimValidate", dp, driver);
				
				// Open the claims again to validate
				dp.set("clm", "txtClaimID", clmid.trim());
				clmcmn.openClaim(dp, "clm");
				clmcmn.checkClaimStatus();
				// Validate Line item tab
				clmcmn.stripLineItemData(dp, "LineItem1", 1, "Hosp");
				// Validate Price Calculation tab
				clmcmn.validatePriceCalculation(dp,"Reference");
			}
		}
		// Close facets
		mnu.closeFacets();
	}

}
