package com.cts.facets.testSuite;

import cts.qea.automation.reports.Report;
import cts.qea.automation.runners.TestRunner;

public class TestSuite extends TestRunner {

	public static void main(String[] args) {
		try {
			TestRunner.addTC("com.cts.facets.testcase.Add_New_Group", "1", true);
			TestRunner.addTC("com.cts.facets.testcase.Create_Plan_For_Group", "1", true);
			TestRunner.addTC("com.cts.facets.testcase.Add_New_Subscriber", "1", true);
			TestRunner.addTC("com.cts.facets.testcase.HospitalClaimSave", "1", true);
			
//			TestRunner.addTC("com.cts.facets.testcase.MedicalClaimSave", "1", true);
//			TestRunner.addTC("com.cts.facets.testcase.Hosp_InvalidGridValues", "1", true);
//			TestRunner.addTC("com.cts.facets.testcase.Hosp_InvalidProvider", "1", true);
//			TestRunner.addTC("com.cts.facets.testcase.Hosp_InvalidSubscriber", "1", true);
//			TestRunner.addTC("com.cts.facets.testcase.Med_InvalidProviderTaxCode", "1", true);
			
			//TestRunner.addTCFromXL();
		} catch (Exception e) {
			Report.log(e);
			e.printStackTrace();
		}
		TestRunner.runSeqential();
//		TestRunner.runParallel();
	}
}
