package com.cts.caffe360.loc.plugin.service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * LocEventRequest — inbound DTO received from the IntelliJ plugin.
 * Matches the JSON payload sent by EventDispatcher.
 *
 * The {@link #fileChanges} list contains per-file LOC details when Copilot
 * modified multiple files in a single "Keep All" action. The top-level
 * linesAdded/Modified/Deleted hold the aggregated totals.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LocEventRequest {

    @NotBlank(message = "developerId is required")
    private String developerId;

    private String developerName;

    @NotBlank(message = "projectId is required")
    private String projectId;

    private String sprintId;

    @NotBlank(message = "filePath is required")
    private String filePath;

    @NotBlank(message = "fileName is required")
    private String fileName;

    /** Java class name (without .java extension) that was added/modified/deleted. */
    private String className;

    private String ideType;

    @NotBlank(message = "genAiTool is required")
    private String genAiTool;

    private String developmentMode;

    @PositiveOrZero
    private int linesAdded;

    @PositiveOrZero
    private int linesModified;

    @PositiveOrZero
    private int linesDeleted;

    @NotNull
    private Boolean genAiGenerated;

    private Double genAiConfidenceScore;

    @NotBlank(message = "eventTimestamp is required")
    private String eventTimestamp;

    @NotBlank(message = "sessionId is required")
    private String sessionId;

    /**
     * Per-file change details. When Copilot modifies multiple files in a single
     * "Keep All" action, each file's LOC breakdown is stored here.
     * May be null or empty for single-file or legacy events.
     */
    private List<FileChangeDto> fileChanges;
}

