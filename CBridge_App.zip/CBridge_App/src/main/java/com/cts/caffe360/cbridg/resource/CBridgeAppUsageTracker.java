package com.cts.caffe360.cbridg.resource;

import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.caffe360.cbridg.service.AppUsageTrackerService;
import com.cts.caffe360.cbridg.utiles.CBridgeUtile;
import com.cts.caffe360.cbridg.vo.AppUsageTrackerVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping(value = "/cbridge/api/aut/v1")
@Tag(name = "CBridge API Application Uasge Traker (aut)")
public class CBridgeAppUsageTracker {
	private static final Logger LOG = LoggerFactory.getLogger(CBridgeAppUsageTracker.class);

	@Autowired
	AppUsageTrackerService service;

	private final AtomicLong counter = new AtomicLong();

	@Operation(summary = "Verify the CBridge API for the Application Uasge Traker Service Status")
	@GetMapping("/healthCheck")
	public String getCBridgeHealthCheck() {
		return "Hello CTS: I am good. CBridge API Application Uasge Traker. Total Call Count: "
				+ counter.incrementAndGet();
	}

	@Operation(summary = "Fetch the Application Uasge Traker Service details by Id")
	@GetMapping("/id/{id}")
	public AppUsageTrackerVO getIdValue(@PathVariable String id) throws Exception {
		AppUsageTrackerVO dataVO = null;
		LOG.info("getIdValue: Request id: " + id);
		dataVO = service.findById(id);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(dataVO));
		return dataVO;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/all")
	public List<AppUsageTrackerVO> getAllKeyValue() throws Exception {
		return service.findAll();
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/application/{appName}")
	public List<AppUsageTrackerVO> getTrackerByUserAndApp(@PathVariable String userId, @PathVariable String appName)
			throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserIdAndAppName(userId, appName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Save/Update the Application Uasge Traker details")
	@PostMapping(path = "/update", name = "updateTestData", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public AppUsageTrackerVO update(@RequestBody(required = false) AppUsageTrackerVO vo, Model model) throws Exception {
		LOG.info("Request Object value: " + CBridgeUtile.getJsonObjectString(vo));
		service.update(vo);
		LOG.info("Response Object value: " + CBridgeUtile.getJsonObjectString(vo));
		return vo;
	}
	@Operation(summary = "Update the Application Uasge Traker details")
	@PostMapping(path = "/bulkUpdate", name = "updateTestData", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<AppUsageTrackerVO> bulkUpdate(@RequestBody(required = false) List<AppUsageTrackerVO> voList, Model model) throws Exception {
		LOG.info("Request Object value: " + CBridgeUtile.getJsonObjectString(voList));
		service.bulkUpdate(voList);
		LOG.info("Response Object value: " + CBridgeUtile.getJsonObjectString(voList));
		return voList;
	}
	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}")
	public List<AppUsageTrackerVO> getTrackerByUserID(@PathVariable String userId) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserId(userId);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/fromDate/{from}/toDate/{to}")
	public List<AppUsageTrackerVO> getTrackerByUserIdFromToDate(@PathVariable String userId, @PathVariable String from,
			@PathVariable String to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserIdFromToDate(userId, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/userName/{userName}")
	public List<AppUsageTrackerVO> getTrackerByUserName(@PathVariable String userName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userName);
		res = service.findByUserName(userName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/userName/{userName}/createdDate/{createdDate}")
	public List<AppUsageTrackerVO> getTrackerByUserNameFromToDate(@PathVariable String userName,
			@PathVariable Date from, @PathVariable Date to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userName);
		res = service.findByUserNameFromToDate(userName, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/application/{appName}")
	public List<AppUsageTrackerVO> getTrackerByAppName(@PathVariable String appName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + appName);
		res = service.findByAppName(appName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/fromDate/{from}/toDate/{to}")
	public List<AppUsageTrackerVO> getTrackerByFromAndToDate(@PathVariable String from, @PathVariable String to)
			throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getTrackerByFromAndToDate:From Date: {1} and To Date: {2}", from, to);
		res = service.findByFromToDate(from, to);
		LOG.info("getTrackerByFromAndToDate: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/application/{appName}/fromDate/{from}/toDate/{to}")
	public List<AppUsageTrackerVO> getTrackerByAppNameFromToDate(@PathVariable String appName,
			@PathVariable String from, @PathVariable String to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + appName);
		res = service.findByAppNameFromToDate(appName, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/moduleName/{moduleName}")
	public List<AppUsageTrackerVO> getTrackerByModuleName(@PathVariable String moduleName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + moduleName);
		res = service.findByModuleName(moduleName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/moduleName/{moduleName}/createdDate/{createdDate}")
	public List<AppUsageTrackerVO> getTrackerByModuleNameFromToDate(@PathVariable String moduleName,
			@PathVariable Date from, @PathVariable Date to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + moduleName);
		res = service.findByModuleNameFromToDate(moduleName, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/transactionType/{transactionType}")
	public List<AppUsageTrackerVO> getTrackerByTxnType(@PathVariable String transactionType) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + transactionType);
		res = service.findByTxnType(transactionType);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/transactionType/{transactionType}/createdDate/{createdDate}")
	public List<AppUsageTrackerVO> getTrackerByTxnTypeFromToDate(@PathVariable String transactionType,
			@PathVariable Date from, @PathVariable Date to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + transactionType);
		res = service.findByTxnTypeFromToDate(transactionType, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/moduleName/{moduleName}/application/{appName}")
	public List<AppUsageTrackerVO> getTrackerByModuleNameAndAppName(@PathVariable String moduleName,
			@PathVariable String appName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + appName);
		res = service.findByModuleNameAndAppName(moduleName, appName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/moduleName/{moduleName}/application/{appName}/fromDate/{from}/toDate/{to}")
	public List<AppUsageTrackerVO> getTrackerByModuleNameAndAppNameFromToDate(@PathVariable String moduleName,
			@PathVariable String appName, @PathVariable String from, @PathVariable String to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + appName);
		res = service.findByModuleNameAndAppNameFromToDate(moduleName, appName, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/moduleName/{moduleName}/application/{appName}/createdDate/{createdDate}")
	public List<AppUsageTrackerVO> getByUserIdAndAppNameAndModuleNameAndDateFromToDate(@PathVariable String userId,
			@PathVariable String moduleName, @PathVariable String appName, @PathVariable Date from,
			@PathVariable Date to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserIdAndAppNameAndModuleNameAndDateFromToDate(userId, appName, moduleName, to, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/application/{appName}/moduleName/{moduleName}")
	public List<AppUsageTrackerVO> getByUserIdAndAppNameAndModuleName(@PathVariable String userId,
			@PathVariable String appName, @PathVariable String moduleName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserIdAndAppNameAndModuleName(userId, appName, moduleName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/application/{appName}/moduleName/{moduleName}/transactionType/{transactionType}")
	public List<AppUsageTrackerVO> getByUserIdAndAppNameAndModuleNameAndTxnType(@PathVariable String userId,
			@PathVariable String appName, @PathVariable String moduleName, @PathVariable String transactionType)
			throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserIdAndAppNameAndModuleNameAndTxnType(userId, appName, moduleName, transactionType);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/application/{appName}/moduleName/{moduleName}/transactionType/{transactionType}/createdDate/{createdDate}")
	public List<AppUsageTrackerVO> getByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(
			@PathVariable String userId, @PathVariable String appName, @PathVariable String moduleName,
			@PathVariable String transactionType, @PathVariable Date from, @PathVariable Date to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(userId, appName, moduleName,
				transactionType, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/towerName/{towerName}")
	public List<AppUsageTrackerVO> getTrackerByTowerName(@PathVariable String towerName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + towerName);
		res = service.findByTower(towerName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/towerName/{towerName}/createdDate/{createdDate}")
	public List<AppUsageTrackerVO> getTrackerByTowerNameAndFromAndTodate(@PathVariable String towerName,
			@PathVariable Date from, @PathVariable Date to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + towerName);
		res = service.findByTowerNameAndFromAndTodate(towerName, from, to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/user/{userId}/towerName/{towerName}")
	public List<AppUsageTrackerVO> getTrackerByUserIdAndTowerName(@PathVariable String userId,
			@PathVariable String towerName) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + towerName);
		res = service.findByUserIdAndTowerName(userId, towerName);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	@Operation(summary = "Fetch all the Application Uasge Traker details")
	@GetMapping("/towerName/{towerName}/user/{userId}/application/{appName}/moduleName/{moduleName}/transactionType/{txnType}/fromDate/{from}/toDate/{to}")
	public List<AppUsageTrackerVO> getByAllFetch(@PathVariable String towerName, @PathVariable String userId,
			@PathVariable String appName, @PathVariable String moduleName, @PathVariable String txnType,
			@PathVariable String from, @PathVariable String to) throws Exception {
		List<AppUsageTrackerVO> res = null;
		LOG.info("getIdValue: Request id: " + userId);
		res = service.findByAllFetch(getEmptyOrNullToNull(towerName), getEmptyOrNullToNull(userId),
				getEmptyOrNullToNull(appName), getEmptyOrNullToNull(moduleName), getEmptyOrNullToNull(txnType), from,
				to);
		LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
		return res;
	}

	private static String getEmptyOrNullToNull(String str) {
		return ("EON".equals(str)) ? null : str.trim();
	}
}

