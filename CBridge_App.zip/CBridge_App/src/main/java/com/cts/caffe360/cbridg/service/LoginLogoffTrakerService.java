package com.cts.caffe360.cbridg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.exception.CBridgeDBException;
import com.cts.caffe360.cbridg.exception.CBridgeServiceException;
import com.cts.caffe360.cbridg.vo.LoginLogoffTrakerVO;

@Service
public interface LoginLogoffTrakerService {

	LoginLogoffTrakerVO save(LoginLogoffTrakerVO vo) throws CBridgeDBException;
	
	LoginLogoffTrakerVO update(LoginLogoffTrakerVO vo) throws CBridgeDBException, CBridgeServiceException;
	
	LoginLogoffTrakerVO findById(String Id) throws CBridgeDBException, CBridgeServiceException;
	
	List<LoginLogoffTrakerVO> findAll() throws CBridgeDBException;

	List<LoginLogoffTrakerVO> findByAppName(String appName) throws CBridgeDBException;
	
	List<LoginLogoffTrakerVO> findByModuleName(String moduleName) throws CBridgeDBException;

	List<LoginLogoffTrakerVO> findByUserIdAndAppName(String userId, String appName);

}
