package com.cts.caffe360.cbridg.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.constants.CBridgeConstant;
import com.cts.caffe360.cbridg.dao.impl.ReactiveCBridgeDAOImpl;
import com.cts.caffe360.cbridg.domain.CBridgeTestDataDO;
import com.cts.caffe360.cbridg.exception.CBridgeServiceException;
import com.cts.caffe360.cbridg.service.CBridgeService;
import com.cts.caffe360.cbridg.vo.CBridgeTestDataVO;

@Service
public class CBridgeServiceImpl implements CBridgeService{
    private static final Logger LOG = LoggerFactory.getLogger(CBridgeServiceImpl.class);

    @Autowired
    ReactiveCBridgeDAOImpl dao;

    @Override
    public CBridgeTestDataVO findById(String id) throws Exception{
    	CBridgeTestDataDO dos = dao.findById(id);
        return getCBridgeTestDataVO(dos);
    }

	private CBridgeTestDataVO getCBridgeTestDataVO(CBridgeTestDataDO dos) {
		CBridgeTestDataVO vo = new CBridgeTestDataVO();
    	BeanUtils.copyProperties(dos, vo);
    	vo.setId(dos.get_id());
//    	for(CBridgeKeyValuesDO doVal : dos.getValues()) {
//    		CBridgeKeyValuesVO voVal = new CBridgeKeyValuesVO();
//    		BeanUtils.copyProperties(doVal, voVal);
////    		vo.addKeyValue(voVal);
//    	}
		return vo;
	}

    @Override
    public List<CBridgeTestDataVO> findByKey(String key) throws Exception{
        return getCBridgeTestDataVOList(dao.findByKey(key));
    }

	private List<CBridgeTestDataVO> getCBridgeTestDataVOList(List<CBridgeTestDataDO> doLst) {
    	List<CBridgeTestDataVO> voLst = new ArrayList<CBridgeTestDataVO>();
    	voLst = doLst.stream().map(dos -> { CBridgeTestDataVO vo = new CBridgeTestDataVO();
    										BeanUtils.copyProperties(dos, vo); 
    										vo.setId(dos.get_id());
    										return vo;
    									   }
    							).collect(Collectors.toList());
		return voLst;
	}

    @Override
    public List<CBridgeTestDataVO> fetchAllCBridgeDocument() throws Exception{
    	List<CBridgeTestDataDO> doLst = dao.findAll();
        return getCBridgeTestDataVOList(doLst);
    }

    @Override
    public CBridgeTestDataVO findByIdAndKey(String id, String key) throws Exception{
    	CBridgeTestDataDO dos = dao.findByIdAndKey(id, key);
        return getCBridgeTestDataVO(dos);
    }

    @Override
    public List<CBridgeTestDataVO> findByKeyAndValue(String key, String value) throws Exception{
    	List<CBridgeTestDataDO> doLst = dao.findByKeyAndValue(key, value);
        return getCBridgeTestDataVOList(doLst);
    }

    @Override
    public List<CBridgeTestDataVO> findByKeyAndValue(String key, String value, String module, LocalDate updateDate) throws Exception{
        return getCBridgeTestDataVOList(dao.findByKeyAndValue(key, value, module));
    }

    @Override
    public void deleteKeyValue(String key, String module, String value) throws Exception{
    	return;
    }

    @Override
    public void deleteKeyValueAll(String key, String module) throws Exception{
    	return;
    }

    @Override
    public void deleteKeyValueExpiryDate(String key, String module) throws Exception{
    	return;
    }

    @Override
    public CBridgeTestDataVO save(CBridgeTestDataVO vo) throws Exception {
        return null;
    }

    @SuppressWarnings("unused")
	@Override
    public CBridgeTestDataVO update(CBridgeTestDataVO voObj) throws Exception{
    	CBridgeTestDataDO dbObj = null;
    	Long id = (voObj.getId() != null && voObj.getId().longValue() > 0 ? voObj.getId() : 0);
		try{
			dbObj = dao.findByKeyModuleUser(voObj.getKey(), voObj.getModuleName(), voObj.getCreatedUser());
			if (dbObj == null && id > 0) {
				dbObj =  dao.findById(id+"");
			} else if (dbObj != null) {
				id = dbObj.get_id();
			} else {
				LOG.info("Data Not Found");
			}
		} catch(Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
			throw new CBridgeServiceException(ex.getMessage());
		}
		
        if (dbObj == null || id == 0){
            id = dao.generateSequence(CBridgeConstant.SEQUENCE_NAME);
            LOG.info("Test Data Save operation and Id: " + id);
            dbObj = new CBridgeTestDataDO();
            dbObj.set_id(id);
            BeanUtils.copyProperties(voObj, dbObj);
//            updateRowIndex(dbObj);
            dao.save(dbObj);
        } else {
        	LOG.info("DB Update Process for the Unique key -> key: "+dbObj.getKey() + "\t Module Name: " + dbObj.getModuleName() + "\t User Name: " + dbObj.getCreatedUser() );
        	updateCBridgeTestDataDO(dbObj, voObj);//update with new value
            dao.update(dbObj);
        }
        BeanUtils.copyProperties(dbObj, voObj);
        voObj.setId(id);
        return voObj;
    }
    
//    private void updateRowIndex(CBridgeTestDataDO doObj) {
//    	doObj.getValues().forEach(d -> d.setRowIndex(doObj.increase()));
//    }
    
    private void updateCBridgeTestDataDO(CBridgeTestDataDO dbDO, CBridgeTestDataVO voObj) {
    	LOG.info("updateCBridgeTestDataDO");
    	dbDO.setCreatedUser(getValideValue(dbDO.getCreatedUser(), voObj.getCreatedUser()));
    	dbDO.setModuleName(getValideValue(dbDO.getModuleName(), voObj.getModuleName()));
    	dbDO.setKey(getValideValue(dbDO.getKey(), voObj.getKey()));
    	setKeyValues(dbDO, voObj);
    }

    private String getValideValue(String dbVal, String userVal) {
    	return (StringUtils.isNotBlank(userVal) ? userVal : dbVal);
    }

	@Override
	public List<CBridgeTestDataVO> findByValue(String value) throws Exception {
		List<CBridgeTestDataVO> lstRes = new ArrayList<>();
		return lstRes;
	}
    
	private void setKeyValues(CBridgeTestDataDO dbDO, CBridgeTestDataVO voObj) {
		Map<String, String> valDO = dbDO.getKeyValues();
		Map<String, String> valVO = voObj.getKeyValues();
		for (String keyVO : valVO.keySet()) {
			boolean notUpdated = true;
			for (String keyDO : valDO.keySet()) {
				if(keyDO.equalsIgnoreCase(keyVO)) {
					valDO.put(keyDO, valVO.get(keyVO));
					notUpdated = false;
					break;
				}
			}
			if (notUpdated) {
				valDO.put(keyVO, valVO.get(keyVO));
			}
		}
	}

	@Override
	public CBridgeTestDataVO findByKeyModuleUser(String key, String module, String user) throws Exception {
        return getCBridgeTestDataVO(dao.findByKeyModuleUser(key, module, user));
	}
}
