package com.cts.caffe360.loc.plugin.service.service;

import com.cts.caffe360.loc.plugin.service.dto.*;
import com.cts.caffe360.loc.plugin.service.exception.GlobalExceptionHandler;
import com.cts.caffe360.loc.plugin.service.exception.LocEventNotFoundException;
import com.cts.caffe360.loc.plugin.service.model.FileChange;
import com.cts.caffe360.loc.plugin.service.model.LocEvent;
import com.cts.caffe360.loc.plugin.service.repository.LocEventRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * LocEventService — core business logic for CRUD operations on LOC events.
 *
 * Responsibilities:
 *   - Map DTO ↔ Document
 *   - Deduplication check before insert (same dev + file + timestamp + session)
 *   - Delegate persistence to LocEventRepository (MongoDB DAO)
 *   - Build LocSummary aggregations
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LocEventService {
	private static final Logger LOG = LoggerFactory.getLogger(LocEventService.class);
	
    private LocEventRepository repository;

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * Save a single LOC event. Skips duplicate events (idempotent).
     */
    public LocEventResponse create(LocEventRequest req) {
        if (isDuplicate(req)) {
        	LOG.debug("create: duplicate skipped dev={} file={} ts={}",
                    req.getDeveloperId(), req.getFileName(), req.getEventTimestamp());
            // Return existing record
            return repository
                    .findBySessionIdAndFileNameAndEventTimestamp(
                            req.getSessionId(), req.getFileName(), req.getEventTimestamp())
                    .map(this::toResponse)
                    .orElse(saveAndReturn(req));
        }
        return saveAndReturn(req);
    }

    /**
     * Save a batch of LOC events. Each event is deduplicated individually.
     */
    public List<LocEventResponse> createBatch(List<LocEventRequest> requests) {
    	LOG.info("createBatch: processing {} events", requests.size());
        return requests.stream()
                .map(this::create)
                .collect(Collectors.toList());
    }

    // ── READ ──────────────────────────────────────────────────────────────────

    /** Get a single event by MongoDB document ID. */
    public LocEventResponse getById(String id) {
        LocEventResponse cached = repository.findById(id)
                .map(this::toResponse)
                .orElseThrow(() -> new LocEventNotFoundException("LocEvent not found: " + id));
        if (cached != null) {
        	LOG.debug("getById: cache hit for id={}", id);
        	LOG.debug("getById: event details: dev={} file={} ts={}",
                    cached.getDeveloperId(), cached.getFileName(), cached.getEventTimestamp());
        } else {
        	LOG.debug("getById: cache miss for id={}", id);
        }
        return cached;

    }

    /** List all events (paginated). */
    public Page<LocEventResponse> getAll(Pageable pageable) {
        return repository.findAll(pageable).map(this::toResponse);
    }

    /** List events by developer (paginated). */
    public Page<LocEventResponse> getByDeveloper(String developerId, Pageable pageable) {
        return repository.findByDeveloperId(developerId, pageable).map(this::toResponse);
    }

    /** List events by developer within a timestamp range (paginated). */
    public Page<LocEventResponse> getByDeveloperInRange(
            String developerId, String from, String to, Pageable pageable) {
    	LOG.info("getByDeveloperInRange: dev={} from={} to={}", developerId, from, to);
        Page<LocEventResponse> locRes = repository.findByDeveloperIdAndEventTimestampBetween(developerId, from, to, pageable)
                .map(this::toResponse);
        LOG.debug("getByDeveloperInRange: found {} events for dev={} in range", locRes.getTotalElements(), developerId);
        return locRes;
    }

    /** List events by project (paginated). */
    public Page<LocEventResponse> getByProject(String projectId, Pageable pageable) {
        return repository.findByProjectId(projectId, pageable).map(this::toResponse);
    }

    /** List events by project within a timestamp range (paginated). */
    public Page<LocEventResponse> getByProjectInRange(
            String projectId, String from, String to, Pageable pageable) {
        return repository
                .findByProjectIdAndEventTimestampBetween(projectId, from, to, pageable)
                .map(this::toResponse);
    }

    /** List events by developer AND project (paginated). */
    public Page<LocEventResponse> getByDeveloperAndProject(
            String developerId, String projectId, Pageable pageable) {
        return repository
                .findByDeveloperIdAndProjectId(developerId, projectId, pageable)
                .map(this::toResponse);
    }

    /** List events by developer + project within a timestamp range (paginated). */
    public Page<LocEventResponse> getByDeveloperAndProjectInRange(
            String developerId, String projectId, String from, String to, Pageable pageable) {
        return repository
                .findByDeveloperIdAndProjectIdAndEventTimestampBetween(
                        developerId, projectId, from, to, pageable)
                .map(this::toResponse);
    }

    /** List events by GenAI tool (paginated). */
    public Page<LocEventResponse> getByTool(String genAiTool, Pageable pageable) {
        return repository.findByGenAiTool(genAiTool, pageable).map(this::toResponse);
    }

    /** List events by sprint. */
    public List<LocEventResponse> getBySprint(String projectId, String sprintId) {
        return repository.findByProjectIdAndSprintIdAll(projectId, sprintId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /** List events belonging to a session (for replay / dedup). */
    public List<LocEventResponse> getBySession(String sessionId) {
        return repository.findBySessionId(sessionId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * Full update — replace all fields of an existing event.
     */
    public LocEventResponse update(String id, LocEventRequest req) {
        LocEvent existing = repository.findById(id)
                .orElseThrow(() -> new LocEventNotFoundException("LocEvent not found: " + id));

        LocEvent updated = toDocument(req);
        updated.setId(existing.getId());
        updated.setCreatedAt(existing.getCreatedAt());   // preserve original creation time

        LocEvent saved = repository.save(updated);
        LOG.info("update: id={} dev={} file={}", id, req.getDeveloperId(), req.getFileName());
        return toResponse(saved);
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    /** Delete a single event by ID. */
    public void delete(String id) {
        if (!repository.existsById(id)) {
            throw new LocEventNotFoundException("LocEvent not found: " + id);
        }
        repository.deleteById(id);
        LOG.info("delete: id={}", id);
    }

    /** Delete all events belonging to a session (e.g. replay cleanup). */
    public long deleteBySession(String sessionId) {
        List<LocEvent> events = repository.findBySessionId(sessionId);
        repository.deleteAll(events);
        LOG.info("deleteBySession: sessionId={} removed={}", sessionId, events.size());
        return events.size();
    }

    // ── SUMMARY / AGGREGATION ─────────────────────────────────────────────────

    /**
     * Compute LOC summary for a developer within a date range.
     */
    public LocSummary getSummaryByDeveloper(String developerId, String from, String to) {
        List<LocEvent> events = repository.findByDeveloperIdInRange(developerId, from, to);
        return buildSummary(events, developerId, null, from, to);
    }

    /**
     * Compute LOC summary for a project within a date range.
     */
    public LocSummary getSummaryByProject(String projectId, String from, String to) {
        List<LocEvent> events = repository.findByProjectIdInRange(projectId, from, to);
        return buildSummary(events, null, projectId, from, to);
    }

    /**
     * Compute LOC summary for a project sprint.
     */
    public LocSummary getSummaryBySprint(String projectId, String sprintId) {
        List<LocEvent> events = repository.findByProjectIdAndSprintIdAll(projectId, sprintId);
        return buildSummary(events, null, projectId, "sprint:" + sprintId, sprintId);
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private boolean isDuplicate(LocEventRequest req) {
        return repository.existsByDeveloperIdAndFileNameAndEventTimestampAndSessionId(
                req.getDeveloperId(), req.getFileName(),
                req.getEventTimestamp(), req.getSessionId());
    }

    private LocEventResponse saveAndReturn(LocEventRequest req) {
        LocEvent saved = repository.save(toDocument(req));
        LOG.debug("saveAndReturn: id={} dev={} file={} tool={} +lines={}",
                saved.getId(), saved.getDeveloperId(), saved.getFileName(),
                saved.getGenAiTool(), saved.getLinesAdded());
        return toResponse(saved);
    }

    /** DTO → Document */
    private LocEvent toDocument(LocEventRequest req) {
        // Map fileChanges DTO list → model list
        List<FileChange> fileChanges = new ArrayList<>();
        if (req.getFileChanges() != null) {
            for (FileChangeDto fc : req.getFileChanges()) {
                fileChanges.add(FileChange.builder()
                        .filePath(fc.getFilePath())
                        .fileName(fc.getFileName())
                        .className(fc.getClassName())
                        .linesAdded(fc.getLinesAdded())
                        .linesModified(fc.getLinesModified())
                        .linesDeleted(fc.getLinesDeleted())
                        .build());
            }
        }
        return LocEvent.builder()
                .developerId(req.getDeveloperId())
                .developerName(req.getDeveloperName())
                .projectId(req.getProjectId())
                .sprintId(req.getSprintId())
                .filePath(req.getFilePath())
                .fileName(req.getFileName())
                .className(req.getClassName())
                .ideType(req.getIdeType() != null ? req.getIdeType() : "INTELLIJ")
                .genAiTool(req.getGenAiTool())
                .developmentMode(req.getDevelopmentMode())
                .linesAdded(req.getLinesAdded())
                .linesModified(req.getLinesModified())
                .linesDeleted(req.getLinesDeleted())
                .genAiGenerated(Boolean.TRUE.equals(req.getGenAiGenerated()))
                .genAiConfidenceScore(req.getGenAiConfidenceScore())
                .eventTimestamp(req.getEventTimestamp())
                .sessionId(req.getSessionId())
                .fileChanges(fileChanges)
                .build();
    }

    /** Document → Response DTO */
    private LocEventResponse toResponse(LocEvent e) {
        // Map fileChanges model list → DTO list
        List<FileChangeDto> fileChangeDtos = new ArrayList<>();
        if (e.getFileChanges() != null) {
            for (FileChange fc : e.getFileChanges()) {
                fileChangeDtos.add(FileChangeDto.builder()
                        .filePath(fc.getFilePath())
                        .fileName(fc.getFileName())
                        .className(fc.getClassName())
                        .linesAdded(fc.getLinesAdded())
                        .linesModified(fc.getLinesModified())
                        .linesDeleted(fc.getLinesDeleted())
                        .build());
            }
        }
        return LocEventResponse.builder()
                .id(e.getId())
                .developerId(e.getDeveloperId())
                .developerName(e.getDeveloperName())
                .projectId(e.getProjectId())
                .sprintId(e.getSprintId())
                .filePath(e.getFilePath())
                .fileName(e.getFileName())
                .className(e.getClassName())
                .ideType(e.getIdeType())
                .genAiTool(e.getGenAiTool())
                .developmentMode(e.getDevelopmentMode())
                .linesAdded(e.getLinesAdded())
                .linesModified(e.getLinesModified())
                .linesDeleted(e.getLinesDeleted())
                .genAiGenerated(e.isGenAiGenerated())
                .genAiConfidenceScore(e.getGenAiConfidenceScore())
                .eventTimestamp(e.getEventTimestamp())
                .sessionId(e.getSessionId())
                .fileChanges(fileChangeDtos)
                .createdAt(e.getCreatedAt())
                .updatedAt(e.getUpdatedAt())
                .build();
    }

    /** Build a LocSummary from a list of events. */
    private LocSummary buildSummary(List<LocEvent> events,
                                    String developerId, String projectId,
                                    String from, String to) {
        long totalEvents    = events.size();
        long genAiEvents    = events.stream().filter(LocEvent::isGenAiGenerated).count();
        long manualEvents   = totalEvents - genAiEvents;

        long totalAdded     = events.stream().mapToLong(LocEvent::getLinesAdded).sum();
        long totalModified  = events.stream().mapToLong(LocEvent::getLinesModified).sum();
        long totalDeleted   = events.stream().mapToLong(LocEvent::getLinesDeleted).sum();

        long genAiAdded     = events.stream()
                .filter(LocEvent::isGenAiGenerated)
                .mapToLong(LocEvent::getLinesAdded).sum();
        long manualAdded    = totalAdded - genAiAdded;

        double adoptionPct  = totalAdded == 0 ? 0.0
                : Math.round((genAiAdded * 100.0 / totalAdded) * 100.0) / 100.0;

        double avgConf      = events.stream()
                .filter(e -> e.getGenAiConfidenceScore() != null)
                .mapToDouble(LocEvent::getGenAiConfidenceScore)
                .average().orElse(0.0);

        // determine most-used tool
        String primaryTool = events.stream()
                .filter(LocEvent::isGenAiGenerated)
                .collect(Collectors.groupingBy(LocEvent::getGenAiTool, Collectors.counting()))
                .entrySet().stream()
                .max(java.util.Map.Entry.comparingByValue())
                .map(java.util.Map.Entry::getKey)
                .orElse("NONE");

        return LocSummary.builder()
                .developerId(developerId)
                .projectId(projectId)
                .genAiTool(primaryTool)
                .fromTimestamp(from)
                .toTimestamp(to)
                .totalEvents(totalEvents)
                .genAiEvents(genAiEvents)
                .manualEvents(manualEvents)
                .totalLinesAdded(totalAdded)
                .totalLinesModified(totalModified)
                .totalLinesDeleted(totalDeleted)
                .genAiLinesAdded(genAiAdded)
                .manualLinesAdded(manualAdded)
                .genAiAdoptionPct(adoptionPct)
                .avgConfidenceScore(avgConf)
                .build();
    }
}

