package com.cts.caffe360.cbridg.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ActiveBatchJobVO implements Serializable {
	private static final long serialVersionUID = 828601686864671083L;
	@JsonProperty("ab_job_id")
	private String abJobId;
	@JsonProperty("ab_job_name")
	private String abJobName;
	@JsonProperty("ab_job_exe_ststus")
	private String abJobExeStstus;
	
	public ActiveBatchJobVO() {
		super();
	}
	public ActiveBatchJobVO(String abJobId, String abJobName, String abJobExeStstus) {
		super();
		this.abJobId = abJobId;
		this.abJobName = abJobName;
		this.abJobExeStstus = abJobExeStstus;
	}
	
	/**
	 * @return the abJobId
	 */
	public String getAbJobId() {
		return abJobId;
	}
	/**
	 * @param abJobId the abJobId to set
	 */
	public void setAbJobId(String abJobId) {
		this.abJobId = abJobId;
	}
	/**
	 * @return the abJobName
	 */
	public String getAbJobName() {
		return abJobName;
	}
	/**
	 * @param abJobName the abJobName to set
	 */
	public void setAbJobName(String abJobName) {
		this.abJobName = abJobName;
	}
	/**
	 * @return the abJobExeStstus
	 */
	public String getAbJobExeStstus() {
		return abJobExeStstus;
	}
	/**
	 * @param abJobExeStstus the abJobExeStstus to set
	 */
	public void setAbJobExeStstus(String abJobExeStstus) {
		this.abJobExeStstus = abJobExeStstus;
	}
	@Override
	public String toString() {
		return "ActiveBatchJobVO [abJobId=" + abJobId + ", abJobName=" + abJobName + ", abJobExeStstus="
				+ abJobExeStstus + "]";
	}
}
