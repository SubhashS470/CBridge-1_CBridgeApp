package com.cts.caffe360.loc.plugin.testcode;

public class StringProcessor {

    public static void main(String[] args) {
        
    }

    public int sum(int a, int b) {
        return a + b;
    }

}
