package com.cts.caffe360.cbridg.exception;

public class CBridgeServiceException extends Exception{

	private static final long serialVersionUID = 1L;

	public CBridgeServiceException() {
        super();
    }

    public CBridgeServiceException(String s) {
        super(s);
    }

    public CBridgeServiceException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CBridgeServiceException(Throwable throwable) {
        super(throwable);
    }

    protected CBridgeServiceException(String s, Throwable throwable, boolean b, boolean b1) {
        super(s, throwable, b, b1);
    }
}
