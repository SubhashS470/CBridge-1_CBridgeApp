package com.cts.caffe360.loc.plugin.service.exception;

public class LocEventNotFoundException extends RuntimeException {
    public LocEventNotFoundException(String message) {
        super(message);
    }
}

