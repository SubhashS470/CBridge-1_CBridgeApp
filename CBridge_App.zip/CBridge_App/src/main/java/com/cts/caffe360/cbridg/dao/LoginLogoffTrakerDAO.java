package com.cts.caffe360.cbridg.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.domain.LoginLogoffTrakerDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;

@Repository
public interface LoginLogoffTrakerDAO extends CBridgeDAO {
	void save(LoginLogoffTrakerDO dos) throws CBridgeDBException;
	
	void update(LoginLogoffTrakerDO dos) throws CBridgeDBException;
	
	List<LoginLogoffTrakerDO> findAll() throws CBridgeDBException;

	void insert(LoginLogoffTrakerDO dos) throws CBridgeDBException;
	
	List<LoginLogoffTrakerDO> findByAppName(String appName) throws CBridgeDBException;
	
	List<LoginLogoffTrakerDO> findByModuleName(String moduleName) throws CBridgeDBException;
	
	LoginLogoffTrakerDO findById(String id) throws CBridgeDBException;

}
