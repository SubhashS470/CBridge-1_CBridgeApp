package com.cts.caffe360.cbridg.resource;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.service.TmgUserDetailsService;
import com.cts.caffe360.cbridg.utiles.CBridgeUtile;
import com.cts.caffe360.cbridg.vo.TmgUserDetailsVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping(value = "/cbridge/api/tmguser/v1")
@Tag(name = "CBridge API - TMG User Details Service")
public class CBridgeTmgUserAPI {

	private static final Logger LOG = LoggerFactory.getLogger(CBridgeTmgUserAPI.class);

	@Autowired
	private TmgUserDetailsService tmgUserDetailsService;

	private final AtomicLong counter = new AtomicLong();

	@Operation(summary = "Verify the CBridge API for the TMG User Details Service Status")
	@GetMapping("/healthCheck_tmguser")
	public String getTmgUserAPIHealth() {
		return "Hello CTS: I am good. TmgUser API Service. Total Call Count: " + counter.incrementAndGet();
	}

	@Operation(summary = "Fetch all TMG User Details")
	@GetMapping("/all")
	public ResponseEntity<List<TmgUserDetailsVO>> getAllTmgUsers() throws Exception {
		LOG.info("getAllTmgUsers: Request received");
		List<TmgUserDetailsVO> res = tmgUserDetailsService.findAll();
		LOG.info("getAllTmgUsers: Response value: {}", CBridgeUtile.getJsonObjectString(res));
		return ResponseEntity.ok(res);
	}

	@Operation(summary = "Create TMG User Details")
		@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TmgUserDetailsVO> createTmgUser(@RequestBody TmgUserDetailsVO tmgUserDetailsVO)
			throws Exception {
		LOG.info("createTmgUser: Request payload: {}", CBridgeUtile.getJsonObjectString(tmgUserDetailsVO));

		TmgUserDetailsVO saved = tmgUserDetailsService.create(tmgUserDetailsVO);
		LOG.info("createTmgUser: Response value: {}", CBridgeUtile.getJsonObjectString(saved));
		return ResponseEntity.status(HttpStatus.CREATED).body(saved);
	}

	@Operation(summary = "Update TMG User Details by Associate Id")
		@PutMapping(path = "/associate/{associateId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TmgUserDetailsVO> updateTmgUserByAssociateId(@PathVariable String associateId,
			@RequestBody TmgUserDetailsVO tmgUserDetailsVO) throws Exception {
		LOG.info("updateTmgUserByAssociateId: Request associateId: {}, payload: {}", associateId,
				CBridgeUtile.getJsonObjectString(tmgUserDetailsVO));

		TmgUserDetailsVO updated = tmgUserDetailsService.updateByAssociateId(associateId, tmgUserDetailsVO);
		LOG.info("updateTmgUserByAssociateId: Response value: {}", CBridgeUtile.getJsonObjectString(updated));
		return ResponseEntity.ok(updated);
	}

	@Operation(summary = "Fetch TMG User Details by Associate Id")
		@GetMapping(path = "/associate/{associateId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TmgUserDetailsVO> getTmgUserByAssociateId(@PathVariable String associateId)
			throws CBridgeDataNotFoundException {
		LOG.info("getTmgUserByAssociateId: Request associateId: {}", associateId);
		TmgUserDetailsVO res = tmgUserDetailsService.findByAssociateId(associateId);
		LOG.info("getTmgUserByAssociateId: Response value: {}", CBridgeUtile.getJsonObjectString(res));
		return ResponseEntity.ok(res);
	}

	@Operation(summary = "Delete TMG User Details by Associate Id")
		@DeleteMapping(path = "/associate/{associateId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> deleteTmgUserByAssociateId(@PathVariable String associateId)
			throws CBridgeDataNotFoundException {
		LOG.info("deleteTmgUserByAssociateId: Request associateId: {}", associateId);
		tmgUserDetailsService.deleteByAssociateId(associateId);
		LOG.info("deleteTmgUserByAssociateId: Successfully deleted associateId: {}", associateId);
		return ResponseEntity.ok("TMG user details deleted successfully for associate id: " + associateId);
	}
}
