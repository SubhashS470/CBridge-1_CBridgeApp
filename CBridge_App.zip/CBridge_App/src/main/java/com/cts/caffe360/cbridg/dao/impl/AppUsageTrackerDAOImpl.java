
package com.cts.caffe360.cbridg.dao.impl;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.dao.AppUsageTrackerDAO;
import com.cts.caffe360.cbridg.domain.AppUsageTrackerDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;

@Repository
public class AppUsageTrackerDAOImpl extends CBridgeDAOImpl implements AppUsageTrackerDAO {
	private static final Logger LOG = LoggerFactory.getLogger(AppUsageTrackerDAOImpl.class);

	public void save(AppUsageTrackerDO appUsageTrackerDO) throws CBridgeDBException {
		LOG.info("DB: save() STARTED");
		mongoTemplate.save(appUsageTrackerDO);
		LOG.info("DB: save() END");
	}

	public void update(AppUsageTrackerDO appUsageTracker) throws CBridgeDBException {
		LOG.info("DB: update() STARTED");
		mongoTemplate.save(appUsageTracker);
		LOG.info("DB: update() END");
	}

	public List<AppUsageTrackerDO> findAll() throws CBridgeDBException {
		LOG.info("DB: findAll() STARTED");
		try {
			return mongoTemplate.findAll(AppUsageTrackerDO.class);
		} catch (Exception ex) {
			LOG.error("Exception throw in findAll() method.", ex);
			throw new CBridgeDBException(ex);
		}
	}

	public void insert(AppUsageTrackerDO appUsageTracker) throws CBridgeDBException {
		LOG.info("DB: insert() STARTED");
		mongoTemplate.insert(appUsageTracker);
		LOG.info("DB: insert() END");
	}

	@Override
	public List<AppUsageTrackerDO> findByAppName(List<String> appName) throws CBridgeDBException {
		LOG.info("DB: findByAppName() STARTED");
		Query query = new Query();
		query.addCriteria(where("appName").is(appName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByAppName() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByAppNameFromToDate(List<String> appName, Date from, Date to)
			throws CBridgeDBException {
		LOG.info("DB: findByAppName() STARTED");
		Query query = new Query();
		query.addCriteria(where("appName").in(appName));
		query.addCriteria(where("createdDate").gte(from).lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByAppName() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByModuleName(List<String> moduleName) throws CBridgeDBException {
		LOG.info("DB: findByModuleName() STARTED");
		Query query = new Query();
		query.addCriteria(where("moduleName").in(moduleName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByModuleName() END");
		return appUsageTrackerDO;
	}

	@Override
	public AppUsageTrackerDO findById(String id) throws CBridgeDBException {
		LOG.info("DB: findById() STARTED");
		AppUsageTrackerDO dataDO = null;
		Query query = new Query();
		try {
			query.addCriteria(where("_id").is(id));
			dataDO = mongoTemplate.findOne(query, AppUsageTrackerDO.class);
		} catch (Exception ex) {
			LOG.error("Exception throw in findByKey() method.", ex);
			throw new CBridgeDBException(ex);
		}
//        if (dataDO == null) {
//        	throw new CBridgeDataNotFoundException("Data Not found with query: " + query.toString());
//        }
		LOG.info("DB: findById() End. Queried object id: "
				+ (dataDO != null ? dataDO.get_id() : "Data Not found with query: " + query.toString()));
		return dataDO;
	}

	public List<AppUsageTrackerDO> findByUserIdAndAppName(List<String> userId, List<String> appName)
			throws CBridgeDBException {
		LOG.info("DB: findByUserIdAndAppName() STARTED");
		List<AppUsageTrackerDO> appUsageTrackerDO = null;
		try {
			Query query = new Query();
			query.addCriteria(getCriteriaRegExConditon(userId));
			query.addCriteria(where("appName").in(appName));
			LOG.info("MongoDB Query: {}", query);
			appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		} catch (Exception ex) {
			LOG.error("Exception throw in findByKey() method.", ex);
			throw new CBridgeDBException(ex);
		}
		LOG.info("DB: findByUserIdAndAppName() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserId(List<String> userId) throws CBridgeDBException {
		LOG.info("DB: AppUsageTrackerDO() STARTED");
		List<AppUsageTrackerDO> appUsageTrackerDO = null;
		try {
			Query query = new Query();
			query.addCriteria(getCriteriaRegExConditon(userId));
			LOG.info("MongoDB Query: {}", query);
			appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		} catch (Exception ex) {
			LOG.error("Exception throw in findByKey() method.", ex);
			throw new CBridgeDBException(ex);
		}
		LOG.info("DB: AppUsageTrackerDO() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserIdFromToDate(List<String> userId, Date from, Date to)
			throws CBridgeDBException {
		LOG.info("DB: findByUserIdFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userId));
		query.addCriteria(where("createdDate").gte(from).lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserIdFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserName(List<String> userName) throws CBridgeDBException {
		LOG.info("DB: findByUserName() STARTED");
		Query query = new Query();
//		query.addCriteria(where("userName").regex(userName, "i"));
		query.addCriteria(getCriteriaRegExConditon(userName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserName() END");
		return appUsageTrackerDO;
	}

	private Criteria getCriteriaRegExConditon(List<String> userName) {
		Criteria criteria = new Criteria().orOperator(
				userName.stream().map(uName -> Criteria.where("userName").regex(uName)).toArray(Criteria[]::new));
		return criteria;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserNameFromToDate(List<String> userName, Date from, Date to)
			throws CBridgeDBException {
		LOG.info("DB: findByUserNameFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userName));
		query.addCriteria(where("createdDate").gte(from));
		query.addCriteria(where("createdDate").lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserNameFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByModuleNameFromToDate(List<String> moduleName, Date from, Date to)
			throws CBridgeDBException {
		LOG.info("DB: findByModuleNameFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(where("moduleName").in(moduleName));
		query.addCriteria(where("createdDate").gte(from));
		query.addCriteria(where("createdDate").lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByModuleNameFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByTxnType(List<String> txnType) throws CBridgeDBException {
		LOG.info("DB: findByTxnType() STARTED");
		Query query = new Query();
		query.addCriteria(where("transactionType").in(txnType));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByTxnType() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByTxnTypeFromToDate(List<String> txnType, Date from, Date to)
			throws CBridgeDBException {
		LOG.info("DB: findByTxnTypeFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(where("transactionType").in(txnType));
		query.addCriteria(where("createdDate").gte(from));
		query.addCriteria(where("createdDate").lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByTxnTypeFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByModuleNameAndAppName(List<String> moduleName, List<String> appName)
			throws CBridgeDBException {
		LOG.info("DB: findByModuleNameAndAppName() STARTED");
		Query query = new Query();
		query.addCriteria(where("moduleName").in(moduleName));
		query.addCriteria(where("appName").in(appName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByModuleNameAndAppName() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByModuleNameAndAppNameFromToDate(List<String> moduleName, List<String> appName,
			Date from, Date to) throws CBridgeDBException {
		LOG.info("DB: findByModuleNameAndAppNameFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(where("moduleName").in(moduleName));
		query.addCriteria(where("appName").in(appName));
		query.addCriteria(where("createdDate").gte(from).lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByModuleNameAndAppNameFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleNameAndDateFromToDate(List<String> userId,
			List<String> appName, List<String> moduleName, Date date, Date from, Date to) throws CBridgeDBException {
		LOG.info("DB: findByUserIdAndAppNameAndModuleNameAndDateFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userId));
		query.addCriteria(where("appName").in(appName));
		query.addCriteria(where("moduleName").in(moduleName));
		query.addCriteria(where("createdDate").gte(from));
		query.addCriteria(where("createdDate").lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserIdAndAppNameAndModuleNameAndDateFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleName(List<String> userId, List<String> appName,
			List<String> moduleName) throws CBridgeDBException {
		LOG.info("DB: findByUserIdAndAppNameAndModuleName() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userId));
		query.addCriteria(where("appName").in(appName));
		query.addCriteria(where("moduleName").in(moduleName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserIdAndAppNameAndModuleName() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleNameAndTxnType(List<String> userId,
			List<String> appName, List<String> moduleName, List<String> TxnType) throws CBridgeDBException {
		LOG.info("DB: findByUserIdAndAppNameAndModuleNameAndTxnType() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userId));
		query.addCriteria(where("appName").in(appName));
		query.addCriteria(where("moduleName").in(moduleName));
		query.addCriteria(where("transactionType").in(TxnType));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserIdAndAppNameAndModuleNameAndTxnType() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(List<String> userId,
			List<String> appName, List<String> moduleName, List<String> TxnType, Date from, Date to)
			throws CBridgeDBException {
		LOG.info("DB: findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userId));
		query.addCriteria(where("appName").gte(appName));
		query.addCriteria(where("moduleName").is(moduleName));
		query.addCriteria(where("transactionType").lte(TxnType));
		query.addCriteria(where("createdDate").gte(from));
		query.addCriteria(where("createdDate").lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByFromToDate(Date from, Date to) throws CBridgeDBException {
		LOG.info("DB: findByFromToDate() STARTED");
		Query query = new Query();
		query.addCriteria(where("createdDate").gte(from).lte(to));
		System.out.println("query..:" + query.toString());
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByFromToDate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByTower(List<String> towerName) throws CBridgeDBException {
		LOG.info("DB: findByTower() STARTED");
		Query query = new Query();
		query.addCriteria(where("towerName").in(towerName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByTower() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByTowerNameAndFromAndTodate(List<String> towerName, Date from, Date to) {
		LOG.info("DB: findByTowerNameAndFromAndTodate() STARTED");
		Query query = new Query();
		query.addCriteria(where("towerName").in(towerName));
		query.addCriteria(where("createdDate").gte(from).lte(to));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByTowerNameAndFromAndTodate() END");
		return appUsageTrackerDO;
	}

	public List<AppUsageTrackerDO> findByUserIdAndTowerName(List<String> userId, List<String> towerName) {
		LOG.info("DB: findByUserIdAndTowerName() STARTED");
		Query query = new Query();
		query.addCriteria(getCriteriaRegExConditon(userId));
		query.addCriteria(where("towerName").in(towerName));
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByTowerNameAndFromAndTodate() END");
		return appUsageTrackerDO;
	}

	@Override
	public List<AppUsageTrackerDO> findByAllFetch(List<String> towerName, List<String> userId, Date from, Date to,
			List<String> appName, List<String> moduleName, List<String> TxnType) {
		LOG.info("DAO: findByAllFetch() STARTED");
		Query query = new Query();
		if (!towerName.isEmpty()) {
			query.addCriteria(where("towerName").in(towerName));
		}
		if (!userId.isEmpty()) {
			query.addCriteria(getCriteriaRegExConditon(userId));
		}
		if (StringUtils.isNotBlank(from.clone().toString()) && StringUtils.isNotBlank(to.clone().toString())) {
			query.addCriteria(where("createdDate").gte(from).lte(to));
		}
		if (!appName.isEmpty()) {
			query.addCriteria(where("appName").in(appName));
		}
		if (!moduleName.isEmpty()) {
			query.addCriteria(where("moduleName").in(moduleName));
		}
		if (!TxnType.isEmpty()) {
			query.addCriteria(where("transactionType").in(TxnType));
		}
		LOG.info("Query String: {}", query);
		List<AppUsageTrackerDO> appUsageTrackerDO = mongoTemplate.find(query, AppUsageTrackerDO.class);
		LOG.info("DB: findByAllFetch() END");
		return appUsageTrackerDO;
	}

}
