package com.cts.caffe360.cbridg.configuration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.cts.caffe360.cbridg.constants.CBridgeConstant;

@Configuration
public class MongoDBSrtatStopService {
	private static final Logger LOG = LoggerFactory.getLogger(MongoDBSrtatStopService.class);

	/*
	 * @Autowired private CBridgeAppMongoDBConfiguration mongoDBConfiguration;
	 */
	
   private static final String START_BAT_FILE_PATH = resolveStartBatFilePath();

   private static String resolveStartBatFilePath() {
       String appPath = CBridgeConstant.APP_PATH;
       int idx = appPath.lastIndexOf("CBridge_App");
       if (idx >= 0) {
           return appPath.substring(0, idx) + "mongoDB_Start.bat";
       }
       // fallback: look for the bat file relative to the jar location
       return appPath + java.io.File.separator + "mongoDB_Start.bat";
   }
    
   public static void ensureMongoDBIsRunning(String mongoHost, String mongoPort) {
        if (!isMongoDBRunning(mongoHost, mongoPort)) {
            startMongoDB();
        }
    }
    
    public static boolean isMongoDBRunning(String mongoHost, String mongoPort) {
        try (Socket socket = new Socket(mongoHost, Integer.valueOf(mongoPort))) {
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void startMongoDB() {
        try {
			/*
			 * C:\Pandiyan\Workspace\Development_Branch\CBridge_Appication>mongoDB_Start.bat
			 * C:\Pandiyan\Workspace\Development_Branch\CBridge_Appication\CBridge_App
			 */
        	String batFilePath = "cmd /c start " + START_BAT_FILE_PATH.replace("\\", "/");
//            ProcessBuilder processBuilder = new ProcessBuilder(batFilePath);
//            processBuilder.redirectErrorStream(true);
            Process process = Runtime.getRuntime().exec(batFilePath);//processBuilder.start();
//            int exitCode = process.waitFor();
//            if (exitCode == 0) {
            if (process.isAlive()) {
                LOG.info("MongoDB started successfully.");
            } else {
//                LOG.error("Failed to start MongoDB. Exit code: " + exitCode + " Please start MongoDB manually.");
                throw new RuntimeException("Failed to start MongoDB. Exit code: " + process.exitValue() + "Error Message: "+ process.getErrorStream() +" . Please start MongoDB manually.");
            }
        } catch (Exception e) {
//            LOG.error("Exception while starting MongoDB using batch file.", e);
            throw new RuntimeException("Exception while starting MongoDB using batch file.", e);
        }
    }

    public static void stopMongoDB() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("cmd", "/c", "taskkill /F /IM mongod.exe");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    LOG.info(line);
                }
            }
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                LOG.info("MongoDB stopped successfully.");
            } else {
                LOG.error("Failed to stop MongoDB. Exit code: " + exitCode);
            }
        } catch (Exception e) {
            LOG.error("Exception while stopping MongoDB using taskkill command.", e);
        }
    }

}
