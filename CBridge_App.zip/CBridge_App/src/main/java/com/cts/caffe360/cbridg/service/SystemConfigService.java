package com.cts.caffe360.cbridg.service;

import java.util.List;
import java.util.Map;

import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.vo.SystemConfigVO;

public interface SystemConfigService {
	List<SystemConfigVO> findAll() throws Exception;
	Map<Long, String> findTypeMapByParamType(String sysParamType) throws CBridgeDataNotFoundException;
	SystemConfigVO findBySysConfigId(Integer sysConfigId) throws CBridgeDataNotFoundException;
	SystemConfigVO create(SystemConfigVO systemConfigVO) throws Exception;
	SystemConfigVO updateBySysConfigId(Integer sysConfigId, SystemConfigVO systemConfigVO) throws Exception;
	void deleteBySysConfigId(Integer sysConfigId) throws CBridgeDataNotFoundException;
}