package com.cts.caffe360.cbridg.vo;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import com.cts.caffe360.cbridg.constants.CBridgeConstant;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CBridgeKeyValuesVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("value")
    private String value;

    @JsonProperty("description")
    private String description;

    @JsonProperty("updated_date")
    private Date updatedDate;

    @JsonProperty("expiry_date")
    private Date expiryDate; //default 90days from last updated date
    
    /**
     * use for save/update/remove allowed function 
     */
    @JsonProperty("operation")
    private String operation = CBridgeConstant.ADD_OPERATION; //default value ADD (Add/Update are value)

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getUpdatedDate() {
        if (updatedDate == null){
            setUpdatedDate(new Date());
        }
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
        setExpiryDate(DateUtils.addMonths(this.updatedDate,3));
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public String toString() {
        return "CBridgeKeyValuesVO{" +
                "value='" + value + '\'' +
                ", description='" + description + '\'' +
                ", updatedDate=" + updatedDate +
                ", expiryDate=" + expiryDate +
                ", operation=" + operation +
                '}';
    }

	public String getOperation() {
		if (StringUtils.isBlank(operation)) {
			operation = CBridgeConstant.ADD_OPERATION;
		}
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}
}
