package com.cts.caffe360.cbridg.resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.caffe360.cbridg.service.ActiveBatchJobService;
import com.cts.caffe360.cbridg.utiles.CBridgeUtile;
import com.cts.caffe360.cbridg.vo.ActiveBatchJobVO;
import com.cts.caffe360.cbridg.vo.AppUsageTrackerVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping(value = "/cbridge/api/abjob/v1")
@Tag(name = "CBridge API Active batch job services")
public class CBridgeABatchJobAPI {
	
	private static final Logger LOG = LoggerFactory.getLogger(CBridgeABatchJobAPI.class);
	@Autowired
	ActiveBatchJobService service;

	@Operation(summary = "Fetch the Application Uasge Traker Service details by Id")
    @GetMapping("/abjobid/{abjobid}/type/{type}")
    public ActiveBatchJobVO  triggerActiveBatchJob(@PathVariable String abjobid,@PathVariable String type) throws Exception {
		ActiveBatchJobVO dataVO = null;
    	LOG.info("getIdValue: Request id: " + abjobid);
    	dataVO = service.triggerABJob(abjobid,type);
    	LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(dataVO));
        return dataVO;
    }
	@GetMapping("/abjobid/{abjobid}")
    public String  getStatus(@PathVariable String abjobid) throws Exception {
		String status="";
    	LOG.info("getStatusValue: Request id: " + abjobid);
    	status = service.getABJobStatus(abjobid);
    	LOG.info("getStatusValue: Response value: " + status);
        return status;
    }
	
}

