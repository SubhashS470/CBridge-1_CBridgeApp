package com.cts.caffe360.app;

import jakarta.annotation.PreDestroy;

import com.cts.caffe360.cbridg.configuration.MongoDBSrtatStopService;

//@Component
public class AppShutdownRunner {

    @PreDestroy
    public void onShutdown() {
    	MongoDBSrtatStopService.stopMongoDB();
    }
}
