package com.cts.caffe360.cbridg.exception.handler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class CBridgeResourceNotFoundException extends Exception{
    private static final long serialVersionUID = 1L;


    public CBridgeResourceNotFoundException(String message){
        super(message);
    }

    public CBridgeResourceNotFoundException(Exception ex){
        super(ex);
    }
}
