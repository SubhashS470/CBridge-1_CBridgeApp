package com.cts.caffe360.cbridg.dao;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.domain.AppUsageTrackerDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;

@Repository
public interface AppUsageTrackerDAO extends CBridgeDAO {
	void save(AppUsageTrackerDO dos) throws CBridgeDBException;
	
	void update(AppUsageTrackerDO dos) throws CBridgeDBException;
	
	List<AppUsageTrackerDO> findAll() throws CBridgeDBException;

	void insert(AppUsageTrackerDO dos) throws CBridgeDBException;
	
	/**
	 * Find by userId or list of userId
	 * @param userId
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByUserId(List<String> userId) throws CBridgeDBException;

	/**
	 * Find by userId or list of userId and from date and to date
	 * 
	 * @param userId
	 * @param from
	 * @param to
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByUserIdFromToDate(List<String> userId, Date from, Date to) throws CBridgeDBException;
	
	/**
	 * Find by userName or list of userName
	 * 
	 * @param userName
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByUserName(List<String> userName) throws CBridgeDBException;

	/**
	 * Find by userName or list of userName and from date and to date
	 * 
	 * @param userName
	 * @param from
	 * @param to
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByUserNameFromToDate(List<String> userName, Date from, Date to) throws CBridgeDBException;
	
	/**
	 * Find by appName or list of appName
	 * 
	 * @param appName
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByAppName(List<String> appName) throws CBridgeDBException;

	/**
	 * Find by appName or list of appName and from date and to date
	 * 
	 * @param appName
	 * @param from
	 * @param to
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByAppNameFromToDate(List<String> appName, Date from, Date to) throws CBridgeDBException;
	
	/**
	 * Find by moduleName or list of moduleName
	 * 
	 * @param moduleName
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByModuleName(List<String> moduleName) throws CBridgeDBException;

	/**
	 * Find by moduleName or list of moduleName and from date and to date
	 * 
	 * @param moduleName
	 * @param from
	 * @param to
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByModuleNameFromToDate(List<String> moduleName, Date from, Date to) throws CBridgeDBException;
	
	/**
	 * Find by txnType or list of txnType
	 * 
	 * @param TxnType
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByTxnType(List<String> TxnType) throws CBridgeDBException;

	/**
	 * Find by txnType or list of txnType and from date and to date
	 * 
	 * @param TxnType
	 * @param from
	 * @param to
	 * @return
	 * @throws CBridgeDBException
	 */
	List<AppUsageTrackerDO> findByTxnTypeFromToDate(List<String> TxnType, Date from, Date to) throws CBridgeDBException;
	
	/**
	 * Find by Module Name and App Name or list of Module Name and App Name
	 * @param moduleName
	 * @param appName
	 * @return
	 * @throws CBridgeDBException
	 */
    List<AppUsageTrackerDO> findByModuleNameAndAppName(List<String> moduleName, List<String> appName) throws CBridgeDBException;
    /**
     * Find by Module Name and App Name or list of Module Name and App Name and from date and to date
     * @param moduleName
     * @param appName
     * @param from
     * @param to
     * @return
     * @throws CBridgeDBException
     */
    List<AppUsageTrackerDO> findByModuleNameAndAppNameFromToDate(List<String> moduleName, List<String> appName, Date from, Date to) throws CBridgeDBException;
    /**
     * Find by Module Name and App Name and User Id or list of Module Name and App Name and User Id
     * @param moduleName
     * @param appName
     * @param userId
     * @return list of AppUsageTrackerDO
     * @throws CBridgeDBException
     * 
     */
    List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleNameAndDateFromToDate(List<String> userId, List<String> appName, List<String> moduleName, Date date, Date from, Date to) throws CBridgeDBException;
    /**
     * Find by User Id and App Name and Module Name or list of User Id and App Name and Module Name
     * @param userId
     * @param appName
     * @param moduleName
     * @return
     * @throws CBridgeDBException
     */
    List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleName(List<String> userId, List<String> appName, List<String> moduleName) throws CBridgeDBException;

	/**
	 * Find by User Id and App Name and Module Name or list of User Id and App Name
	 * and Module Name and from date and to date
	 * 
	 * @param userId
	 * @param appName
	 * @param moduleName
	 * @param from
	 * @param to
	 * @return
	 * @throws CBridgeDBException
	 */
    List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleNameAndTxnType(List<String> userId, List<String> appName, List<String> moduleName, List<String> TxnType) throws CBridgeDBException;
    /**
     * Find by User Id and App Name and Module Name and Txn Type or list of User Id and App Name
     * @param userId
     * @param appName
     * @param moduleName
     * @param TxnType
     * @param from
     * @param to
     * @return
     * @throws CBridgeDBException
     */
    List<AppUsageTrackerDO> findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(List<String> userId, List<String> appName, List<String> moduleName, List<String> TxnType, Date from, Date to) throws CBridgeDBException;
	
    /**
     * find application usage tracker by object id
     * @param id
     * @return
     * @throws CBridgeDBException
     */
    AppUsageTrackerDO findById(String id) throws CBridgeDBException;
    
    List<AppUsageTrackerDO> findByUserIdAndAppName(List<String> userId, List<String> appName)throws CBridgeDBException;
	
    List<AppUsageTrackerDO> findByFromToDate(Date from, Date to) throws CBridgeDBException;
    List<AppUsageTrackerDO> findByTower(List<String>  towerName) throws CBridgeDBException;

	List<AppUsageTrackerDO> findByTowerNameAndFromAndTodate(List<String> towerName, Date from, Date to);
	
	List<AppUsageTrackerDO> findByUserIdAndTowerName(List<String> userId, List<String> towerName)throws CBridgeDBException;
	
	List<AppUsageTrackerDO> findByAllFetch(List<String> towerName, List<String> userId, Date from, Date to,
			List<String> appName, List<String> moduleName, List<String> TxnType)throws CBridgeDBException;
}
