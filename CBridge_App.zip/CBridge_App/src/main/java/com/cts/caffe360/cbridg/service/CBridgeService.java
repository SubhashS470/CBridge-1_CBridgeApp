package com.cts.caffe360.cbridg.service;

import java.time.LocalDate;
import java.util.List;

import com.cts.caffe360.cbridg.vo.CBridgeTestDataVO;

public interface CBridgeService {
	CBridgeTestDataVO findById(String id) throws Exception;

    List<CBridgeTestDataVO> findByKey(String key) throws Exception;
    
    List<CBridgeTestDataVO> findByValue(String value) throws Exception;

    List<CBridgeTestDataVO> fetchAllCBridgeDocument() throws Exception;

    CBridgeTestDataVO findByIdAndKey(String Id, String value) throws Exception;

    List<CBridgeTestDataVO> findByKeyAndValue(String key, String value) throws Exception;

    List<CBridgeTestDataVO> findByKeyAndValue(String key, String value, String module, LocalDate updateDate) throws Exception;

    void deleteKeyValue(String key, String module, String value) throws Exception;

    void deleteKeyValueAll(String key, String module) throws Exception;

    void deleteKeyValueExpiryDate(String key, String module) throws Exception;

    CBridgeTestDataVO save(CBridgeTestDataVO cBridgeTestDataVo) throws Exception;

    CBridgeTestDataVO update(CBridgeTestDataVO cBridgeTestDataVo) throws Exception;
    
    CBridgeTestDataVO findByKeyModuleUser(String key, String module, String user) throws Exception;
}
