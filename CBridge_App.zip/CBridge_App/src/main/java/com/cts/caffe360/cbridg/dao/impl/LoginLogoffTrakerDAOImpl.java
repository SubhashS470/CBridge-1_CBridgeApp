
package com.cts.caffe360.cbridg.dao.impl;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.dao.LoginLogoffTrakerDAO;
import com.cts.caffe360.cbridg.domain.LoginLogoffTrakerDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;

@Repository
public class LoginLogoffTrakerDAOImpl extends CBridgeDAOImpl implements LoginLogoffTrakerDAO {
	 private static final Logger LOG = LoggerFactory.getLogger(LoginLogoffTrakerDAOImpl.class);

    public void save(LoginLogoffTrakerDO dos) throws CBridgeDBException{
		LOG.info("DB: save() STARTED");
		mongoTemplate.save(dos);
		LOG.info("DB: save() END");
	}
	
	public void update(LoginLogoffTrakerDO dos) throws CBridgeDBException{
		LOG.info("DB: update() STARTED");
		mongoTemplate.save(dos);
		LOG.info("DB: update() END");
	}
	
	public List<LoginLogoffTrakerDO> findAll() throws CBridgeDBException {
        LOG.info("DB: findAll() STARTED");
        try {
            return mongoTemplate.findAll(LoginLogoffTrakerDO.class);
        } catch (Exception ex){
            LOG.error("Exception throw in findAll() method.", ex);
            throw new CBridgeDBException(ex);
        }
	}

	public void insert(LoginLogoffTrakerDO logDo) throws CBridgeDBException {
		LOG.info("DB: insert() STARTED");
		mongoTemplate.insert(logDo);
		LOG.info("DB: insert() END");
	}

	@Override
	public List<LoginLogoffTrakerDO> findByAppName(String appName) throws CBridgeDBException {
		LOG.info("DB: findByAppName() STARTED");
		Query query = new Query();
		query.addCriteria(where("appName").is(appName));
		List<LoginLogoffTrakerDO> doLst = mongoTemplate.find(query, LoginLogoffTrakerDO.class);
		LOG.info("DB: findByAppName() END");
		return doLst;
	}

	@Override
	public List<LoginLogoffTrakerDO> findByModuleName(String moduleName) throws CBridgeDBException {
		LOG.info("DB: findByModuleName() STARTED");
        Query query = new Query();
        query.addCriteria(where("moduleName").is(moduleName));
        List<LoginLogoffTrakerDO> doLst = mongoTemplate.find(query, LoginLogoffTrakerDO.class);
        LOG.info("DB: findByModuleName() END");
        return doLst;
	}

	@Override
	public LoginLogoffTrakerDO findById(String id) throws CBridgeDBException {
        LOG.info("DB: findById() STARTED");
        LoginLogoffTrakerDO dataDO = null;
        Query query = new Query();
        try {
            query.addCriteria(where("_id").is(id));
            dataDO = mongoTemplate.findOne(query, LoginLogoffTrakerDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKey() method.", ex);
            throw new CBridgeDBException(ex);
        }
//        if (dataDO == null) {
//        	throw new CBridgeDataNotFoundException("Data Not found with query: " + query.toString());
//        }
        LOG.info("DB: findById() End. Queried object id: " + (dataDO != null ? dataDO.getId() : "Data Not found with query: " + query.toString()));
        return dataDO;
	}

	public List<LoginLogoffTrakerDO> findByUserIdAndAppName(String userId, String appName) throws CBridgeDBException {
		LOG.info("DB: findByUserIdAndAppName() STARTED");
		List<LoginLogoffTrakerDO> doLst = null;
		try {
			Query query = new Query();
			query.addCriteria(where("userId").is(userId));
			query.addCriteria(where("appName").is(appName));
			LOG.info("MongoDB Query: {}",query);
			doLst = mongoTemplate.find(query, LoginLogoffTrakerDO.class);
		} catch(Exception ex){
            LOG.error("Exception throw in findByKey() method.", ex);
            throw new CBridgeDBException(ex);
        }
		LOG.info("DB: findByUserIdAndAppName() END");
		return doLst;
	}
	
}
