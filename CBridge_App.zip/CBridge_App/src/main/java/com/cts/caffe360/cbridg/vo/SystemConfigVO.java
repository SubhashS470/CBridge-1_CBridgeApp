package com.cts.caffe360.cbridg.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemConfigVO {

	@JsonProperty("Sys_Config_Id")
	private Integer sysConfigId;

	@JsonProperty("Sys_Param_Type")
	private String sysParamType;

	@JsonProperty("Type_Id")
	private Long typeId;

	@JsonProperty("Type_Value")
	private String typeValue;

	public Integer getSysConfigId() { return sysConfigId; }
	public void setSysConfigId(Integer sysConfigId) { this.sysConfigId = sysConfigId; }
	public String getSysParamType() { return sysParamType; }
	public void setSysParamType(String sysParamType) { this.sysParamType = sysParamType; }
	public Long getTypeId() { return typeId; }
	public void setTypeId(Long typeId) { this.typeId = typeId; }
	public String getTypeValue() { return typeValue; }
	public void setTypeValue(String typeValue) { this.typeValue = typeValue; }
}