package com.cts.caffe360.cbridg.resource;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.caffe360.cbridg.service.LoginLogoffTrakerService;
import com.cts.caffe360.cbridg.utiles.CBridgeUtile;
import com.cts.caffe360.cbridg.vo.LoginLogoffTrakerVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping(value = "/cbridge/api/log/v1")
@Tag(name = "CBridge API - Logger Service")
public class LoginLogoffTrakerAPI {
	
	private static final Logger LOG = LoggerFactory.getLogger(LoginLogoffTrakerAPI.class);

    @Autowired
    LoginLogoffTrakerService service;
    
    private final AtomicLong counter = new AtomicLong();
    
	@Operation(summary = "Verify the CBridge API for the Application Uasge Traker Service Status")
    @GetMapping("/healthCheck_llt")
    public String getLoginLogoffTrakerAPI(){
        return "Hello CTS: I am good. LoginLogoffTrakerAPI API Application Uasge Traker. Total Call Count: " + counter.incrementAndGet();
    }

	@Operation(summary = "Fetch all the Application Uasge Traker details")
    @GetMapping("/user/{userId}/application/{appName}")
    public List<LoginLogoffTrakerVO> getTrackerByUserAndApp(@PathVariable String userId, @PathVariable String appName) throws Exception {
    	List<LoginLogoffTrakerVO> res = null;
    	LOG.info("getIdValue: Request id: " + userId);
    	res = service.findByUserIdAndAppName(userId, appName);
    	LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(res));
    	return res;
    }

    @Operation(summary = "Save/Update the Application Uasge Traker details")
    @PostMapping(path="/update", name="updateTestData", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public LoginLogoffTrakerVO update(@RequestBody (required = false) LoginLogoffTrakerVO vo, Model model) throws Exception {
        LOG.info("Request Object value: " + CBridgeUtile.getJsonObjectString(vo));
        service.update(vo);
        LOG.info("Response Object value: " + CBridgeUtile.getJsonObjectString(vo));
        return vo;
    }

    @Operation(summary = "Fetch all the Application Uasge Traker details")
    @GetMapping("/all")
    public List<LoginLogoffTrakerVO> getAllKeyValue() throws Exception {
        return service.findAll();
    }

}

