package com.cts.caffe360.cbridg.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class CBridgeAppSwaggerConfiguration {

    @Bean
    @Primary
    public OpenAPI cbridgeOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("CBridge REST API")
                        .description("CAFFe360 Framework's C-Bridge REST API")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("CAFFe360 Auto Team")
                                .url("https://qahub.cognizant.com/v2/#/testAutomationDetail")
                                .email("COGTMGOffshoreQA@cognizant.com")));
    }
}
