package com.cts.caffe360.cbridg.dao.impl;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.dao.ReactiveCBridgeDAO;
import com.cts.caffe360.cbridg.domain.CBridgeTestDataDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;
import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.mongodb.client.result.UpdateResult;

@Repository
public class ReactiveCBridgeDAOImpl extends CBridgeDAOImpl implements ReactiveCBridgeDAO {
    private static final Logger LOG = LoggerFactory.getLogger(ReactiveCBridgeDAOImpl.class);

    @Override
    public CBridgeTestDataDO findById(String id) throws CBridgeDBException{
        LOG.info("DB: findById() STARTED");
        CBridgeTestDataDO dataDO = null;
        Query query = new Query();
        try {
            query.addCriteria(where("_id").is(Long.valueOf(id)));
            dataDO = mongoTemplate.findOne(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKey() method.", ex);
            throw new CBridgeDBException(ex);
        }
        if (dataDO == null) {
        	throw new CBridgeDataNotFoundException("Data Not found with query: " + query.toString());
        }
        LOG.info("DB: findById() End. Queried object id: " + dataDO.get_id());
        return dataDO;
    }

    @Override
    public List<CBridgeTestDataDO> findAll() throws CBridgeDBException{
        LOG.info("DB: findAll() STARTED");
        try {
            return mongoTemplate.findAll(CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findAll() method.", ex);
            throw new CBridgeDBException(ex);
        }
    }

    @Override
    public List<CBridgeTestDataDO> findByKey(String key) throws CBridgeDBException{
        LOG.info("DB: findByKey() STARTED");
        try {
            Query query = new Query();
            query.addCriteria(where("key").is(key));
            return mongoTemplate.find(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKey() method.", ex);
            throw new CBridgeDBException(ex);
        }
    }

    @Override
    public CBridgeTestDataDO findByIdAndKey(String id, String key) throws Exception{
        LOG.info("DB: findByKeyAndValue() STARTED");
        CBridgeTestDataDO dataDO = null;
        Query query = null;
        try {
            query = new Query();
            query.addCriteria(where("_id").is(Long.valueOf(id)));
            query.addCriteria(where("key").is(key));
            dataDO = mongoTemplate.findOne(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKeyAndValue() method.", ex);
            throw new CBridgeDBException(ex);
        }
        LOG.info("DB: findById() End. Queried object id: " + dataDO.get_id());
        return dataDO;
    }
    @Override
    public List<CBridgeTestDataDO> findByKeyAndValue(String key, String value) throws CBridgeDBException{
        LOG.info("DB: findByKeyAndValue() STARTED");
        try {
            Query query = new Query();
            query.addCriteria(where("key").is(key));
            //query.addCriteria(where("values.value").is(value));
            return mongoTemplate.find(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKeyAndValue() method.", ex);
            throw new CBridgeDBException(ex);
        }

    }

    @Override
    public List<CBridgeTestDataDO> findByKeyAndValue(String key, String value, String module) throws CBridgeDBException{
        LOG.info("DB: findByKeyAndValue() STARTED");
        try {
        	Query query = new Query();
            query.addCriteria(where("key").is(key));
            query.addCriteria(where("module").is(module));
            //query.addCriteria(where("values.value").is(value));
            return mongoTemplate.find(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKeyAndValue() method.", ex);
            throw new CBridgeDBException(ex);
        }
    }

    @Override
    public void deleteKeyValue(String key, String module, String value) throws CBridgeDBException{

    }

    @Override
    public void deleteKeyValueAll(String key, String module) throws CBridgeDBException{

    }

    @Override
    public void deleteKeyValueExpiryDate(String key, String module) throws CBridgeDBException {

    }

    @Override
    public CBridgeTestDataDO save(CBridgeTestDataDO dataDO) throws CBridgeDBException {
        LOG.info("DB: save() STARTED");
        try {
            return mongoTemplate.save(dataDO);
        } catch(Exception ex){
            LOG.error("Exception throw in save() method.", ex);
            throw new CBridgeDBException(ex);
        }
    }

    @Override
    public CBridgeTestDataDO update(CBridgeTestDataDO dataDO) throws CBridgeDBException{
        LOG.info("DB: update() STARTED");
        try {
            Query query = new Query();
            query.addCriteria(where("_id").is(dataDO.get_id()));
            query.addCriteria(where("key").is(dataDO.getKey()));
            query.addCriteria(where("createdUser").is(dataDO.getCreatedUser()));
            query.addCriteria(where("moduleName").is(dataDO.getModuleName()));
            Update update = new Update();
//            update.set("key", dataDO.getKey());
//            update.set("createdUser", dataDO.getCreatedUser());
//            update.set("moduleName", dataDO.getModuleName());
            update.set("keyValues", dataDO.getKeyValues());
            UpdateResult updateResult = mongoTemplate.updateMulti(query, update, CBridgeTestDataDO.class);
            LOG.info("Updated count" + updateResult.getMatchedCount());
        } catch(Exception ex){
            LOG.error("Exception throw in update() method.", ex);
            throw new CBridgeDBException(ex);
        }
        return dataDO;
    }

    @Override
    public void deleteById(String key) throws CBridgeDBException{
        LOG.info("DB: deleteById() STARTED");
        try {
            Query query = new Query();
            query.addCriteria(where("key").is(key));
            mongoTemplate.remove(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in deleteById() method.", ex);
            throw new CBridgeDBException(ex);
        }
    }

	@Override
	public CBridgeTestDataDO findByKeyModuleUser(String key, String module, String user) throws Exception {
		LOG.info("DB: findByKeyAndValue() STARTED");
        try {
        	Query query = new Query();
            query.addCriteria(where("key").is(key));
            query.addCriteria(where("moduleName").is(module));
            query.addCriteria(where("createdUser").is(user));
            return (CBridgeTestDataDO) mongoTemplate.findOne(query, CBridgeTestDataDO.class);
        } catch(Exception ex){
            LOG.error("Exception throw in findByKeyAndValue() method.", ex);
            throw new CBridgeDBException(ex);
        }
	}
	
}
