package com.cts.caffe360.cbridg.resource;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.service.SystemConfigService;
import com.cts.caffe360.cbridg.utiles.CBridgeUtile;
import com.cts.caffe360.cbridg.vo.SystemConfigVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping(value = "/cbridge/api/sysconfig/v1")
@Tag(name = "CBridge API - System Configuration Service")
public class CBridgeSystemConfigAPI {

	private static final Logger LOG = LoggerFactory.getLogger(CBridgeSystemConfigAPI.class);

	@Autowired
	private SystemConfigService systemConfigService;

	private final AtomicLong counter = new AtomicLong();

	@Operation(summary = "Verify the CBridge API for the System Configuration Service Status")
	@GetMapping("/healthCheck_sysconfig")
	public String getSystemConfigAPI() {
		return "Hello CTS:  I am good. SystemConfigAPI API System Configuration Service. Total Call Count: "
				+ counter.incrementAndGet();
	}

	@Operation(summary = "Fetch all the System Configuration details")
	@GetMapping("/all")
	public ResponseEntity<List<SystemConfigVO>> getAllSystemConfig() throws Exception {
		LOG.info("getAllSystemConfig:  Request received");
		List<SystemConfigVO> res = systemConfigService.findAll();
		LOG.info("getAllSystemConfig:  Response value: " + CBridgeUtile.getJsonObjectString(res));
		return ResponseEntity.ok(res);
	}

	@Operation(summary = "Create System Configuration")
		@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SystemConfigVO> createSystemConfig(@RequestBody SystemConfigVO systemConfigVO)
			throws Exception {
		LOG.info("createSystemConfig: Request payload: {}", CBridgeUtile.getJsonObjectString(systemConfigVO));
		SystemConfigVO saved = systemConfigService.create(systemConfigVO);
		LOG.info("createSystemConfig: Response value: {}", CBridgeUtile.getJsonObjectString(saved));
		return ResponseEntity.status(HttpStatus.CREATED).body(saved);
	}

	@Operation(summary = "Update System Configuration by System_Config_Id")
		@PutMapping(path = "/config/{sysConfigId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SystemConfigVO> updateSystemConfigById(@PathVariable Integer sysConfigId,
			@RequestBody SystemConfigVO systemConfigVO) throws Exception {
		LOG.info("updateSystemConfigById: Request sysConfigId: {}, payload: {}", sysConfigId,
				CBridgeUtile.getJsonObjectString(systemConfigVO));

		SystemConfigVO updated = systemConfigService.updateBySysConfigId(sysConfigId, systemConfigVO);
		LOG.info("updateSystemConfigById: Response value: {}", CBridgeUtile.getJsonObjectString(updated));
		return ResponseEntity.ok(updated);
	}

	@Operation(summary = "Fetch Type Id and Type Value as Map based on Sys Param Type (tower/project)")
		@GetMapping(path = "/param/{sysParamType}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<Long, String>> getTypeMapByParamType(@PathVariable String sysParamType) 
			throws CBridgeDataNotFoundException {
		LOG.info("getTypeMapByParamType: Request sysParamType:  {}", sysParamType);
		Map<Long, String> res = systemConfigService.findTypeMapByParamType(sysParamType);
		LOG.info("getTypeMapByParamType:  Response value: {}", CBridgeUtile.getJsonObjectString(res));
		return ResponseEntity.ok(res);
	}

	@Operation(summary = "Fetch System Configuration by System_Config_Id")
		@GetMapping(path = "/config/{sysConfigId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SystemConfigVO> getSystemConfigById(@PathVariable Integer sysConfigId) 
			throws CBridgeDataNotFoundException {
		LOG.info("getSystemConfigById: Request sysConfigId: {}", sysConfigId);
		SystemConfigVO res = systemConfigService.findBySysConfigId(sysConfigId);
		LOG.info("getSystemConfigById: Response value:  {}", CBridgeUtile.getJsonObjectString(res));
		return ResponseEntity.ok(res);
	}

	@Operation(summary = "Delete System Configuration by System_Config_Id")
		@DeleteMapping(path = "/config/{sysConfigId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> deleteSystemConfigById(@PathVariable Integer sysConfigId) 
			throws CBridgeDataNotFoundException {
		LOG.info("deleteSystemConfigById: Request sysConfigId: {}", sysConfigId);
		systemConfigService.deleteBySysConfigId(sysConfigId);
		LOG.info("deleteSystemConfigById: Successfully deleted sysConfigId: {}", sysConfigId);
		return ResponseEntity.ok("System configuration deleted successfully for System_Config_Id: " + sysConfigId);
	}

}
