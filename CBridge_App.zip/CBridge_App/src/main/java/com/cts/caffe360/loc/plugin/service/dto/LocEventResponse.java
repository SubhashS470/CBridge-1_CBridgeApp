package com.cts.caffe360.loc.plugin.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

/**
 * LocEventResponse — outbound DTO returned by the REST API.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LocEventResponse {

    private String  id;
    private String  developerId;
    private String  developerName;
    private String  projectId;
    private String  sprintId;
    private String  filePath;
    private String  fileName;
    private String  className;
    private String  ideType;
    private String  genAiTool;
    private String  developmentMode;
    private int     linesAdded;
    private int     linesModified;
    private int     linesDeleted;
    private boolean genAiGenerated;
    private Double  genAiConfidenceScore;
    private String  eventTimestamp;
    private String  sessionId;
    /** Per-file LOC breakdown — one entry per file changed in this "Keep All" action. */
    private List<FileChangeDto> fileChanges;
    private Instant createdAt;
    private Instant updatedAt;
}

