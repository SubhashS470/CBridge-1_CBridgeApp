package com.cts.caffe360.cbridg.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CBridge_DBSequence")
public class CBridgeDBSequence {
    @Id
    private String id;
    private long seq;

    public String getId() {
        return id;
    }

    public CBridgeDBSequence setId(String id) {
        this.id = id;
        return this;
    }

    public long getSeq() {
        return seq;
    }

    public CBridgeDBSequence setSeq(long seq) {
        this.seq = seq;
        return this;
    }
}
