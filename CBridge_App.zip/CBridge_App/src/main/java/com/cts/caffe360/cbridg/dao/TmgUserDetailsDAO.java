package com.cts.caffe360.cbridg.dao;

import java.util.List;

import com.cts.caffe360.cbridg.domain.TmgUserDetailsDO;

public interface TmgUserDetailsDAO {
	List<TmgUserDetailsDO> findAll();
	TmgUserDetailsDO findByAssociateId(String associateId);
	TmgUserDetailsDO save(TmgUserDetailsDO tmgUserDetailsDO);
	void deleteByAssociateId(String associateId);
}