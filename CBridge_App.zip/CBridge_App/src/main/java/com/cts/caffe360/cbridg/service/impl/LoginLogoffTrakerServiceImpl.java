package com.cts.caffe360.cbridg.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.constants.CBridgeConstant;
import com.cts.caffe360.cbridg.dao.impl.LoginLogoffTrakerDAOImpl;
import com.cts.caffe360.cbridg.domain.LoginLogoffTrakerDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;
import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.exception.CBridgeServiceException;
import com.cts.caffe360.cbridg.service.LoginLogoffTrakerService;
import com.cts.caffe360.cbridg.vo.LoginLogoffTrakerVO;

@Service
public class LoginLogoffTrakerServiceImpl implements LoginLogoffTrakerService {

	private static final Logger LOG = LoggerFactory.getLogger(LoginLogoffTrakerServiceImpl.class);

    @Autowired
    LoginLogoffTrakerDAOImpl dao;


	@Override
	public LoginLogoffTrakerVO save(LoginLogoffTrakerVO voObj) throws CBridgeDBException {
		LOG.info("SAVE Operation Started");
		LoginLogoffTrakerDO dbObj = saveLoginLogoffTrakerDO(voObj);
		BeanUtils.copyProperties(dbObj, voObj);
		LOG.info("SAVE Operation End");
		return voObj;
	}

	@Override
	public LoginLogoffTrakerVO update(LoginLogoffTrakerVO voObj) throws CBridgeDBException, CBridgeServiceException {
		LoginLogoffTrakerDO dbObj = null;
    	String id = (StringUtils.isNotBlank(voObj.getId()) ? voObj.getId() : "");
		try{
			if (StringUtils.isNotBlank(id)) {
				dbObj = dao.findById(id);
			} else {
				LOG.info("Data Not Found");
			}
			if (dbObj == null){
	            dbObj = saveLoginLogoffTrakerDO(voObj);
	        } else {
	        	LOG.info("DB Update Process for the Unique key -> Id: "+dbObj.getId() + "\t Appp Name: " + dbObj.getAppName());
	        	BeanUtils.copyProperties(voObj, dbObj);
	        	dao.update(dbObj);
	        }
			BeanUtils.copyProperties(dbObj, voObj);
	        voObj.setId(dbObj.getId());
		} catch(Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
			throw new CBridgeServiceException(ex.getMessage());
		}
        return voObj;
	}

	private LoginLogoffTrakerDO saveLoginLogoffTrakerDO(LoginLogoffTrakerVO voObj) throws CBridgeDBException {
		LoginLogoffTrakerDO dbObj;
		String id = dao.generateSequence(CBridgeConstant.SEQUENCE_NAME) + "";
		LOG.info("Test Data Save operation and Id: " + id);
		dbObj = new LoginLogoffTrakerDO();
		BeanUtils.copyProperties(voObj, dbObj);
		dbObj.setId(id);
//            updateRowIndex(dbObj);
		dao.save(dbObj);
		return dbObj;
	}

	@Override
	public List<LoginLogoffTrakerVO> findAll() throws CBridgeDBException {
		List<LoginLogoffTrakerVO> voList = new ArrayList<LoginLogoffTrakerVO>();
		List<LoginLogoffTrakerDO> dbList = null;
		try {
			dbList = dao.findAll();
			for (LoginLogoffTrakerDO dbObj : dbList) {
				LoginLogoffTrakerVO voObj = new LoginLogoffTrakerVO();
				beanCopyAndAddList(voList, dbObj, voObj);
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<LoginLogoffTrakerVO> findByAppName(String appName) throws CBridgeDBException {
		List<LoginLogoffTrakerVO> voList = new ArrayList<LoginLogoffTrakerVO>();
		List<LoginLogoffTrakerDO> dbList = null;
		try {
			if (StringUtils.isNotBlank(appName)) {
				dbList = dao.findByAppName(appName);
				for (LoginLogoffTrakerDO dbObj : dbList) {
					LoginLogoffTrakerVO voObj = new LoginLogoffTrakerVO();
					beanCopyAndAddList(voList, dbObj, voObj);
				}
			} else {
				LOG.info("Data Not Found");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<LoginLogoffTrakerVO> findByModuleName(String moduleName) throws CBridgeDBException {
		List<LoginLogoffTrakerVO> voList = new ArrayList<LoginLogoffTrakerVO>();
		List<LoginLogoffTrakerDO> dbList = null;
		try {
			if (StringUtils.isNotBlank(moduleName)) {
				dbList = dao.findByModuleName(moduleName);
				for (LoginLogoffTrakerDO dbObj : dbList) {
					LoginLogoffTrakerVO voObj = new LoginLogoffTrakerVO();
					beanCopyAndAddList(voList, dbObj, voObj);
				}
			} else {
				LOG.info("Data Not Found");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	private void beanCopyAndAddList(List<LoginLogoffTrakerVO> lst, LoginLogoffTrakerDO dbObj, LoginLogoffTrakerVO voObj) {
		try {
			BeanUtils.copyProperties(dbObj, voObj);
			voObj.setId(dbObj.getId());
			if (lst != null) {
				lst.add(voObj);
			}
		} catch(Exception ex) {
			LOG.error("Error on copy method: " + ex.getMessage());
		}
	}

	@Override
	public LoginLogoffTrakerVO findById(String id) throws CBridgeDBException, CBridgeServiceException {
		LoginLogoffTrakerDO dbObj = null;
		LoginLogoffTrakerVO voObj = new LoginLogoffTrakerVO();
		try{
			if (StringUtils.isNotBlank(id)) {
				dbObj = dao.findById(id);
				beanCopyAndAddList(null, dbObj, voObj);
			} else {
				LOG.info("Data Not Found");
				throw new CBridgeDataNotFoundException("Data Not Found with Id: " + id);
			}
		} catch(Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
			throw new CBridgeServiceException(ex.getMessage());
		}
		return voObj;
	}

	@Override
	public List<LoginLogoffTrakerVO> findByUserIdAndAppName(String userId, String appName) {
		List<LoginLogoffTrakerVO> voList = new ArrayList<LoginLogoffTrakerVO>();
		List<LoginLogoffTrakerDO> dbList = null;
		try {
			if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(appName)) {
				dbList = dao.findByUserIdAndAppName(userId, appName);
				for (LoginLogoffTrakerDO dbObj : dbList) {
					LoginLogoffTrakerVO voObj = new LoginLogoffTrakerVO();
					beanCopyAndAddList(voList, dbObj, voObj);
				}
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		
		return voList;
	}

}
