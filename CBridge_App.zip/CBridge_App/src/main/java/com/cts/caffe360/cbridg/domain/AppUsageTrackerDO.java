
package com.cts.caffe360.cbridg.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
@Document(collection = "AppUsageTracker")
public class AppUsageTrackerDO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@JsonProperty("id")
	private String _id;

	private Integer rowIndex;
	@JsonProperty("user_id")
	private String userId;
	@JsonProperty("user_name")
	private String userName;
	@JsonProperty("app_name")
	private String appName;
	@JsonProperty("module_name")
	private String moduleName;
	@JsonProperty("transaction_type")
	private String transactionType;
	@JsonProperty("created_tot_rec")
	private int tranTotalCount;
	@JsonProperty("tran_status")
	private String tranStatus;
	@JsonProperty("tran_remarks")
	private String tranRemarks;
	@JsonProperty("created_date")
	private Date createdDate;
	@JsonProperty("updated_date")
	private Date updatedDate;
	@JsonProperty("created_by")
	private String createdBy;
	@JsonProperty("total_exe_time")
	private String totalExeTime;
	@JsonProperty("project_name")
	private String projectName;
	@JsonProperty("lob_name")
	private String lobNmae;
	@JsonProperty("cfg_name")
	private String cfgName;
	@JsonProperty("tower_name")
	private String towerName;
	@JsonProperty("onshore_offshore")
	private String onShoreOffshore;
	@JsonProperty("accetpted_rec_count")
	private int acceptedRecCount;
	@JsonProperty("accept_flag")
	private String acceptFlag;

	/**
	 * @return the acceptFlag
	 */
	public String getAcceptFlag() {
		return acceptFlag;
	}

	/**
	 * @param acceptFlag the acceptFlag to set
	 */
	public void setAcceptFlag(String acceptFlag) {
		this.acceptFlag = acceptFlag;
	}

	public String getOnShoreOffshore() {
		return onShoreOffshore;
	}

	public void setOnShoreOffshore(String onShoreOffshore) {
		this.onShoreOffshore = onShoreOffshore;
	}

	public String getTowerName() {
		return towerName;
	}

	public void setTowerName(String towerName) {
		this.towerName = towerName;
	}

	public String getCfgName() {
		return cfgName;
	}

	public void setCfgName(String cfgName) {
		this.cfgName = cfgName;
	}

	public String getLobNmae() {
		return lobNmae;
	}

	public void setLobNmae(String lobNmae) {
		this.lobNmae = lobNmae;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Integer getRowIndex() {
		return rowIndex;
	}

	public void setRowIndex(Integer rowIndex) {
		this.rowIndex = rowIndex;
	}

	public String get_id() {
		return _id;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public int getTranTotalCount() {
		return tranTotalCount;
	}

	public String getTranStatus() {
		return tranStatus;
	}

	public String getTranRemarks() {
		return tranRemarks;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public void setTranTotalCount(int tranTotalCount) {
		this.tranTotalCount = tranTotalCount;
	}

	/**
	 * @return the acceptedRecCount
	 */
	public int getAcceptedRecCount() {
		return acceptedRecCount;
	}

	/**
	 * @param acceptedRecCount the acceptedRecCount to set
	 */
	public void setAcceptedRecCount(int acceptedRecCount) {
		this.acceptedRecCount = acceptedRecCount;
	}

	public void setTranStatus(String tranStatus) {
		this.tranStatus = tranStatus;
	}

	public void setTranRemarks(String tranRemarks) {
		this.tranRemarks = tranRemarks;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getTotalExeTime() {
		return totalExeTime;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setTotalExeTime(String totalExeTime) {
		this.totalExeTime = totalExeTime;
	}

	@Override
	public int hashCode() {
		return Objects.hash(_id, appName, createdBy, createdDate, moduleName, rowIndex, totalExeTime, tranRemarks,
				tranStatus, tranTotalCount, transactionType, updatedDate, userId, userName, projectName, lobNmae,
				cfgName, towerName, onShoreOffshore, acceptedRecCount, acceptFlag);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AppUsageTrackerDO other = (AppUsageTrackerDO) obj;
		return Objects.equals(_id, other._id) && Objects.equals(appName, other.appName)
				&& Objects.equals(createdBy, other.createdBy) && Objects.equals(createdDate, other.createdDate)
				&& Objects.equals(moduleName, other.moduleName) && Objects.equals(rowIndex, other.rowIndex)
				&& Objects.equals(totalExeTime, other.totalExeTime) && Objects.equals(tranRemarks, other.tranRemarks)
				&& Objects.equals(tranStatus, other.tranStatus) && tranTotalCount == other.tranTotalCount
				&& Objects.equals(transactionType, other.transactionType)
				&& Objects.equals(updatedDate, other.updatedDate) && Objects.equals(userId, other.userId)
				&& Objects.equals(userName, other.userName) && Objects.equals(projectName, other.projectName)
				&& Objects.equals(lobNmae, other.lobNmae) && Objects.equals(cfgName, other.cfgName)
				&& Objects.equals(towerName, other.towerName) && Objects.equals(onShoreOffshore, other.onShoreOffshore)
				&& acceptedRecCount == other.acceptedRecCount && Objects.equals(acceptFlag, other.acceptFlag);
	}

	@Override
	public String toString() {
		return "AppUsageTrackerDO [_id=" + _id + ", rowIndex=" + rowIndex + ", userId=" + userId + ", userName="
				+ userName + ", appName=" + appName + ", moduleName=" + moduleName + ", transactionType="
				+ transactionType + ", tranTotalCount=" + tranTotalCount + ", tranStatus=" + tranStatus
				+ ", tranRemarks=" + tranRemarks + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ ", createdBy=" + createdBy + ", totalExeTime=" + totalExeTime + ",projectName=" + projectName
				+ ",lobNmae=" + lobNmae + ",cfgName=" + cfgName + ",towerName=" + towerName + ",onShoreOffshore="
				+ onShoreOffshore + ",acceptedRecCount=" + acceptedRecCount + ",acceptFlag=" + acceptFlag + "]";
	}

}
