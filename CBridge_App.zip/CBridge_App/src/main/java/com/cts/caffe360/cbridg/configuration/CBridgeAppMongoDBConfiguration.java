package com.cts.caffe360.cbridg.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;

import com.cts.caffe360.cbridg.exception.CBridgeDBConnectException;
import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

//@EnableReactiveMongoRepositories({"com.cts.caffe360.cbridg.domain","com.cts.caffe360.cbridg.dao"})
//@AutoConfigureAfter(EmbeddedMongoAutoConfiguration.class)
@Configuration
class CBridgeAppMongoDBConfiguration {
    private static final Logger LOG = LoggerFactory.getLogger(CBridgeAppMongoDBConfiguration.class);

    @Autowired
    private Environment environment;

    @Value("${spring.data.mongodb.host}")
    private String mongoHost;

    @Value("${spring.data.mongodb.port}")
    private String mongopPort;

    @Value("${spring.data.mongodb.port}")
    private String mongoPort;

    @Value("${spring.data.mongodb.database}")
    private String mongoDB;

    @Value("spring.data.mongodb.collection")
    private String dbCollection;

    @Value("spring.data.mongodb.url")
    private String url;

    private static final int conErrorCount = 0;
    
    public CBridgeAppMongoDBConfiguration(Environment environment) {
        this.environment = environment;
    }

    @Bean("mongoDbFactory")
    public MongoDatabaseFactory mongoDbFactory() {
        return new SimpleMongoClientDatabaseFactory(new ConnectionString(environment.getProperty(url)));
    }

    @Bean("mongoTemplate")
    public MongoTemplate mongoTemplate() {
        LOG.info("MongoDB connection in progress with given property URL: " + environment.getProperty(url));
        try{
        	if (MongoDBSrtatStopService.isMongoDBRunning(mongoHost, mongoPort)) {
				LOG.info("MongoDB connection established successfully.");
			} else {
				MongoDBSrtatStopService.startMongoDB();
        	}
            return new MongoTemplate(mongoDbFactory());
        } catch (Exception ex){
            LOG.error("Exception while create MongoDB connection in mongoTemplate() method.", ex);
            throw new CBridgeDBConnectException(ex);
        }

    }

    @Bean("mongoClient")
    public MongoClient mongoClient() {
//        int port = environment.getProperty("spring.data.mongodb.port", Integer.class);
        LOG.info("MongoDB connection in progress with given property URL: " + environment.getProperty(url));
        try{
            return MongoClients.create(String.format("mongodb://%s:%d", mongoHost, Integer.parseInt(mongopPort)));
        } catch (Exception ex){
            LOG.error("Exception while create MongoDB connection in mongoClient() method.", ex);
            throw new CBridgeDBConnectException(ex);
        }
    }

    protected String getDatabaseName() {
        return mongoDB;
    }

    protected String getDbCollection(){
        return dbCollection;
    }

	public Environment getEnvironment() {
		return environment;
	}

	public String getMongoHost() {
		return mongoHost;
	}

	public String getMongopPort() {
		return mongopPort;
	}

	public String getMongoPort() {
		return mongoPort;
	}

	public String getMongoDB() {
		return mongoDB;
	}

	public String getUrl() {
		return url;
	}

	public static int getConerrorcount() {
		return conErrorCount;
	}

}
