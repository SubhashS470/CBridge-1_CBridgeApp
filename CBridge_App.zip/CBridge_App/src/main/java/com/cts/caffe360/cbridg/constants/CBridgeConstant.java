package com.cts.caffe360.cbridg.constants;

import java.text.SimpleDateFormat;

public interface CBridgeConstant {
	String APP_PATH = System.getProperty("user.dir");
    String SEQUENCE_NAME = "TestData_Sequence";
    String DATE_FORMAT_DD_MM = "DD-MM-yyyy";
    
//    enum OPERATION = new Enum{"Add", "update", "remove"}();
    String ADD_OPERATION = "Add";
	String UPDATE_OPERATION = "update";
	String REMOVE_OPERATION = "remove";
	
	SimpleDateFormat SDF_DD_MM_YYYY= new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat SDF_MM_DD_YYYY= new SimpleDateFormat("MM/dd/yyyy");
	SimpleDateFormat SDF_YYYY_MM_DD= new SimpleDateFormat("yyyy/MM/dd");
}
