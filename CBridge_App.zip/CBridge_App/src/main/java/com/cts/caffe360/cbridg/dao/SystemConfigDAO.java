package com.cts.caffe360.cbridg.dao;

import java.util.List;
import java.util.Map;

import com.cts.caffe360.cbridg.domain.SystemConfigDO;

public interface SystemConfigDAO {
	List<SystemConfigDO> findAll();
	List<SystemConfigDO> findBySysParamType(String sysParamType);
	Map<Long, String> findTypeMapByParamType(String sysParamType);
	SystemConfigDO save(SystemConfigDO systemConfigDO);
	SystemConfigDO findBySysConfigId(Integer sysConfigId);
	void deleteBySysConfigId(Integer sysConfigId);
}