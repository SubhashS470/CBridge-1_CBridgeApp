package com.cts.caffe360.cbridg.exception;

public class CBridgeDataNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public CBridgeDataNotFoundException() {
        super();
    }

    public CBridgeDataNotFoundException(String s) {
        super(s);
    }

    public CBridgeDataNotFoundException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CBridgeDataNotFoundException(Throwable throwable) {
        super(throwable);
    }

    protected CBridgeDataNotFoundException(String s, Throwable throwable, boolean b, boolean b1) {
        super(s, throwable, b, b1);
    }
}
