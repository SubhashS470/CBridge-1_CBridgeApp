package com.cts.caffe360.cbridg.service;

import java.util.List;

import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.vo.TmgUserDetailsVO;

public interface TmgUserDetailsService {
	List<TmgUserDetailsVO> findAll() throws Exception;
	TmgUserDetailsVO findByAssociateId(String associateId) throws CBridgeDataNotFoundException;
	TmgUserDetailsVO create(TmgUserDetailsVO tmgUserDetailsVO) throws Exception;
	TmgUserDetailsVO updateByAssociateId(String associateId, TmgUserDetailsVO tmgUserDetailsVO) throws Exception;
	void deleteByAssociateId(String associateId) throws CBridgeDataNotFoundException;
}