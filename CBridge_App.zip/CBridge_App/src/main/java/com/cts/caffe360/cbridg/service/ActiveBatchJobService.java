package com.cts.caffe360.cbridg.service;

import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.vo.ActiveBatchJobVO;

@Service
public interface ActiveBatchJobService {
	
	ActiveBatchJobVO triggerABJob(String abJob,String type) throws Exception;
	
	String getABJobStatus(String instentId)throws Exception;

}
