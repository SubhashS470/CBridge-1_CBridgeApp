package com.cts.caffe360.cbridg.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.exception.CBridgeDBException;
import com.cts.caffe360.cbridg.exception.CBridgeServiceException;
import com.cts.caffe360.cbridg.vo.AppUsageTrackerVO;

@Service
public interface AppUsageTrackerService {
	AppUsageTrackerVO save(AppUsageTrackerVO appUsageTrackerVO) throws CBridgeDBException;

	AppUsageTrackerVO update(AppUsageTrackerVO appUsageTracker) throws CBridgeDBException, CBridgeServiceException;

	AppUsageTrackerVO findById(String Id) throws CBridgeDBException, CBridgeServiceException;

	List<AppUsageTrackerVO> findAll() throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserId(String userId) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserIdFromToDate(String userId, String from, String to) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserName(String userName) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserNameFromToDate(String userName, Date from, Date to)
			throws CBridgeDBException;
	
	List<AppUsageTrackerVO> findByFromToDate(String from, String to)
			throws CBridgeDBException;
	
	List<AppUsageTrackerVO> findByAppName(String appName) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByAppNameFromToDate(String appName, String from, String to) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByModuleName(String moduleName) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByModuleNameFromToDate(String moduleName, Date from, Date to)
			throws CBridgeDBException;

	List<AppUsageTrackerVO> findByTxnType(String TxnType) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByTxnTypeFromToDate(String TxnType, Date from, Date to) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByModuleNameAndAppName(String moduleName, String appName)
			throws CBridgeDBException;

	List<AppUsageTrackerVO> findByModuleNameAndAppNameFromToDate(String moduleName, String appName,
			String from, String to) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleNameAndDateFromToDate(String userId,
			String appName, String moduleName, Date date, Date from, Date to) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleName(String userId, String appName,
			String moduleName) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleNameAndTxnType(String userId, String appName,
			String moduleName, String TxnType) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(String userId,
			String appName, String moduleName, String TxnType, Date from, Date to)
			throws CBridgeDBException;

	List<AppUsageTrackerVO> findByUserIdAndAppName(String userId, String appName);
	List<AppUsageTrackerVO> findByTower(String towerName) throws CBridgeDBException;

	List<AppUsageTrackerVO> findByTowerNameAndFromAndTodate(String towerName, Date from, Date to);
	List<AppUsageTrackerVO> findByUserIdAndTowerName(String userId, String towerName);
	List<AppUsageTrackerVO> findByAllFetch(String towerName,String userId,String appName,
			String moduleName, String TxnType,String from,
			String to);

	List<AppUsageTrackerVO> bulkUpdate(List<AppUsageTrackerVO> voList);
}
