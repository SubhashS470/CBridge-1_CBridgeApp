package com.cts.caffe360.cbridg.exception;

public class CBridgeDBException extends Exception{

	private static final long serialVersionUID = 1L;

	public CBridgeDBException() {
        super();
    }

    public CBridgeDBException(String s) {
        super(s);
    }

    public CBridgeDBException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CBridgeDBException(Throwable throwable) {
        super(throwable);
    }

    protected CBridgeDBException(String s, Throwable throwable, boolean b, boolean b1) {
        super(s, throwable, b, b1);
    }
}
