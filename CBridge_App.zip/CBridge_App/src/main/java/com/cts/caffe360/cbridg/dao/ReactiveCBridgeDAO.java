package com.cts.caffe360.cbridg.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.domain.CBridgeTestDataDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;

@Repository
public interface ReactiveCBridgeDAO extends CBridgeDAO {

    @Query("{ '_id': ?0}")
    CBridgeTestDataDO findById(String id) throws Exception;

    @Query("{ 'key': ?0}")
    List<CBridgeTestDataDO> findByKey(String key) throws Exception;

    @Query("{ '_id': ?0, 'key': ?1}")
    CBridgeTestDataDO findByIdAndKey(String Id, String value) throws Exception;

    public List<CBridgeTestDataDO> findAll() throws Exception;

    @Query("{ 'key': ?0, 'values.value': ?1}")
    List<CBridgeTestDataDO> findByKeyAndValue(String key, String value) throws Exception;

    @Query("{ 'key': ?0, 'values.value': ?1, 'module': ?2}")
    List<CBridgeTestDataDO> findByKeyAndValue(String key, String value, String module) throws Exception;
    
    @Query("{ 'key': ?0, 'values.value': ?1}")
    CBridgeTestDataDO findByKeyModuleUser(String key, String module, String user) throws Exception;

    public CBridgeTestDataDO save(CBridgeTestDataDO dataDO) throws CBridgeDBException;

    public CBridgeTestDataDO update(CBridgeTestDataDO dataDO) throws CBridgeDBException;

    void deleteKeyValue(String key, String module, String value) throws Exception;

	void deleteKeyValueAll(String key, String module) throws Exception;

    void deleteKeyValueExpiryDate(String key, String module) throws Exception;
    
    public void deleteById(String key) throws CBridgeDBException;
   
}
