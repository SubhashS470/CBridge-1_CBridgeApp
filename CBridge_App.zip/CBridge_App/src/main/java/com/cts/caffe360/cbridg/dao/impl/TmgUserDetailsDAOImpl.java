package com.cts.caffe360.cbridg.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.dao.TmgUserDetailsDAO;
import com.cts.caffe360.cbridg.domain.TmgUserDetailsDO;

@Repository
public class TmgUserDetailsDAOImpl implements TmgUserDetailsDAO {

	private static final Logger LOG = LoggerFactory.getLogger(TmgUserDetailsDAOImpl.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<TmgUserDetailsDO> findAll() {
		LOG.info("TmgUserDetailsDAOImpl: findAll");
		return mongoTemplate.findAll(TmgUserDetailsDO.class);
	}

	@Override
	public TmgUserDetailsDO findByAssociateId(String associateId) {
		LOG.info("TmgUserDetailsDAOImpl: findByAssociateId: {}", associateId);

		try {
			Long number = Long.parseLong(associateId);
			Query query = new Query(Criteria.where("Associate_Id").is(number));
			return mongoTemplate.findOne(query, TmgUserDetailsDO.class);
		} catch (NumberFormatException e) {
			LOG.error("Invalid number: " + associateId, e);
		}
		return null;

	}

	@Override
	public TmgUserDetailsDO save(TmgUserDetailsDO tmgUserDetailsDO) {
		LOG.info("TmgUserDetailsDAOImpl: save");
		return mongoTemplate.save(tmgUserDetailsDO);
	}

	@Override
	public void deleteByAssociateId(String associateId) {
		try {
			Long number = Long.parseLong(associateId);
			LOG.info("TmgUserDetailsDAOImpl: deleteByAssociateId: {}", associateId);
			Query query = new Query(Criteria.where("Associate_Id").is(number));
			mongoTemplate.remove(query, TmgUserDetailsDO.class);
		} catch (NumberFormatException e) {
			LOG.error("Invalid number: " + associateId, e);
		}

	}
}