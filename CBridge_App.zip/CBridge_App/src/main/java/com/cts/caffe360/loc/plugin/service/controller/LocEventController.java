package com.cts.caffe360.loc.plugin.service.controller;

import com.cts.caffe360.cbridg.resource.CBridgeABatchJobAPI;
import com.cts.caffe360.loc.plugin.service.dto.BatchLocEventRequest;
import com.cts.caffe360.loc.plugin.service.dto.LocEventRequest;
import com.cts.caffe360.loc.plugin.service.dto.LocEventResponse;
import com.cts.caffe360.loc.plugin.service.dto.LocSummary;
import com.cts.caffe360.loc.plugin.service.service.LocEventService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * LocEventController — RESTful API for GenAI LOC Tracker events.
 *
 * Base path : /api/v1/genai-loc
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  Endpoint                                   Method  Description         │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │  /events                                    POST    Create single event │
 * │  /events/batch                              POST    Create batch events │
 * │  /events                                    GET     List all (paged)    │
 * │  /events/{id}                               GET     Get by ID           │
 * │  /events/{id}                               PUT     Full update         │
 * │  /events/{id}                               DELETE  Delete by ID        │
 * │  /events/developer/{developerId}            GET     By developer        │
 * │  /events/project/{projectId}                GET     By project          │
 * │  /events/tool/{genAiTool}                   GET     By AI tool          │
 * │  /events/session/{sessionId}                GET     By session          │
 * │  /events/session/{sessionId}                DELETE  Delete by session   │
 * │  /summary/developer/{developerId}           GET     Developer summary   │
 * │  /summary/project/{projectId}               GET     Project summary     │
 * │  /summary/project/{projectId}/sprint/{id}   GET     Sprint summary      │
 * └─────────────────────────────────────────────────────────────────────────┘
 */
@Slf4j()
@RestController
@RequestMapping("/genai-loc")
@RequiredArgsConstructor
public class LocEventController {
	private static final Logger LOG = LoggerFactory.getLogger(LocEventController.class);
    
	private LocEventService service;

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * POST /genai-loc/events
     * Accepts a single LOC event from the IntelliJ plugin.
     */
    @PostMapping("/events")
    public ResponseEntity<LocEventResponse> createEvent(
            @Valid @RequestBody LocEventRequest req) {
    	LOG.debug("POST /events dev={} file={} tool={} \t Request Body: {}", req.getDeveloperId(),
                req.getFileName(), req.getGenAiTool(), req.toString());
        LocEventResponse saved = service.create(req);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    /**
     * POST /genai-loc/events/batch
     * Accepts a batch of LOC events (sent when queue > 1 in the plugin).
     */
    @PostMapping("/events/batch")
    public ResponseEntity<List<LocEventResponse>> createBatch(
            @Valid @RequestBody BatchLocEventRequest req) {
    	LOG.debug("POST /events/batch count={}", req.getEvents().size());
        List<LocEventResponse> saved = service.createBatch(req.getEvents());
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // ── READ ──────────────────────────────────────────────────────────────────

    /**
     * GET /genai-loc/events
     * Returns all events paginated. Default: page=0, size=20, sort=eventTimestamp desc.
     */
    @GetMapping("/events")
    public ResponseEntity<Page<LocEventResponse>> getAllEvents(
            @PageableDefault(size = 20, sort = "eventTimestamp",
                             direction = Sort.Direction.DESC) Pageable pageable) {
    	LOG.debug("GET /events page={} size={} sort={}", pageable.getPageNumber(),
                pageable.getPageSize(), pageable.getSort());
        return ResponseEntity.ok(service.getAll(pageable));
    }

    /**
     * GET /genai-loc/events/{id}
     * Returns a single event by MongoDB document ID.
     */
    @GetMapping("/events/{id}")
    public ResponseEntity<LocEventResponse> getEventById(@PathVariable String id) {
    	LOG.debug("GET /events/{}", id);
        return ResponseEntity.ok(service.getById(id));
    }

    /**
     * GET /genai-loc/events/developer/{developerId}
     * Optional query params: from, to (ISO-8601 timestamps for range filter).
     */
    @GetMapping("/events/developer/{developerId}")
    public ResponseEntity<Page<LocEventResponse>> getByDeveloper(
            @PathVariable String developerId,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @PageableDefault(size = 20, sort = "eventTimestamp",
                             direction = Sort.Direction.DESC) Pageable pageable) {
        Page<LocEventResponse> result = (from != null && to != null)
                ? service.getByDeveloperInRange(developerId, from, to, pageable)
                : service.getByDeveloper(developerId, pageable);
        return ResponseEntity.ok(result);
    }

    /**
     * GET /genai-loc/events/project/{projectId}
     * Optional query params: from, to for range filter.
     */
    @GetMapping("/events/project/{projectId}")
    public ResponseEntity<Page<LocEventResponse>> getByProject(
            @PathVariable String projectId,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @PageableDefault(size = 20, sort = "eventTimestamp",
                             direction = Sort.Direction.DESC) Pageable pageable) {
        Page<LocEventResponse> result = (from != null && to != null)
                ? service.getByProjectInRange(projectId, from, to, pageable)
                : service.getByProject(projectId, pageable);
        return ResponseEntity.ok(result);
    }

    /**
     * GET /genai-loc/events/developer/{developerId}/project/{projectId}
     * Optional query params: from, to for range filter.
     */
    @GetMapping("/events/developer/{developerId}/project/{projectId}")
    public ResponseEntity<Page<LocEventResponse>> getByDeveloperAndProject(
            @PathVariable String developerId,
            @PathVariable String projectId,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @PageableDefault(size = 20, sort = "eventTimestamp",
                             direction = Sort.Direction.DESC) Pageable pageable) {
        Page<LocEventResponse> result = (from != null && to != null)
                ? service.getByDeveloperAndProjectInRange(developerId, projectId, from, to, pageable)
                : service.getByDeveloperAndProject(developerId, projectId, pageable);
        return ResponseEntity.ok(result);
    }

    /**
     * GET /genai-loc/events/tool/{genAiTool}
     * Filter events by GenAI tool (COPILOT, CLAUDE, CHATGPT, GEMINI, NONE, etc.)
     */
    @GetMapping("/events/tool/{genAiTool}")
    public ResponseEntity<Page<LocEventResponse>> getByTool(
            @PathVariable String genAiTool,
            @PageableDefault(size = 20, sort = "eventTimestamp",
                             direction = Sort.Direction.DESC) Pageable pageable) {
        return ResponseEntity.ok(service.getByTool(genAiTool, pageable));
    }

    /**
     * GET /genai-loc/events/session/{sessionId}
     * Returns all events from a specific plugin session.
     */
    @GetMapping("/events/session/{sessionId}")
    public ResponseEntity<List<LocEventResponse>> getBySession(@PathVariable String sessionId) {
        return ResponseEntity.ok(service.getBySession(sessionId));
    }

    /**
     * GET /genai-loc/events/project/{projectId}/sprint/{sprintId}
     */
    @GetMapping("/events/project/{projectId}/sprint/{sprintId}")
    public ResponseEntity<List<LocEventResponse>> getBySprint(
            @PathVariable String projectId,
            @PathVariable String sprintId) {
        return ResponseEntity.ok(service.getBySprint(projectId, sprintId));
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * PUT /genai-loc/events/{id}
     * Full replacement of an existing event.
     */
    @PutMapping("/events/{id}")
    public ResponseEntity<LocEventResponse> updateEvent(
            @PathVariable String id,
            @Valid @RequestBody LocEventRequest req) {
    	LOG.debug("PUT /events/{} dev={} file={}", id, req.getDeveloperId(), req.getFileName());
        return ResponseEntity.ok(service.update(id, req));
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    /**
     * DELETE /genai-loc/events/{id}
     * Removes a single event by ID.
     */
    @DeleteMapping("/events/{id}")
    public ResponseEntity<Void> deleteEvent(@PathVariable String id) {
    	LOG.debug("DELETE /events/{}", id);
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * DELETE /genai-loc/events/session/{sessionId}
     * Removes all events from a session (used for replay cleanup).
     */
    @DeleteMapping("/events/session/{sessionId}")
    public ResponseEntity<Map<String, Long>> deleteBySession(@PathVariable String sessionId) {
        long removed = service.deleteBySession(sessionId);
        return ResponseEntity.ok(Map.of("removed", removed));
    }

    // ── SUMMARY ───────────────────────────────────────────────────────────────

    /**
     * GET /genai-loc/summary/developer/{developerId}?from=...&to=...
     * Aggregated LOC stats for a developer within a time range.
     */
    @GetMapping("/summary/developer/{developerId}")
    public ResponseEntity<LocSummary> getSummaryByDeveloper(
            @PathVariable String developerId,
            @RequestParam String from,
            @RequestParam String to) {
        return ResponseEntity.ok(service.getSummaryByDeveloper(developerId, from, to));
    }

    /**
     * GET /genai-loc/summary/project/{projectId}?from=...&to=...
     * Aggregated LOC stats for a project within a time range.
     */
    @GetMapping("/summary/project/{projectId}")
    public ResponseEntity<LocSummary> getSummaryByProject(
            @PathVariable String projectId,
            @RequestParam String from,
            @RequestParam String to) {
        return ResponseEntity.ok(service.getSummaryByProject(projectId, from, to));
    }

    /**
     * GET /genai-loc/summary/project/{projectId}/sprint/{sprintId}
     * Aggregated LOC stats for a project sprint.
     */
    @GetMapping("/summary/project/{projectId}/sprint/{sprintId}")
    public ResponseEntity<LocSummary> getSummaryBySprint(
            @PathVariable String projectId,
            @PathVariable String sprintId) {
        return ResponseEntity.ok(service.getSummaryBySprint(projectId, sprintId));
    }
}

