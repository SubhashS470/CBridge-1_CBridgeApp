package com.cts.caffe360.cbridg.utiles;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.cts.caffe360.cbridg.constants.CBridgeConstant;
import com.cts.caffe360.cbridg.vo.CBridgeTestDataVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class CBridgeUtile {



    public static String getJsonObjectString(Object testDataDO){
        String objValue = null;
        try {
            objValue = new ObjectMapper().writeValueAsString(testDataDO);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return objValue;
    }

    public static CBridgeTestDataVO getCBridgeTestDataDOFromJson(String testDataDO){
    	CBridgeTestDataVO objValue = null;
        try {
            objValue = new ObjectMapper().readValue(testDataDO, CBridgeTestDataVO.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return objValue;
    }

    public static String getFormattedDateValue(Date date){
        return new SimpleDateFormat(CBridgeConstant.DATE_FORMAT_DD_MM).format(date);
    }
}
