package com.cts.caffe360.cbridg.domain;

import java.util.Objects;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
@Document(collection = "TMG_User_Details")
public class TmgUserDetailsDO {

	@Id
	@JsonProperty("id")
	private String id;

	@Field("Associate_Id")
	@JsonProperty("Associate_Id")
	private Long associateId;

	@Field("Associate_Name")
	@JsonProperty("Associate_Name")
	private String associateName;

	@Field("password")
	@JsonProperty("password")
	private String password;

	@Field("Email_Id")
	@JsonProperty("Email_Id")
	private String email;

	@Field("TMG_User_Id")
	@JsonProperty("TMG_User_Id")
	private String tmgUserId;

	@Field("Status")
	@JsonProperty("Status")
	private String status;

	@Field("Location")
	@JsonProperty("Location")
	private String location;

	@Field("Supervisor_ID")
	@JsonProperty("Supervisor_ID")
	private Long superviserId;

	@Field("Supervisor_Name")
	@JsonProperty("Supervisor_Name")
	private String superviserName;

	@Field("Tower")
	@JsonProperty("Tower")
	private String tower;

	@Field("Project")
	@JsonProperty("Project")
	private String project;

	public String getId() { return id; }
	public void setId(String id) { this.id = id; }
	public Long getAssociateId() { return associateId; }
	public void setAssociateId(Long associateId) { this.associateId = associateId; }
	public String getAssociateName() { return associateName; }
	public void setAssociateName(String associateName) { this.associateName = associateName; }
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
	public String getTmgUserId() { return tmgUserId; }
	public void setTmgUserId(String tmgUserId) { this.tmgUserId = tmgUserId; }
	public String getStatus() { return status; }
	public void setStatus(String status) { this.status = status; }
	public String getLocation() { return location; }
	public void setLocation(String location) { this.location = location; }
	public Long getSuperviserId() { return superviserId; }
	public void setSuperviserId(Long superviserId) { this.superviserId = superviserId; }
	public String getSuperviserName() { return superviserName; }
	public void setSuperviserName(String superviserName) { this.superviserName = superviserName; }
	public String getTower() { return tower; }
	public void setTower(String tower) { this.tower = tower; }
	public String getProject() { return project; }
	public void setProject(String project) { this.project = project; }

	@Override
	public String toString() {
		return "TmgUserDetailsDO [id=" + id + ", associateId=" + associateId + ", associateName=" + associateName
				+ ", password=" + password + ", email=" + email + ", tmgUserId=" + tmgUserId + ", status=" + status
				+ ", location=" + location + ", superviserId=" + superviserId + ", superviserName=" + superviserName
				+ ", tower=" + tower + ", project=" + project + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(associateId, associateName, email, id, location, password, project, status, superviserId,
				superviserName, tmgUserId, tower);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		TmgUserDetailsDO other = (TmgUserDetailsDO) obj;
		return Objects.equals(associateId, other.associateId) && Objects.equals(associateName, other.associateName)
				&& Objects.equals(email, other.email) && Objects.equals(id, other.id)
				&& Objects.equals(location, other.location) && Objects.equals(password, other.password)
				&& Objects.equals(project, other.project) && Objects.equals(status, other.status)
				&& Objects.equals(superviserId, other.superviserId)
				&& Objects.equals(superviserName, other.superviserName) && Objects.equals(tmgUserId, other.tmgUserId)
				&& Objects.equals(tower, other.tower);
	}
}