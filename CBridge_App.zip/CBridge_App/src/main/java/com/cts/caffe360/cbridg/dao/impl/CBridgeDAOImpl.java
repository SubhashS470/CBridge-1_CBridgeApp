package com.cts.caffe360.cbridg.dao.impl;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.cts.caffe360.cbridg.dao.CBridgeDAO;
import com.cts.caffe360.cbridg.domain.CBridgeDBSequence;

public class CBridgeDAOImpl implements CBridgeDAO{

	@Autowired
    protected MongoTemplate mongoTemplate;
	
	@Override
	public long generateSequence(String seqName) {
		Query query = new Query();
		CBridgeDBSequence counter = mongoTemplate.findAndModify(query.addCriteria(where("_id").is(seqName)),
				new Update().inc("seq",1),
				FindAndModifyOptions.options().returnNew(true).upsert(true), CBridgeDBSequence.class);
		return !Objects.isNull(counter) ? counter.getSeq() : 1;
	}
}
