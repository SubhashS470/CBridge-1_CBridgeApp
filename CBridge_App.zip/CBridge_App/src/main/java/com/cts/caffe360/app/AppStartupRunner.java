package com.cts.caffe360.app;

import org.springframework.boot.CommandLineRunner;

//@Component
public class AppStartupRunner implements CommandLineRunner {

//	@Autowired
//    private MongoDBSrtatStopService mongoDBService;

    @Override
    public void run(String... args) throws Exception {
//        mongoDBService.ensureMongoDBIsRunning();
    }
}
