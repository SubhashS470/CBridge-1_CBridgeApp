package com.cts.caffe360.cbridg.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TmgUserDetailsVO {

	@JsonProperty("Associate_Id")
	private Long associateId;

	@JsonProperty("Associate_Name")
	private String associateName;

	@JsonProperty("password")
	private String password;

	@JsonProperty("Email_Id")
	private String email;

	@JsonProperty("TMG_User_Id")
	private String tmgUserId;

	@JsonProperty("Status")
	private String status;

	@JsonProperty("Location")
	private String location;

	@JsonProperty("Supervisor_ID")
	private Long superviserId;

	@JsonProperty("Supervisor_Name")
	private String superviserName;

	@JsonProperty("Tower")
	private String tower;

	@JsonProperty("Project")
	private String project;

	public Long getAssociateId() { return associateId; }
	public void setAssociateId(Long associateId) { this.associateId = associateId; }
	public String getAssociateName() { return associateName; }
	public void setAssociateName(String associateName) { this.associateName = associateName; }
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
	public String getTmgUserId() { return tmgUserId; }
	public void setTmgUserId(String tmgUserId) { this.tmgUserId = tmgUserId; }
	public String getStatus() { return status; }
	public void setStatus(String status) { this.status = status; }
	public String getLocation() { return location; }
	public void setLocation(String location) { this.location = location; }
	public Long getSuperviserId() { return superviserId; }
	public void setSuperviserId(Long superviserId) { this.superviserId = superviserId; }
	public String getSuperviserName() { return superviserName; }
	public void setSuperviserName(String superviserName) { this.superviserName = superviserName; }
	public String getTower() { return tower; }
	public void setTower(String tower) { this.tower = tower; }
	public String getProject() { return project; }
	public void setProject(String project) { this.project = project; }
}