package com.cts.caffe360.cbridg.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

//@ControllerAdvice
public class CBridgeGlobalExceptionHandler {

    @ExceptionHandler(CBridgeResourceNotFoundException.class)
    public ResponseEntity<?> resourceNotFoundException(CBridgeResourceNotFoundException ex, WebRequest request) {
        CBridgeErrorDetails errorDetails = new CBridgeErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> globleExcpetionHandler(Exception ex, WebRequest request) {
        CBridgeErrorDetails errorDetails = new CBridgeErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
