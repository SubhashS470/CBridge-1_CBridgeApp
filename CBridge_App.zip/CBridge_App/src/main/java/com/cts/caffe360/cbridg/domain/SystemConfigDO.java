package com.cts.caffe360.cbridg.domain;

import java.util.Objects;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
@Document(collection = "Sys_Config")
public class SystemConfigDO {

	@Id
	@JsonProperty("id")
	private String id;

	@Field("Sys_Config_Id")
	@JsonProperty("Sys_Config_Id")
	private Integer sysConfigId;

	@Field("Sys_Param_Type")
	@JsonProperty("Sys_Param_Type")
	private String sysParamType;

	@Field("Type_Id")
	@JsonProperty("Type_Id")
	private Long typeId;

	@Field("Type_Value")
	@JsonProperty("Type_Value")
	private String typeValue;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the sysConfigId
	 */
	public Integer getSysConfigId() {
		return sysConfigId;
	}

	/**
	 * @param sysConfigId the sysConfigId to set
	 */
	public void setSysConfigId(Integer sysConfigId) {
		this.sysConfigId = sysConfigId;
	}

	/**
	 * @return the sysParamType
	 */
	public String getSysParamType() {
		return sysParamType;
	}

	/**
	 * @param sysParamType the sysParamType to set
	 */
	public void setSysParamType(String sysParamType) {
		this.sysParamType = sysParamType;
	}

	/**
	 * @return the typeId
	 */
	public Long getTypeId() {
		return typeId;
	}

	/**
	 * @param typeId the typeId to set
	 */
	public void setTypeId(Long typeId) {
		this.typeId = typeId;
	}

	/**
	 * @return the typeValue
	 */
	public String getTypeValue() {
		return typeValue;
	}

	/**
	 * @param typeValue the typeValue to set
	 */
	public void setTypeValue(String typeValue) {
		this.typeValue = typeValue;
	}

	@Override
	public String toString() {
		return "SystemConfigDO [id=" + id + ", sysConfigId=" + sysConfigId + ", sysParamType=" + sysParamType
				+ ", typeId=" + typeId + ", typeValue=" + typeValue + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, sysConfigId, sysParamType, typeId, typeValue);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SystemConfigDO other = (SystemConfigDO) obj;
		return Objects.equals(id, other.id) 
				&& Objects.equals(sysConfigId, other.sysConfigId)
				&& Objects.equals(sysParamType, other.sysParamType) 
				&& Objects.equals(typeId, other.typeId)
				&& Objects.equals(typeValue, other.typeValue);
	}

}