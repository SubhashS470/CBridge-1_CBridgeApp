
package com.cts.caffe360.cbridg.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AppUsageTrackerVO implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("id")
	private String id;
	@JsonProperty("user_id")
	private String userId;
	@JsonProperty("user_name")
	private String userName;
	@JsonProperty("app_name")
	private String appName;
	@JsonProperty("module_name")
	private String moduleName;
	@JsonProperty("transaction_type")
	private String transactionType;
	@JsonProperty("created_tot_rec")
	private int tranTotalCount;
	@JsonProperty("tran_status")
	private String tranStatus;
	@JsonProperty("tran_remarks")
	private String tranRemarks;
	@JsonProperty("created_date")
	private Date createdDate;
	@JsonProperty("updated_date")
	private Date updatedDate;
	@JsonProperty("created_by")
	private String createdBy;
	@JsonProperty("total_exe_time")
	private String totalExeTime;
	@JsonProperty("project_name")
	private String projectName;
	@JsonProperty("lob_name")
	private String lobNmae;
	@JsonProperty("cfg_name")
	private String cfgName;
	@JsonProperty("tower_name")
	private String towerName;
	@JsonProperty("onshore_offshore")
	private String onShoreOffshore;
	@JsonProperty("accetpted_rec_count")
	private int acceptedRecCount;
	@JsonProperty("accept_flag")
	private String acceptFlag;

	public AppUsageTrackerVO() {
		super();
	}

	public AppUsageTrackerVO(String id, String userId, String userName, String appName, String moduleName,
			String transactionType, int tranTotalCount, String tranStatus, String tranRemarks, Date createdDate,
			Date updatedDate, String createdBy, String totalExeTime, String projectName, String lobNmae, String cfgName,
			String towerName, String onShoreOffshore, int acceptedRecCount,String acceptFlag ) {
		super();
		this.id = id;
		this.userId = userId;
		this.userName = userName;
		this.appName = appName;
		this.moduleName = moduleName;
		this.transactionType = transactionType;
		this.tranTotalCount = tranTotalCount;
		this.tranStatus = tranStatus;
		this.tranRemarks = tranRemarks;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.createdBy = createdBy;
		this.totalExeTime = totalExeTime;
		this.projectName = projectName;
		this.lobNmae = lobNmae;
		this.cfgName = cfgName;
		this.towerName = towerName;
		this.onShoreOffshore = onShoreOffshore;
		this.acceptedRecCount = acceptedRecCount;
		this.acceptFlag=acceptFlag;
	}

	/**
	 * @return the acceptFlag
	 */
	public String getAcceptFlag() {
		return acceptFlag;
	}

	/**
	 * @param acceptFlag the acceptFlag to set
	 */
	public void setAcceptFlag(String acceptFlag) {
		this.acceptFlag = acceptFlag;
	}

	public String getOnShoreOffshore() {
		return onShoreOffshore;
	}

	public void setOnShoreOffshore(String onShoreOffshore) {
		this.onShoreOffshore = onShoreOffshore;
	}

	public String getTowerName() {
		return towerName;
	}

	public void setTowerName(String towerName) {
		this.towerName = towerName;
	}

	public String getCfgName() {
		return cfgName;
	}

	public void setCfgName(String cfgName) {
		this.cfgName = cfgName;
	}

	public String getLobNmae() {
		return lobNmae;
	}

	public void setLobNmae(String lobNmae) {
		this.lobNmae = lobNmae;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getUserId() {
		return userId;
	}

	public String getUserName() {
		return userName;
	}

	public String getAppName() {
		return appName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public int getTranTotalCount() {
		return tranTotalCount;
	}

	public String getTranStatus() {
		return tranStatus;
	}

	public String getTranRemarks() {
		return tranRemarks;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public void setTranTotalCount(int tranTotalCount) {
		this.tranTotalCount = tranTotalCount;
	}

	/**
	 * @return the acceptedRecCount
	 */
	public int getAcceptedRecCount() {
		return acceptedRecCount;
	}

	/**
	 * @param acceptedRecCount the acceptedRecCount to set
	 */
	public void setAcceptedRecCount(int acceptedRecCount) {
		this.acceptedRecCount = acceptedRecCount;
	}

	public void setTranStatus(String tranStatus) {
		this.tranStatus = tranStatus;
	}

	public void setTranRemarks(String tranRemarks) {
		this.tranRemarks = tranRemarks;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getTotalExeTime() {
		return totalExeTime;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setTotalExeTime(String totalExeTime) {
		this.totalExeTime = totalExeTime;
	}

	@Override
	public int hashCode() {
		return Objects.hash(appName, createdBy, createdDate, id, moduleName, totalExeTime, tranRemarks, tranStatus,
				tranTotalCount, transactionType, updatedDate, userId, userName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AppUsageTrackerVO other = (AppUsageTrackerVO) obj;
		return Objects.equals(appName, other.appName) && Objects.equals(createdBy, other.createdBy)
				&& Objects.equals(createdDate, other.createdDate) && Objects.equals(id, other.id)
				&& Objects.equals(moduleName, other.moduleName) && Objects.equals(totalExeTime, other.totalExeTime)
				&& Objects.equals(tranRemarks, other.tranRemarks) && Objects.equals(tranStatus, other.tranStatus)
				&& tranTotalCount == other.tranTotalCount && Objects.equals(transactionType, other.transactionType)
				&& Objects.equals(updatedDate, other.updatedDate) && Objects.equals(userId, other.userId)
				&& Objects.equals(userName, other.userName) && Objects.equals(projectName, other.projectName)
				&& Objects.equals(lobNmae, other.lobNmae) && Objects.equals(cfgName, other.cfgName)
				&& Objects.equals(towerName, other.towerName) && Objects.equals(onShoreOffshore, other.onShoreOffshore)
				&& acceptedRecCount == other.acceptedRecCount&& Objects.equals(acceptFlag, other.acceptFlag);
	}

	@Override
	public String toString() {
		return "AppUsageTrackerVO [id=" + id + ", userId=" + userId + ", userName=" + userName + ", appName=" + appName
				+ ", moduleName=" + moduleName + ", transactionType=" + transactionType + ", tranTotalCount="
				+ tranTotalCount + ", tranStatus=" + tranStatus + ", tranRemarks=" + tranRemarks + ", createdDate="
				+ createdDate + ", updatedDate=" + updatedDate + ", createdBy=" + createdBy + ", totalExeTime="
				+ totalExeTime + ",projectName=" + projectName + ",lobNmae=" + lobNmae + ",cfgName=" + cfgName
				+ ",towerName=" + towerName + ",onShoreOffshore=" + onShoreOffshore + ",acceptedRecCount="
				+ acceptedRecCount + ",acceptFlag=" + acceptFlag + "]";
	}
}
