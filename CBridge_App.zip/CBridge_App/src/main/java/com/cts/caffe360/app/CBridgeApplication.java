package com.cts.caffe360.app;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.cts.caffe360.cbridg", "com.cts.caffe360.loc.plugin", "com.cts.caffe360.app"})
public class CBridgeApplication {

    public static void main(String arg[]){
    	SpringApplication.run(CBridgeApplication.class, arg);
    	
    	/*ApplicationContext ctx = SpringApplication.run(CBridgeApplication.class, arg);
        
        System.out.println("Let's inspect the beans provided by Spring Boot:");
        String[] beanNames = ctx.getBeanDefinitionNames();
        Arrays.sort(beanNames);
        for (String beanName : beanNames) {
            System.out.println(beanName);
        }*/
    }

    //create method add 2 number




}
