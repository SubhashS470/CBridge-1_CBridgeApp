package com.cts.caffe360.cbridg.exception;

public class CBridgeDBConnectException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public CBridgeDBConnectException() {
        super();
    }

    public CBridgeDBConnectException(String s) {
        super(s);
    }

    public CBridgeDBConnectException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public CBridgeDBConnectException(Throwable throwable) {
        super(throwable);
    }

    protected CBridgeDBConnectException(String s, Throwable throwable, boolean b, boolean b1) {
        super(s, throwable, b, b1);
    }
}
