package com.cts.caffe360.cbridg.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.constants.CBridgeConstant;
import com.cts.caffe360.cbridg.dao.impl.AppUsageTrackerDAOImpl;
import com.cts.caffe360.cbridg.domain.AppUsageTrackerDO;
import com.cts.caffe360.cbridg.exception.CBridgeDBException;
import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.exception.CBridgeServiceException;
import com.cts.caffe360.cbridg.service.AppUsageTrackerService;
import com.cts.caffe360.cbridg.vo.AppUsageTrackerVO;

@Service
public class AppUsageTrackerServiceImpl implements AppUsageTrackerService {
	private static final Logger LOG = LoggerFactory.getLogger(AppUsageTrackerServiceImpl.class);

	@Autowired
	AppUsageTrackerDAOImpl dao;

	@Override
	public AppUsageTrackerVO save(AppUsageTrackerVO voObj) throws CBridgeDBException {
		LOG.info("SAVE Operation Started");
		AppUsageTrackerDO dbObj = saveAppUsageTrackerDO(voObj);
		BeanUtils.copyProperties(dbObj, voObj);
		LOG.info("SAVE Operation End");
		return voObj;
	}

	@Override
	public AppUsageTrackerVO update(AppUsageTrackerVO voObj) throws CBridgeDBException, CBridgeServiceException {
		AppUsageTrackerDO dbObj = null;
		String id = (StringUtils.isNotBlank(voObj.getId()) ? voObj.getId() : "");
		try {
			if (StringUtils.isNotBlank(voObj.getId())) {
				dbObj = dao.findById(id);
			} else {
				LOG.info("Data Not Found");
			}
			if (dbObj == null) {
				dbObj = saveAppUsageTrackerDO(voObj);
			} else {
				LOG.info("DB Update Process for the Unique key -> Id: " + dbObj.get_id() + "\t Appp Name: "
						+ dbObj.getAppName() + "\t Transaction Type: " + dbObj.getTransactionType());
				BeanUtils.copyProperties(voObj, dbObj);
				dao.update(dbObj);
			}
			BeanUtils.copyProperties(dbObj, voObj);
			voObj.setId(dbObj.get_id());
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
			throw new CBridgeServiceException(ex.getMessage());
		}
		return voObj;
	}

	private AppUsageTrackerDO saveAppUsageTrackerDO(AppUsageTrackerVO voObj) throws CBridgeDBException {
		AppUsageTrackerDO dbObj;
		String id = dao.generateSequence(CBridgeConstant.SEQUENCE_NAME) + "";
		LOG.info("Test Data Save operation and Id: " + id);
		dbObj = new AppUsageTrackerDO();
		dbObj.set_id(id);
		BeanUtils.copyProperties(voObj, dbObj);
		// updateRowIndex(dbObj);
		dao.save(dbObj);
		return dbObj;
	}

	@Override
	public List<AppUsageTrackerVO> findAll() throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			dbList = dao.findAll();
			copyDoToVo(voList, dbList);
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByAppName(String appName) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!appName.isEmpty()) {
				dbList = dao.findByAppName(getStringtoList(appName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Data Not Found");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByModuleName(String moduleName) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!moduleName.isEmpty()) {
				dbList = dao.findByModuleName(getStringtoList(moduleName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Data Not Found");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	private void beanCopyAndAddList(List<AppUsageTrackerVO> lst, AppUsageTrackerDO dbObj, AppUsageTrackerVO voObj) {
		try {
			BeanUtils.copyProperties(dbObj, voObj);
			voObj.setId(dbObj.get_id());
			if (lst != null) {
				lst.add(voObj);
			}
		} catch (Exception ex) {
			LOG.error("Error on copy method: " + ex.getMessage());
		}
	}

	@Override
	public AppUsageTrackerVO findById(String id) throws CBridgeDBException, CBridgeServiceException {
		AppUsageTrackerDO dbObj = null;
		AppUsageTrackerVO voObj = new AppUsageTrackerVO();
		try {
			if (StringUtils.isNotBlank(id)) {
				dbObj = dao.findById(id);
				beanCopyAndAddList(null, dbObj, voObj);
			} else {
				LOG.info("Data Not Found");
				throw new CBridgeDataNotFoundException("Data Not Found with Id: " + id);
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
			throw new CBridgeServiceException(ex.getMessage());
		}
		return voObj;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdAndAppName(String userId, String appName) {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(appName)) {
				dbList = dao.findByUserIdAndAppName(getStringtoList(userId), getStringtoList(appName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	private void copyDoToVo(List<AppUsageTrackerVO> voList, List<AppUsageTrackerDO> dbList) {
		for (AppUsageTrackerDO dbObj : dbList) {
			AppUsageTrackerVO voObj = new AppUsageTrackerVO();
			beanCopyAndAddList(voList, dbObj, voObj);
		}
	}

	@Override
	public List<AppUsageTrackerVO> findByUserId(String userId) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userId.isEmpty()) {
				dbList = dao.findByUserId(getStringtoList(userId));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdFromToDate(String userId, String from, String to)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userId.isEmpty()) {
				dbList = dao.findByUserIdFromToDate(getStringtoList(userId), convertStringToDate(from),
						convertStringToDate(to));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserName(String userName) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userName.isEmpty()) {
				dbList = dao.findByUserName(getStringtoList(userName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserNameFromToDate(String userName, Date from, Date to)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userName.isEmpty()) {
				dbList = dao.findByUserNameFromToDate(getStringtoList(userName), from, to);
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByAppNameFromToDate(String appName, String from, String to)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!appName.isEmpty()) {
				dbList = dao.findByAppNameFromToDate(getStringtoList(appName), convertStringToDate(from),
						convertStringToDate(to));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByModuleNameFromToDate(String moduleName, Date from, Date to)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!moduleName.isEmpty()) {
				dbList = dao.findByModuleNameFromToDate(getStringtoList(moduleName), from, to);
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByTxnType(String TxnType) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!TxnType.isEmpty()) {
				dbList = dao.findByTxnType(getStringtoList(TxnType));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByTxnTypeFromToDate(String TxnType, Date from, Date to)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!TxnType.isEmpty()) {
				dbList = dao.findByTxnTypeFromToDate(getStringtoList(TxnType), from, to);
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByModuleNameAndAppName(String moduleName, String appName)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!moduleName.isEmpty() && !appName.isEmpty()) {
				dbList = dao.findByModuleNameAndAppName(getStringtoList(moduleName), getStringtoList(appName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByModuleNameAndAppNameFromToDate(String moduleName, String appName, String from,
			String to) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!moduleName.isEmpty() && !appName.isEmpty()) {
				dbList = dao.findByModuleNameAndAppNameFromToDate(getStringtoList(moduleName), getStringtoList(appName),
						convertStringToDate(from), convertStringToDate(to));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleNameAndDateFromToDate(String userId, String appName,
			String moduleName, Date date, Date from, Date to) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!moduleName.isEmpty() && !moduleName.isEmpty() && !appName.isEmpty()) {
				dbList = dao.findByUserIdAndAppNameAndModuleNameAndDateFromToDate(getStringtoList(userId),
						getStringtoList(appName), getStringtoList(moduleName), date, from, to);
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleName(String userId, String appName, String moduleName)
			throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userId.isEmpty() && !moduleName.isEmpty() && !appName.isEmpty()) {
				dbList = dao.findByUserIdAndAppNameAndModuleName(getStringtoList(userId), getStringtoList(appName),
						getStringtoList(moduleName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleNameAndTxnType(String userId, String appName,
			String moduleName, String TxnType) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userId.isEmpty() && !moduleName.isEmpty() && !appName.isEmpty()) {
				dbList = dao.findByUserIdAndAppNameAndModuleName(getStringtoList(userId), getStringtoList(appName),
						getStringtoList(moduleName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(String userId,
			String appName, String moduleName, String TxnType, Date from, Date to) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!userId.isEmpty() && !moduleName.isEmpty() && !appName.isEmpty() && !TxnType.isEmpty()) {
				dbList = dao.findByUserIdAndAppNameAndModuleNameAndTxnTypeAndFromToDate(getStringtoList(userId),
						getStringtoList(appName), getStringtoList(moduleName), getStringtoList(TxnType), from, to);
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	public static Date convertStringToDate(String dateStr) throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return formatter.parse(dateStr);
	}

	private List<String> getStringtoList(String str) {
		List<String> lst = StringUtils.isBlank(str) ? Collections.emptyList()
				: Stream.of(StringUtils.split(str, ',')).map(String::trim).filter(StringUtils::isNotBlank)
						.collect(Collectors.toList());
		return lst;
	}
//.map(s -> "\"" + s + "\"")
	/*
	 * public static void main(String[] args) { AppUsageTrackerServiceImpl app = new
	 * AppUsageTrackerServiceImpl();
	 */

	@Override
	public List<AppUsageTrackerVO> findByFromToDate(String from, String to) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (from != null && to != null) {
				dbList = dao.findByFromToDate(convertStringToDate(from), convertStringToDate(to));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByTower(String towerName) throws CBridgeDBException {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!towerName.isEmpty()) {
				dbList = dao.findByTower(getStringtoList(towerName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByTowerNameAndFromAndTodate(String towerName, Date from, Date to) {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (!towerName.isEmpty()) {
				dbList = dao.findByTowerNameAndFromAndTodate(getStringtoList(towerName), from, to);
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByUserIdAndTowerName(String userId, String towerName) {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(towerName)) {
				dbList = dao.findByUserIdAndTowerName(getStringtoList(userId), getStringtoList(towerName));
				copyDoToVo(voList, dbList);
			} else {
				LOG.info("Input data should not empty");
			}
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> findByAllFetch(String towerName, String userId, String appName, String moduleName,
			String TxnType, String from, String to) {
		List<AppUsageTrackerVO> voList = new ArrayList<AppUsageTrackerVO>();
		List<AppUsageTrackerDO> dbList = null;
		try {
			dbList = dao.findByAllFetch(getStringtoList(towerName), getStringtoList(userId), convertStringToDate(from),
					convertStringToDate(to), getStringtoList(appName), getStringtoList(moduleName),
					getStringtoList(TxnType));
			copyDoToVo(voList, dbList);
		} catch (Exception ex) {
			LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
		}
		return voList;
	}

	@Override
	public List<AppUsageTrackerVO> bulkUpdate(List<AppUsageTrackerVO> voList) {
		for (AppUsageTrackerVO vo : voList) {
			AppUsageTrackerDO dbObj = null;
			String id = (StringUtils.isNotBlank(vo.getId()) ? vo.getId() : "");
			try {
				if (StringUtils.isNotBlank(vo.getId())) {
					dbObj = dao.findById(id);
					LOG.info("DB Update Process for the Unique key -> Id: " + dbObj.get_id() + "\t Appp Name: "
							+ dbObj.getAppName() + "\t Transaction Type: " + dbObj.getTransactionType());
					BeanUtils.copyProperties(vo, dbObj);
					dao.update(dbObj);
					BeanUtils.copyProperties(dbObj, vo);
					vo.setId(dbObj.get_id());
				} else {
					LOG.info("Data Not Found");
				}

			} catch (Exception ex) {
				LOG.info("Exception Found on Update fetch query execution. Error Message: " + ex.getMessage());
			}
		}
		return voList;
	}

}
