package com.cts.caffe360.cbridg.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.time.DateUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CBridgeKeyValuesDO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer rowIndex;
	
	@JsonProperty("value")
    private String value;

    @JsonProperty("description")
    private String description;

    @JsonProperty("updated_date")
    private Date updatedDate;

    @JsonProperty("expiry_date")
    private Date expiryDate; //default 90days from last updated date

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getUpdatedDate() {
        if (updatedDate == null){
            setUpdatedDate(new Date());
        }
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
        setExpiryDate(DateUtils.addMonths(this.updatedDate,3));
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public String toString() {
        return "CBridgeKeyValuesDO{" +
                "value='" + value + '\'' +
                ", description='" + description + '\'' +
                ", updatedDate=" + updatedDate +
                ", expiryDate=" + expiryDate +
                '}';
    }

	public Integer getRowIndex() {
		return rowIndex;
	}

	public void setRowIndex(Integer rowIndex) {
		this.rowIndex = rowIndex;
	}

	@Override
	public int hashCode() {
		return Objects.hash(description, expiryDate, rowIndex, updatedDate, value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CBridgeKeyValuesDO other = (CBridgeKeyValuesDO) obj;
		return Objects.equals(description, other.description) && Objects.equals(expiryDate, other.expiryDate)
				&& Objects.equals(rowIndex, other.rowIndex) && Objects.equals(updatedDate, other.updatedDate)
				&& Objects.equals(value, other.value);
	}
}
