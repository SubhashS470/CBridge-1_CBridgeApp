package com.cts.caffe360.cbridg.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LoginLogoffTrakerVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("id")
	private String id;
	@JsonProperty("user_id")
	private String userId;
	@JsonProperty("user_name")
	private String userName;
	@JsonProperty("app_name")
	private String appName;
	@JsonProperty("login_date")
	private Date loginDate;
	@JsonProperty("login_time")
	private Date loginTime;
	@JsonProperty("logoff_time")
	private Date logoffTime;
	@JsonProperty("logoff_remarks")
	private String logoffRemarks;
	
	public LoginLogoffTrakerVO() {
		super();
	}
	
	public LoginLogoffTrakerVO(String id, String userId, String userName, String appName, Date loginDate,
			Date loginTime, Date logoffTime, String logoffRemarks) {
		super();
		this.id = id;
		this.userId = userId;
		this.userName = userName;
		this.appName = appName;
		this.loginDate = loginDate;
		this.loginTime = loginTime;
		this.logoffTime = logoffTime;
		this.logoffRemarks = logoffRemarks;
	}
	public String getId() {
		return id;
	}
	public String getUserId() {
		return userId;
	}
	public String getUserName() {
		return userName;
	}
	public String getAppName() {
		return appName;
	}
	public Date getLoginDate() {
		return loginDate;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public Date getLogoffTime() {
		return logoffTime;
	}
	public String getLogoffRemarks() {
		return logoffRemarks;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public void setLogoffTime(Date logoffTime) {
		this.logoffTime = logoffTime;
	}
	public void setLogoffRemarks(String logoffRemarks) {
		this.logoffRemarks = logoffRemarks;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(appName, id, loginDate, loginTime, logoffRemarks, logoffTime, userId, userName);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoginLogoffTrakerVO other = (LoginLogoffTrakerVO) obj;
		return Objects.equals(appName, other.appName) && Objects.equals(id, other.id)
				&& Objects.equals(loginDate, other.loginDate) && Objects.equals(loginTime, other.loginTime)
				&& Objects.equals(logoffRemarks, other.logoffRemarks) && Objects.equals(logoffTime, other.logoffTime)
				&& Objects.equals(userId, other.userId) && Objects.equals(userName, other.userName);
	}
	
	@Override
	public String toString() {
		return "LoginLogoffVO [id=" + id + ", userId=" + userId + ", userName=" + userName + ", appName=" + appName
				+ ", loginDate=" + loginDate + ", loginTime=" + loginTime + ", logoffTime=" + logoffTime
				+ ", logoffRemarks=" + logoffRemarks + "]";
	}
	
}
