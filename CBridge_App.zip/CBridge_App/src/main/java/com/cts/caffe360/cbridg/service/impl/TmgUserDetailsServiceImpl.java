package com.cts.caffe360.cbridg.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.dao.TmgUserDetailsDAO;
import com.cts.caffe360.cbridg.domain.TmgUserDetailsDO;
import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;
import com.cts.caffe360.cbridg.service.TmgUserDetailsService;
import com.cts.caffe360.cbridg.vo.TmgUserDetailsVO;

@Service
public class TmgUserDetailsServiceImpl implements TmgUserDetailsService {

	private static final Logger LOG = LoggerFactory.getLogger(TmgUserDetailsServiceImpl.class);

	@Autowired
	private TmgUserDetailsDAO tmgUserDetailsDAO;

	@Override
	public List<TmgUserDetailsVO> findAll() throws Exception {
		LOG.info("TmgUserDetailsServiceImpl: findAll");
		List<TmgUserDetailsDO> doList = tmgUserDetailsDAO.findAll();
		return doList.stream().map(this::convertToVO).collect(Collectors.toList());
	}

	@Override
	public TmgUserDetailsVO findByAssociateId(String associateId) throws CBridgeDataNotFoundException {
		LOG.info("TmgUserDetailsServiceImpl: findByAssociateId: {}", associateId);

		if (associateId == null) {
			throw new IllegalArgumentException("Associate Id cannot be null");
		}

		TmgUserDetailsDO tmgUserDetailsDO = tmgUserDetailsDAO.findByAssociateId(associateId);
		if (tmgUserDetailsDO == null) {
			throw new CBridgeDataNotFoundException("TMG user details not found for associate id: " + associateId);
		}
		return convertToVO(tmgUserDetailsDO);
	}

	@Override
	public TmgUserDetailsVO create(TmgUserDetailsVO tmgUserDetailsVO) throws Exception {
		LOG.info("TmgUserDetailsServiceImpl: create");

		if (tmgUserDetailsVO == null) {
			throw new IllegalArgumentException("TMG user details cannot be null");
		}

		// No id set here; MongoDB will generate _id
		TmgUserDetailsDO saved = tmgUserDetailsDAO.save(convertToDO(tmgUserDetailsVO));
		return convertToVO(saved);
	}

	@Override
	public TmgUserDetailsVO updateByAssociateId(String associateId, TmgUserDetailsVO tmgUserDetailsVO) throws Exception {
		LOG.info("TmgUserDetailsServiceImpl: updateByAssociateId: {}", associateId);

		if (associateId == null) {
			throw new IllegalArgumentException("Associate Id cannot be null");
		}
		if (tmgUserDetailsVO == null) {
			throw new IllegalArgumentException("TMG user details cannot be null");
		}

		TmgUserDetailsDO existing = tmgUserDetailsDAO.findByAssociateId(associateId);
		if (existing == null) {
			throw new CBridgeDataNotFoundException("TMG user details not found for associate id: " + associateId);
		}

		TmgUserDetailsDO toSave = convertToDO(tmgUserDetailsVO);
		// Preserve Mongo _id and ensure associateId matches path
		toSave.setId(existing.getId());
		toSave.setAssociateId(Long.parseLong(associateId));

		TmgUserDetailsDO saved = tmgUserDetailsDAO.save(toSave);
		return convertToVO(saved);
	}

	@Override
	public void deleteByAssociateId(String associateId) throws CBridgeDataNotFoundException {
		LOG.info("TmgUserDetailsServiceImpl: deleteByAssociateId: {}", associateId);

		if (associateId == null) {
			throw new IllegalArgumentException("Associate Id cannot be null");
		}

		TmgUserDetailsDO existing = tmgUserDetailsDAO.findByAssociateId(associateId);
		if (existing == null) {
			throw new CBridgeDataNotFoundException("TMG user details not found for associate id: " + associateId);
		}

		tmgUserDetailsDAO.deleteByAssociateId(associateId);
	}

	private TmgUserDetailsVO convertToVO(TmgUserDetailsDO doObj) {
		TmgUserDetailsVO vo = new TmgUserDetailsVO();
		vo.setAssociateId(doObj.getAssociateId());
		vo.setAssociateName(doObj.getAssociateName());
		vo.setPassword(doObj.getPassword());
		vo.setEmail(doObj.getEmail());
		vo.setTmgUserId(doObj.getTmgUserId());
		vo.setStatus(doObj.getStatus());
		vo.setLocation(doObj.getLocation());
		vo.setSuperviserId(doObj.getSuperviserId());
		vo.setSuperviserName(doObj.getSuperviserName());
		vo.setTower(doObj.getTower());
		vo.setProject(doObj.getProject());
		return vo;
	}

	private TmgUserDetailsDO convertToDO(TmgUserDetailsVO vo) {
		TmgUserDetailsDO doObj = new TmgUserDetailsDO();
		// _id is not set here; it is handled on create by Mongo, or on update by copying from existing
		doObj.setAssociateId(vo.getAssociateId());
		doObj.setAssociateName(vo.getAssociateName());
		doObj.setPassword(vo.getPassword());
		doObj.setEmail(vo.getEmail());
		doObj.setTmgUserId(vo.getTmgUserId());
		doObj.setStatus(vo.getStatus());
		doObj.setLocation(vo.getLocation());
		doObj.setSuperviserId(vo.getSuperviserId());
		doObj.setSuperviserName(vo.getSuperviserName());
		doObj.setTower(vo.getTower());
		doObj.setProject(vo.getProject());
		return doObj;
	}
}