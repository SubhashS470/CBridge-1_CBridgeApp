package com.cts.caffe360.cbridg.dao.impl;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.dao.SystemConfigDAO;
import com.cts.caffe360.cbridg.domain.SystemConfigDO;

@Repository
public class SystemConfigDAOImpl implements SystemConfigDAO {

	private static final Logger LOG = LoggerFactory.getLogger(SystemConfigDAOImpl.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<SystemConfigDO> findAll() {
		LOG.info("SystemConfigDAOImpl:  findAll");
		return mongoTemplate.findAll(SystemConfigDO.class);
	}

	@Override
	public List<SystemConfigDO> findBySysParamType(String sysParamType) {
		LOG.info("SystemConfigDAOImpl: findBySysParamType:  {}", sysParamType);
		Query query = new Query(Criteria.where("Sys_Param_Type").is(sysParamType));
		return mongoTemplate.find(query, SystemConfigDO.class);
	}

	@Override
	public Map<Long, String> findTypeMapByParamType(String sysParamType) {
		LOG.info("SystemConfigDAOImpl: findTypeMapByParamType: {}", sysParamType);
		List<SystemConfigDO> configList = findBySysParamType(sysParamType);
		return configList.stream()
				.collect(Collectors.toMap(
						SystemConfigDO::getTypeId,
						SystemConfigDO::getTypeValue
				));
	}

	@Override
	public SystemConfigDO save(SystemConfigDO systemConfigDO) {
		LOG.info("SystemConfigDAOImpl: save");
		return mongoTemplate.save(systemConfigDO);
	}

	@Override
	public SystemConfigDO findBySysConfigId(Integer sysConfigId) {
		LOG.info("SystemConfigDAOImpl: findBySysConfigId: {}", sysConfigId);
		Query query = new Query(Criteria.where("Sys_Config_Id").is(sysConfigId));
		return mongoTemplate.findOne(query, SystemConfigDO.class);
	}

	@Override
	public void deleteBySysConfigId(Integer sysConfigId) {
		LOG.info("SystemConfigDAOImpl:  deleteBySysConfigId: {}", sysConfigId);
		Query query = new Query(Criteria.where("Sys_Config_Id").is(sysConfigId));
		mongoTemplate.remove(query, SystemConfigDO.class);
	}

}