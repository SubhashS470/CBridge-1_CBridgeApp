package com.cts.caffe360.cbridg.domain;

import java.io.Serializable;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document (collection = "CBridgeTestData")
public class CBridgeTestDataDO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @JsonProperty("id")
    private Long _id;
	
    @JsonProperty("key")
    private String key;
    
    @JsonProperty("module_name")
    private String moduleName;
    
    @JsonProperty("created_user")
    private String createdUser;
    
    @JsonProperty("key_value")
    private Map<String, String> keyValues;
    
    private Integer listTotIndex;
    
    public CBridgeTestDataDO() {
    }

    public CBridgeTestDataDO(Long _id) {
        this._id = _id;
    }

    public CBridgeTestDataDO(String key, String moduleName) {
        this.key = key;
        this.moduleName = moduleName;
    }

    public Long get_id() {
        return _id;
    }

    public void set_id(Long _id) {
        this._id = _id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

	public Integer getListTotIndex() {
		return listTotIndex;
	}

	public void setListTotIndex(Integer listTotIndex) {
		this.listTotIndex = listTotIndex;
	}
	
	public int increase() {
		return ++listTotIndex;
	}

	public Map<String, String> getKeyValues() {
		return keyValues;
	}

	public void setKeyValues(Map<String, String> keyValues) {
		this.keyValues = keyValues;
	}
	
	@Override
    public String toString() {
        return "CBridgeTestDataDO{" +
                "_id=" + _id +
                ", key='" + key + '\'' +
                ", moduleName='" + moduleName + '\'' +
                ", createdUser='" + createdUser + '\'' +
                ", values=" + keyValues +
                '}';
    }
}
