package com.cts.caffe360.cbridg.vo;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CBridgeTestDataVO implements Serializable {
	private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private Long id;
	
    @JsonProperty("key")
    private String key;
    
    @JsonProperty("module_name")
    private String moduleName;
    
    @JsonProperty("created_user")
    private String createdUser;
    
    @JsonProperty("key_value")
    private Map<String, String> keyValues;

    public Map<String, String> getKeyValues() {
		return keyValues;
	}

	public void setKeyValues(Map<String, String> keyValues) {
		this.keyValues = keyValues;
	}

	public Long getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getCreatedUser() {
        return createdUser;
    }

    public void setCreatedUser(String createdUser) {
        this.createdUser = createdUser;
    }

    @Override
    public String toString() {
        return "CBridgeTestDataVO{" +
                "id=" + id +
                ", key='" + key + '\'' +
                ", moduleName='" + moduleName + '\'' +
                ", createdUser='" + createdUser + '\'' +
                ", keyValues=" + keyValues +
                '}';
    }

	/*
	 * public List<CBridgeKeyValuesVO> getKeyValues() { return keyValues; }
	 * 
	 * public void setKeyValues(List<CBridgeKeyValuesVO> keyValues) { this.keyValues
	 * = keyValues; }
	 * 
	 * public void addKeyValue(CBridgeKeyValuesVO voValue) { if (keyValues == null)
	 * { keyValues = new ArrayList<CBridgeKeyValuesVO>(); } keyValues.add(voValue);
	 * }
	 */
	public void setId(Long id) {
		this.id = id;
	}
	
}
