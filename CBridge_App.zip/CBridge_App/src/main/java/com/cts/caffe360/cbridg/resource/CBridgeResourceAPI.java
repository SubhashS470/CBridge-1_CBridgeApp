package com.cts.caffe360.cbridg.resource;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.caffe360.cbridg.service.impl.CBridgeServiceImpl;
import com.cts.caffe360.cbridg.utiles.CBridgeUtile;
import com.cts.caffe360.cbridg.vo.CBridgeTestDataVO;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping(value = "/cbridge/api")
@Tag(name = "CBridge API Documentation")
public class CBridgeResourceAPI {
    private static final Logger LOG = LoggerFactory.getLogger(CBridgeResourceAPI.class);

    @Autowired
    CBridgeServiceImpl service;
    private final AtomicLong counter = new AtomicLong();

    @Operation(summary = "Verify CBridge Service Status")
    @GetMapping("/healthCheck")
    public String getCBridgeHealthCheck(){
        return "Hello CTS: I am good. Total Call Count: " + counter.incrementAndGet();
    }

    @Operation(summary = "Fetch Test Data values based on key")
    @GetMapping("/id/{id}")
    public CBridgeTestDataVO  getIdValue(@PathVariable String id) throws Exception {
    	CBridgeTestDataVO dataVO = null;
    	LOG.info("getIdValue: Request id: " + id);
    	dataVO = service.findById(id);
    	LOG.info("getIdValue: Response value: " + CBridgeUtile.getJsonObjectString(dataVO));
        return dataVO;
    }

    @Operation(summary = "Fetch Test Data values based on key")
    @GetMapping("/key/{key}")
    public List<CBridgeTestDataVO>  getKeyValue(@PathVariable String key) throws Exception {
        return service.findByKey(key);
    }

    @Operation(summary = "Fetch Test Data values based on key")
    @GetMapping("/id/{id}/key/{key}")
    CBridgeTestDataVO findByIdAndKey(@PathVariable String id, @PathVariable String key) throws Exception{
        return service.findByIdAndKey(id, key);
    }

    @Operation(summary = "Fetch Test Data based on key, Module and created user name")
    @GetMapping("/key/{key}/module/{module}/userName/{userName}")
    CBridgeTestDataVO findByIdAndKey(@PathVariable String key, @PathVariable String module, @PathVariable String userName) throws Exception{
        return service.findByKeyModuleUser(key, module, userName);
    }

    
    @Operation(summary = "Fetch all Test Data values")
    @GetMapping("/all")
    public List<CBridgeTestDataVO> getAllKeyValue() throws Exception {
        return service.fetchAllCBridgeDocument();
    }
    
    @Operation(summary = "Fetch Test Data values based on key")
    @GetMapping("/value/{value}")
    public List<CBridgeTestDataVO>  getByValue(@PathVariable String value) throws Exception {
        return service.findByValue(value);
    }

    @Operation(summary = "Save/Update the Test data")
    @PostMapping(path="/updateTestData", name="updateTestData", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public CBridgeTestDataVO updateTestData(@RequestBody (required = false) CBridgeTestDataVO cBridgeTestDataVO, Model model) throws Exception {
        LOG.info("Request Object value: " + CBridgeUtile.getJsonObjectString(cBridgeTestDataVO));
        service.update(cBridgeTestDataVO);
        LOG.info("Response Object value: " + CBridgeUtile.getJsonObjectString(cBridgeTestDataVO));
        return cBridgeTestDataVO;
    }

}
