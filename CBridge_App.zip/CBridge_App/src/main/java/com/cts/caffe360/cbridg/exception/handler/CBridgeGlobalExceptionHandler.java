package com.cts.caffe360.cbridg.exception.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.cts.caffe360.cbridg.exception.CBridgeDBConnectException;
import com.cts.caffe360.cbridg.exception.CBridgeDataNotFoundException;

import java.util.Date;

@ControllerAdvice
public class CBridgeGlobalExceptionHandler {

    @ExceptionHandler(CBridgeResourceNotFoundException.class)
    public ResponseEntity<? > resourceNotFoundException(CBridgeResourceNotFoundException ex, WebRequest request) {
        return new ResponseEntity<>(getCBridgeExceptionDetails(ex, request), HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> globleExcpetionHandler(Exception ex, WebRequest request) {
        return new ResponseEntity<>(getCBridgeExceptionDetails(ex, request), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(CBridgeDataNotFoundException.class)
    public ResponseEntity<? > resourceDataNotFoundException(CBridgeDataNotFoundException ex, WebRequest request) {
        return new ResponseEntity<>(getCBridgeExceptionDetails(ex, request), HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(CBridgeDBConnectException.class)
    public ResponseEntity<? > cBridgeDBConnectException(CBridgeDBConnectException ex, WebRequest request) {
        return new ResponseEntity<>(getCBridgeExceptionDetails(ex, request), HttpStatus.EXPECTATION_FAILED);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<?> illegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        return new ResponseEntity<>(getCBridgeExceptionDetails(ex, request), HttpStatus.BAD_REQUEST);
    }
    
	private CBridgeExceptionDetails getCBridgeExceptionDetails(Exception ex, WebRequest request) {
		CBridgeExceptionDetails errorDetails = new CBridgeExceptionDetails(new Date(), ex.getMessage(), request.getDescription(false));
		return errorDetails;
	}

}