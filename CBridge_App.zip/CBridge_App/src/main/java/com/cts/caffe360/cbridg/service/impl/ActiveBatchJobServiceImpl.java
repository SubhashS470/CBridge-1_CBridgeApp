package com.cts.caffe360.cbridg.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.caffe360.cbridg.service.ActiveBatchJobService;
import com.cts.caffe360.cbridg.vo.ActiveBatchJobVO;

@Service
@Component
public class ActiveBatchJobServiceImpl implements ActiveBatchJobService {
	private static final Logger LOG = LoggerFactory.getLogger(ActiveBatchJobServiceImpl.class);

	@Value("${user.name}")
	private String userName;

	@Value("${password}")
	private String password;

	@Value("${command.to.execute}")
	private String command;
	
	@Value("${host}")
	private String host;

	@Value("${dbName}")
	private String dbName;
	
	@Value("${statusQuery}")
	private String statusQuery;

	@Override
	public ActiveBatchJobVO triggerABJob(String abJob, String type) throws Exception {
		ActiveBatchJobVO voList = new ActiveBatchJobVO();
		if (StringUtils.equalsIgnoreCase(type, "URL")) {
			abJobWebserviceTrigger(abJob);
		} else {
			abJobIdTrigger(getActivebatchURL(command, abJob, userName, password));
		}
		return voList;
	}

	@Override
	public String getABJobStatus(String instentId) throws Exception {
		String stsQuery = StringUtils.EMPTY;
		stsQuery = statusQuery;
		stsQuery = stsQuery.replace(":jobid", instentId);
		String result = StringUtils.EMPTY;
		String connectionUrl = "jdbc:sqlserver://" + host + ":1433;" + "databaseName=" + dbName
				+ ";integratedSecurity=true;";
		try (Connection connection = DriverManager.getConnection(connectionUrl);) {
			PreparedStatement ps = connection.prepareStatement(stsQuery);
			ResultSet rssample = ps.executeQuery();
			while (rssample.next()) {
				if (rssample.getString("ExitCode").equals("0") || rssample.getString("ExitCode").equals("100")) {
					result = "Success" + "~" + rssample.getString("InstanceID");
				} else {
					result = "Failed" + "~" + rssample.getString("InstanceID");
				}
			}
			return result;
		} catch (SQLException e) {
			LOG.info("Error while get Job Status: Error Message : "+e.getMessage());
		}
		System.out.println(result);
		return null;

	}

	private static String getActivebatchURL(String commandToExecute, String jobId, String userName,
			String userPassword) {
		userPassword = userPassword.replace("$", "\\$");
		commandToExecute = commandToExecute.replaceAll("-----JOB_ID-----", jobId)
				.replace("-----USERNAME-----", userName).replaceAll("-----PWD-----", userPassword);
		return commandToExecute;
	}

	public void abJobIdTrigger(String jobExecuteCommond) {
		Process processor = null;
		try {
			ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", jobExecuteCommond);
			builder.redirectErrorStream(true);
			processor = builder.start();
			BufferedReader busRead = null;
			if (processor != null) {
				busRead = new BufferedReader(new InputStreamReader(processor.getInputStream()));
			} else {
				LOG.info("Active Batch Trigger Process Failed");
			}
			String jobProcessId = getJobExecutionProcessId(processor, busRead);
			String[] jobests = jobProcessId.split("~");
			if (jobests.length > 0 && !jobProcessId.trim().equals("~")) {
				jobProcessId = jobProcessId.split("~")[0];
			}
		} catch (IOException e) {
			LOG.info("Exception Found on JobID execution. Error Message: " + e.getMessage());
		}
	}

	private static String getJobExecutionProcessId(Process processor, BufferedReader busRead) throws IOException {
		String line;
		String fline = "";
		String jobProcessId = "";
		String Jobexecsts = "";
		try {
			while ((line = busRead.readLine()) != null) {
				fline = fline + "\n" + line;
				LOG.info("line =" + line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != processor) {
				processor.destroy();
			}
			if (null != busRead) {
				busRead.close();
			}
		}
		System.out.println(fline);
		if (fline.contains("Failed to Trigger")) {
			Jobexecsts = fline;
		}
		if (!fline.trim().equals("")) {
			String[] str = fline.split("\n");
			jobProcessId = str[1];
			jobProcessId = jobProcessId.substring(jobProcessId.length() - 8, jobProcessId.length());
		}
		LOG.info("Check : " + jobProcessId + "~" + Jobexecsts.replace("\n", " "));
		return jobProcessId + "~" + Jobexecsts.replace("\n", " ");
	}

	public void abJobWebserviceTrigger(String url) {
		String responseString = StringUtils.EMPTY;
		String outputString = "Job Instance ID:";
		HttpURLConnection httpConn = gethttpConnection(url);
		InputStreamReader isr = null;
		try {
			isr = new InputStreamReader(httpConn.getInputStream());
		} catch (IOException ex) {
			LOG.info("Exception Found on Job execution. Error Message: " + ex.getMessage());
		}
		BufferedReader in = new BufferedReader(isr);
		try {
			if ((responseString = in.readLine()) != null) {
				LOG.info("Job Triggered " + outputString + responseString);
			}
		} catch (IOException ex) {
			LOG.info("Trigger Failed: " + ex.getMessage());
		}
	}

	private static HttpURLConnection gethttpConnection(String endPointurl) {
		URL url = null;
		try {
			url = new URL(endPointurl);
		} catch (MalformedURLException e) {
			LOG.info("Exception Found on Job execution connection URL. Error Message: " + e.getMessage());
		}
		URLConnection connection = null;
		try {
			connection = url.openConnection();
		} catch (IOException e) {
			LOG.info("Exception Found on Job execution connection. Error Message: " + e.getMessage());
		}
		return (HttpURLConnection) connection;
	}
}
