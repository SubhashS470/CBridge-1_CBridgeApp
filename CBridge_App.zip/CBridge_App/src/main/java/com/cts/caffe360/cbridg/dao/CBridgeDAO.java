package com.cts.caffe360.cbridg.dao;

import org.springframework.stereotype.Repository;

import com.cts.caffe360.cbridg.exception.CBridgeDBException;

@Repository
public interface CBridgeDAO {
	 /**
     * This method used to increase CBridge Test Data sequence value and return values
     * @param seqName
     * @return
     * @throws CBridgeDBException
     */
    public long generateSequence(String seqName) throws CBridgeDBException;

}
